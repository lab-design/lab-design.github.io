package lib.exceptions;

public class UpdateEntryException extends Exception {

	public UpdateEntryException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UpdateEntryException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public UpdateEntryException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public UpdateEntryException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
