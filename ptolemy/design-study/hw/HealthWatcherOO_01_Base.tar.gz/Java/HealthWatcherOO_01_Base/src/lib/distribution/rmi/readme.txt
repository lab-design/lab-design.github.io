The classes in this package were defined to 
implement an adapter to  iterators objects.

The  iterator objects  are  used  to list a 
collection of objets  stored in the system. 
For example, the  clients of a  bank, which 
have  more  than  1000 US$  in the  account 
balance. Depending of the searching  asked, 
the iterator can have several  objects, and 
their   transmissions  over  the   net  can 
overhead  the system. Using  this approach, 
the iterator's objects are transmitted while 
the iterator is accessed
