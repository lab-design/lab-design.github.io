package lib.exceptions;

public class TransactionException extends Exception {

	public TransactionException(String s) {
		super(s);
	}
}
