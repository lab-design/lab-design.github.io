package lib.exceptions;


public class PersistenceMechanismException extends RepositoryException {
	public PersistenceMechanismException(String erro) {
		super(erro);
	}

}
