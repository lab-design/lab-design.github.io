package lib.exceptions;

public class FacadeUnavailableException extends Exception {

}
