package lancs.midp.mobilephoto.alternative.photoMusic.events;

import ubc.midp.mobilephoto.core.ui.screens.AlbumListScreen;

public void event InitMenuEvent {
	AlbumListScreen screen;
}
