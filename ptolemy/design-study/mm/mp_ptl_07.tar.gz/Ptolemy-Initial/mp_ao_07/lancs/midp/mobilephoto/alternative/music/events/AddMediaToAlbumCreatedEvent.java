package lancs.midp.mobilephoto.alternative.music.events;

import ubc.midp.mobilephoto.core.ui.screens.AddMediaToAlbum;

public void event AddMediaToAlbumCreatedEvent {
	AddMediaToAlbum screen;
}
