package lancs.midp.mobilephoto.alternative.photo.handler;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Image;

import lancs.midp.mobilephoto.alternative.photo.ImageAlbumData;
import lancs.midp.mobilephoto.alternative.photo.PhotoViewScreen;
import ubc.midp.mobilephoto.core.ui.controller.*;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import javax.microedition.rms.RecordStoreException;
import java.io.IOException;
import ubc.midp.mobilephoto.core.ui.screens.*;
import lancs.midp.mobilephoto.optional.sms.events.*;
import ubc.midp.mobilephoto.core.ui.controller.ScreenSingleton;
import ubc.midp.mobilephoto.core.util.Constants;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.events.*;
import lancs.midp.mobilephoto.alternative.music.events.*;
import lancs.midp.mobilephoto.optional.copyPhoto.events.*;
import edu.iastate.cs.ptolemy.runtime.*;

@Instantiation(Instantiation.Model.SINGLETON)
@Registration(Registration.Model.IMPLICIT)
@PrecedesHandler(lancs.midp.mobilephoto.alternative.photoMusic.handler.PhotoAndMusicAspectHandler.class)
public class PhotoAspectHandler {
	public static BaseController imageRootController;

	public static AlbumData imageModel;

	public PhotoAspectHandler() { register(this); }

	// [NC] Added in the scenario 07
	public void MediaController.showImage(String name) throws IOException, RecordStoreException {
		//[EF] Instead of replicating this code, I change to use the method "getSelectedImageName()". 		
		Image storedImage = null;
		storedImage = ((ImageAlbumData)getAlbumData()).getImageFromRecordStore(getCurrentStoreName(), name);
		//We can pass in the image directly here, or just the name/model pair and have it loaded
		PhotoViewScreen canv = new PhotoViewScreen(storedImage);
		announce GetPhotoControllerEvent (this, name) {
			canv.setCommandListener( this );
		}

		announce SetPhotoScreenEvent(this,name,canv) {
			setCurrentScreen(canv);
		}
	}
			
	public static final int SHOWPHOTO = 1;
	
	// [NC] Added in the scenario 07
	public static final Command viewCommand = new Command("View", Command.ITEM, 1);

	public void handler(StartApplicationEvent next) throws Throwable {
		invoke(next);

		PhotoAspectHandler.imageModel = new ImageAlbumData();
		
		// [NC] Added in the scenario 07
		AlbumListScreen album = new AlbumListScreen();
		PhotoAspectHandler.imageRootController = new BaseController(next.middlet, PhotoAspectHandler.imageModel, album);
		
		// [EF] Add in scenario 04: initialize sub-controllers
		MediaListController photoListController = new MediaListController(next.middlet, PhotoAspectHandler.imageModel, album);
		photoListController.setNextController(PhotoAspectHandler.imageRootController);
		
		AlbumController albumController = new AlbumController(next.middlet, PhotoAspectHandler.imageModel, album);
		albumController.setNextController(photoListController);
		album.setCommandListener(albumController);
		
		PhotoAspectHandler.imageRootController.init(PhotoAspectHandler.imageModel);
	}
	when StartApplicationEvent do handler;

	public boolean handler(CommandActionEvent next) throws Throwable {
		boolean handled = invoke(next);
		
		if (handled) return true;
		
		String label = next.c.getLabel();
		System.out.println("<* PhotoAspect.around handleCommandAction *> ::handleCommand: " + label);
		
		// [NC] Added in the scenario 07
		if (label.equals("View")) {
			String selectedImageName = next.controller.getSelectedMediaName();
			next.controller.showImage(selectedImageName);
			ScreenSingleton.getInstance().setCurrentScreenName(Constants.IMAGE_SCREEN);
			return true;
		}
		return false;
	}
	when CommandActionEvent do handler;

	public void handler(InitMenuEvent next) throws Throwable {
		invoke(next);
		
		if (next.screen.getTypeOfScreen() == PhotoAspectHandler.SHOWPHOTO)
			next.screen.addCommand(PhotoAspectHandler.viewCommand);
	}
	when InitMenuEvent do handler;

	public MediaListScreen handler(MediaListScreenCreatedEvent next) throws Throwable {
		MediaListScreen listScreen = invoke(next);
		if (next.controller.getAlbumData() instanceof ImageAlbumData)
			listScreen.setTypeOfScreen(PhotoAspectHandler.SHOWPHOTO);
		return listScreen;
	}
	when MediaListScreenCreatedEvent do handler;
}
