package lancs.midp.mobilephoto.optional.sms.events;

import ubc.midp.mobilephoto.core.ui.controller.MediaController;

public void event GetPhotoControllerEvent {
	
	MediaController controller;
	String imageName;
}
