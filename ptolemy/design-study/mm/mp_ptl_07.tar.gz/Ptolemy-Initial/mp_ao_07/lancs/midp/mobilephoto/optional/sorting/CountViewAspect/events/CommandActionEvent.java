package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.events;

import javax.microedition.lcdui.Command;
import ubc.midp.mobilephoto.core.ui.controller.MediaController;

public boolean event CommandActionEvent {
	MediaController controller;
	Command c;
}
