package lancs.midp.ptolemy.exceptionblocks.controllerAspectEH.events;

import javax.microedition.midlet.MIDlet;

public void event ResetImageDataEvent {
	MIDlet midlet;
}
