package lancs.midp.ptolemy.exceptionblocks.dataModelAspectEH.events;

import javax.microedition.lcdui.Image;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;

public Image event GetImageFromRecordStoreEvent {
	AlbumData album;
}
