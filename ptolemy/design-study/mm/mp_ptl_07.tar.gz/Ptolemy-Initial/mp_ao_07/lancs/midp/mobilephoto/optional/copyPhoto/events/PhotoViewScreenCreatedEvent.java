package lancs.midp.mobilephoto.optional.copyPhoto.events;

import lancs.midp.mobilephoto.alternative.photo.PhotoViewScreen;

public void event PhotoViewScreenCreatedEvent {
	PhotoViewScreen f;
}
