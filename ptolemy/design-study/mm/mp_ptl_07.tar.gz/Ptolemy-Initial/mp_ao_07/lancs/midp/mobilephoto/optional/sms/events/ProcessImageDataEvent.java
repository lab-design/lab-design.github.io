package lancs.midp.mobilephoto.optional.sms.events;

import lancs.midp.mobilephoto.optional.copyPhoto.MediaViewController;
import ubc.midp.mobilephoto.core.ui.datamodel.MediaAccessor;

public void event ProcessImageDataEvent
{
	MediaViewController photoViewController;
	MediaAccessor mediaAccessor;
	String photoName;
	String albumname;
}
