package lancs.midp.aspects.exceptionblocks.controllerAspectEH.annotations;

import java.lang.annotation.*;

@Retention(RetentionPolicy.CLASS)
public @interface DeletePhotoAlbumEvent
{
}
