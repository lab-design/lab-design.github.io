package lancs.midp.ptolemy.exceptionblocks.screensAspectEH.annotations;

import java.lang.annotation.*;

@Retention(RetentionPolicy.CLASS)
public @interface NewPhotoViewScreenEvent {

}
