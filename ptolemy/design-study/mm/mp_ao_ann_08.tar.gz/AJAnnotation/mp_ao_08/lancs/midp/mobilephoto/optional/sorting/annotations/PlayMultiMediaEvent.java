package lancs.midp.mobilephoto.optional.sorting.annotations;

import java.lang.annotation.*;

@Retention(RetentionPolicy.CLASS)
public @interface PlayMultiMediaEvent
{
}
