package lancs.midp.mobilephoto.alternative.video.annotations;

import java.lang.annotation.*;

@Retention(RetentionPolicy.CLASS)
public @interface HandleCommandEvent
{
}
