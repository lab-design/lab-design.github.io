package lancs.midp.mobilephoto.alternative.photoMusic.annotations;

import java.lang.annotation.*;

@Retention(RetentionPolicy.CLASS)
public @interface GoToPreviousEvent
{
}
