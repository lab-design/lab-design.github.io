package lancs.midp.mobilephoto.optional.favourites.annotations;

import java.lang.annotation.*;

@Retention(RetentionPolicy.CLASS)
public @interface AppendEvent
{
}
