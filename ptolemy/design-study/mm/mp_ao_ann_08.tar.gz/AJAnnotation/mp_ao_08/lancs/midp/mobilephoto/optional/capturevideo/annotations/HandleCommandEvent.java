package lancs.midp.mobilephoto.optional.capturevideo.annotations;

import java.lang.annotation.*;

@Retention(RetentionPolicy.CLASS)
public @interface HandleCommandEvent
{
}
