package lancs.midp.mobilephoto.optional.copyPhoto.annotations;

import java.lang.annotation.*;

@Retention(RetentionPolicy.CLASS)
public @interface HandleCommandEvent
{
}
