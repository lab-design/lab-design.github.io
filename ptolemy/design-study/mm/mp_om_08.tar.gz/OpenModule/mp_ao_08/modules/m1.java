/*****************/
/* photo package */
/*****************/
module Photo {
	class lancs.midp.mobilephoto.alternative.photo.*;


	/* PhotoViewScreen */
	expose
		: lancs.midp.aspects.exceptionblocks.SCreensAspectEH.PhotoViewScreenConstructor(ubc.midp.mobilephoto.core.ui.datamodel.AlbumData, String);

	expose
		: lancs.midp.mobilephoto.optional.copyPhoto.CopyPhotoAspect.constructor(javax.microedition.lcdui.Image);


	/* MediaController */
	expose
		: lancs.midp.mobilephoto.optional.sorting.CountViewsAspect.showImage(ubc.midp.mobilephoto.core.ui.controller.MediaController, String);
}


/*****************/
/* video package */
/*****************/
module Video {
	class lancs.midp.mobilephoto.alternative.video.*;


	/* PlayVideoController */
	expose
		: lancs.midp.mobilephoto.optional.copyPhoto.CopyPhotoAndVideo.newMediaController(String);

	expose
		: lancs.midp.mobilephoto.optional.copyPhoto.CopyPhotoAndVideo.handleCommandAction(lancs.midp.mobilephoto.optional.copyPhoto.CopyPhotoTargets, javax.microedition.lcdui.Command);


	/* PlayVideoScreen */
	expose
		: lancs.midp.mobilephoto.optional.copyPhoto.CopyPhotoAndVideo.initForm(lancs.midp.mobilephoto.alternative.video.PlayVideoScreen);
}


/*****************/
/* music package */
/*****************/
module Music {
	class lancs.midp.mobilephoto.alternative.music.*;


	/* MusicPlayController */
	expose
		: lancs.midp.mobilephoto.optional.copyPhoto.CopyPhotoAndMusic.newMediaController(String);

	expose
		: lancs.midp.mobilephoto.optional.copyPhoto.CopyPhotoAndMusic.handleCommandAction(lancs.midp.mobilephoto.optional.copyPhoto.CopyPhotoTargets, javax.microedition.lcdui.Command);


	/* PlayMediaScreen */
	expose
		: lancs.midp.mobilephoto.optional.copyPhoto.CopyPhotoAndMusic.initForm(lancs.midp.mobilephoto.alternative.music.PlayMediaScreen);


	/* MediaController */
	// NOTE: this is here because it is an introduced method
	expose to lancs.midp.mobilephoto.optional.sorting.CountViewsAspect
		: execution(boolean ubc.midp.mobilephoto.core.ui.controller.MediaController.playMultiMedia(String));


	/* MultiMediaData */
	expose
		: lancs.midp.mobilephoto.optional.favourites.FavouritesAspect.newMultiMediaData(lancs.midp.mobilephoto.alternative.musicvideo.MultiMediaData, ubc.midp.mobilephoto.core.ui.datamodel.MediaData, String);

	expose
		: lancs.midp.mobilephoto.optional.sorting.CountViewsAspect.newMultiMediaData(lancs.midp.mobilephoto.alternative.musicvideo.MultiMediaData, ubc.midp.mobilephoto.core.ui.datamodel.MediaData, String);


	/* MusicMediaUtil */
	expose
		: lancs.midp.aspects.exceptionblocks.UtilAspectEH.getBytesFromMediaInfo();
}


/***************************/
/* photomusicvideo package */
/***************************/
module PhotoMusicVideo {
	class lancs.midp.mobilephoto.alternative.photomusicvideo.*;
}


/*********************/
/* datamodel package */
/*********************/
module DataModel {
	class ubc.midp.mobilephoto.core.ui.datamodel.*;
	friend lancs.midp.mobilephoto.optional.favourites.FavouritesAspect;
	friend lancs.midp.mobilephoto.optional.sorting.CountViewsAspect;


	/* MediaAccessor */
	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.addMediaData();

	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.loadMediaDataFromRMS();

	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.updateMediaInfoExec();

	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.loadMediaBytesFromRMS();

	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.deleteSingleMediaFromRMS();

	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.deleteAlbum();

	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.getAlbumNames();


	/* AlbumData */
	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.getMedias();

	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.resetMediaData();

	expose
		: lancs.midp.aspects.exceptionblocks.ControllerAspectEH.handleCommand1(String, ubc.midp.mobilephoto.core.ui.controller.AlbumController);
}


/******************************************/
/* allow ITDs in SmsOrCapturePhotoOrVideo */
/******************************************/
module SmsOrCapturePhotoOrVideoITD {
	open MusicVideoPhotoITD;
	friend lancs.midp.mobilephoto.optional.smsorcapturephotoorvideo.SmsOrCapturePhotoOrVideo;
	friend lancs.midp.mobilephoto.optional.smsorcapturephoto.SmSOrCapturePhoto;
}


/*******************************************************/
/* allow ITDs in MusicAspect, VideoAspect, PhotoAspect */
/*******************************************************/
module MusicVideoPhotoITD {
	friend lancs.midp.mobilephoto.alternative.music.MusicAspect;
	friend lancs.midp.mobilephoto.alternative.video.VideoAspect;
	friend lancs.midp.mobilephoto.alternative.photo.PhotoAspect;
	open Controller;
	open SMSITD;
	open PhotoMusicVideo;
	open CopyPhotoITD;
}


/***************************/
/* allow ITDs in SMSAspect */
/***************************/
module SMSITD {
	open Photo;
	open Screens;
	friend lancs.midp.mobilephoto.optional.sms.SMSAspect;
}


/***************************/
/* allow ITDs in CopyPhoto */
/***************************/
module CopyPhotoITD {
	friend lancs.midp.mobilephoto.optional.copyPhoto.CopyPhotoAspect;
	friend lancs.midp.mobilephoto.optional.copyPhoto.CopyPhotoAndVideo;
	friend lancs.midp.mobilephoto.optional.copyPhoto.CopyPhotoAndMusic;
	open DataModel;
	open Music;
	open Video;
}


/************************************/
/* allow ITDs in CaptureVideoAspect */
/************************************/
module CaptureVideoITD {
	class lancs.midp.mobilephoto.optional.capturephotoandvideo.*;
	friend lancs.midp.mobilephoto.optional.capturevideo.CaptureVideoAspect;
}


/************************************/
/* allow ITDs in CapturePhotoAspect */
/************************************/
module CapturePhotoITD {
	open SMS;
	open CaptureVideoITD;
	friend lancs.midp.mobilephoto.optional.capturephoto.CapturePhotoAspect;
}


/**************/
/* ui package */
/**************/
module UI {
	class ubc.midp.mobilephoto.core.ui.*;


	/* MainUIMidlet */
	expose
		: lancs.midp.mobilephoto.optional.sms.SMSAspect.startApplication(ubc.midp.mobilephoto.core.ui.MainUIMidlet);

	expose
		: lancs.midp.mobilephoto.alternative.photoMusic.PhotoAndMusicAspect.startApp(ubc.midp.mobilephoto.core.ui.MainUIMidlet);

	expose
		: lancs.midp.mobilephoto.alternative.music.MusicAspect.startApp(ubc.midp.mobilephoto.core.ui.MainUIMidlet);

	expose
		: lancs.midp.mobilephoto.alternative.photo.PhotoAspect.startApp(ubc.midp.mobilephoto.core.ui.MainUIMidlet);

	expose
		: lancs.midp.mobilephoto.alternative.video.VideoAspect.startApp(ubc.midp.mobilephoto.core.ui.MainUIMidlet);

	expose
		: lancs.midp.mobilephoto.alternative.photomusicvideo.PhotoAndMusicAndVideo.startApp(ubc.midp.mobilephoto.core.ui.MainUIMidlet);
}


/**********************/
/* controller package */
/**********************/
module Controller {
	class ubc.midp.mobilephoto.core.ui.controller.*;
	friend lancs.midp.mobilephoto.alternative.photomusicvideo.PhotoAndMusicAndVideo;


	/* BaseController */
	expose
		: lancs.midp.mobilephoto.alternative.photoMusic.PhotoAndMusicAspect.goToPreviousScreen(ubc.midp.mobilephoto.core.ui.controller.BaseController);


	/* AlbumController */
	expose
		: lancs.midp.aspects.exceptionblocks.ControllerAspectEH.resetMediaData(ubc.midp.mobilephoto.core.ui.controller.AlbumController);


	/* MediaListController */
	expose
		: lancs.midp.aspects.exceptionblocks.ControllerAspectEH.showMediaList(String, ubc.midp.mobilephoto.core.ui.controller.MediaListController);

	expose
		: lancs.midp.mobilephoto.optional.sorting.CountViewsAspect.appendMedias(ubc.midp.mobilephoto.core.ui.controller.MediaListController, ubc.midp.mobilephoto.core.ui.datamodel.MediaData[], ubc.midp.mobilephoto.core.ui.screens.MediaListScreen);

	expose
		: lancs.midp.mobilephoto.optional.favourites.FavouritesAspect.appendMedias(ubc.midp.mobilephoto.core.ui.controller.MediaListController, ubc.midp.mobilephoto.core.ui.datamodel.MediaData[], ubc.midp.mobilephoto.core.ui.screens.MediaListScreen);


	/* MediaController */
	expose
		: lancs.midp.aspects.exceptionblocks.ControllerAspectEH.showImage(ubc.midp.mobilephoto.core.ui.controller.MediaController);

	expose
		: lancs.midp.mobilephoto.optional.sorting.CountViewsAspect.showImage(ubc.midp.mobilephoto.core.ui.controller.MediaController, String);

	expose
		: lancs.midp.mobilephoto.optional.sorting.CountViewsAspect.handleCommandAction(ubc.midp.mobilephoto.core.ui.controller.MediaController, javax.microedition.lcdui.Command);

	expose
		: lancs.midp.mobilephoto.optional.favourites.FavouritesAspect.handleCommandAction(ubc.midp.mobilephoto.core.ui.controller.MediaController, javax.microedition.lcdui.Command);

	expose
		: lancs.midp.mobilephoto.optional.sms.SMSAspect.getMediaController(ubc.midp.mobilephoto.core.ui.controller.MediaController, String);

	expose
		: lancs.midp.mobilephoto.optional.copyPhoto.CopyPhotoAspect.getMediaController(ubc.midp.mobilephoto.core.ui.controller.MediaController, String);
}


/*********************/
/* copyPhoto package */
/*********************/
module SMS {
	class lancs.midp.mobilephoto.optional.copyPhoto.*;


	/* PhotoViewController */
	expose
		: lancs.midp.mobilephoto.optional.smsorcapturephotoorvideo.SmsOrCapturePhotoOrVideo.processCopy(lancs.midp.mobilephoto.optional.copyPhoto.PhotoViewController, ubc.midp.mobilephoto.core.ui.screens.AddMediaToAlbum);

	expose
		: lancs.midp.mobilephoto.optional.smsorcapturephotoorvideo.SmsOrCapturePhotoOrVideo.processImageData(lancs.midp.mobilephoto.optional.copyPhoto.PhotoViewController, String, String);
}


/****************/
/* util package */
/****************/
module Util {
	class ubc.midp.mobilephoto.core.util.*;


	/* MediaUtil */
	expose
		: lancs.midp.aspects.exceptionblocks.UtilAspectEH.readInternalMediaAsByteArrayEx();

	expose
		: lancs.midp.aspects.exceptionblocks.UtilAspectEH.getMediaInfoFromBytes();

	expose
		: lancs.midp.aspects.exceptionblocks.UtilAspectEH.getBytesFromMediaInfo();

	expose
		: lancs.midp.mobilephoto.optional.sorting.CountViewsAspect.createMediaData(ubc.midp.mobilephoto.core.util.MediaUtil, String, String, String, int, String);

	expose
		: lancs.midp.mobilephoto.optional.sorting.CountViewsAspect.getBytesFromImageInfo(ubc.midp.mobilephoto.core.ui.datamodel.MediaData);

	expose
		: lancs.midp.mobilephoto.optional.favourites.PersisteFavoritesAspect.getBytesFromImageInfo(ubc.midp.mobilephoto.core.ui.datamodel.MediaData);

	expose
		: lancs.midp.mobilephoto.optional.favourites.FavouritesAspect.createMediaData(ubc.midp.mobilephoto.core.util.MediaUtil, String, String, String, int, String);
}


/*******************/
/* screens package */
/*******************/
module Screens {
	class ubc.midp.mobilephoto.core.ui.screens.*;


	/* AlbumListScreen */
	expose
		: lancs.midp.mobilephoto.alternative.photoMusic.PhotoOrMusicAspect.initMenu(ubc.midp.mobilephoto.core.ui.screens.AlbumListScreen);

	expose
		: lancs.midp.mobilephoto.alternative.photomusicvideo.PhotoOrMusicOrVideo.initMenu(ubc.midp.mobilephoto.core.ui.screens.AlbumListScreen);


	/* MediaListScreen */
	expose
		: lancs.midp.mobilephoto.optional.sorting.CountViewsAspect.initMenu(ubc.midp.mobilephoto.core.ui.screens.MediaListScreen);

	expose
		: lancs.midp.mobilephoto.optional.favourites.FavouritesAspect.append(ubc.midp.mobilephoto.core.ui.controller.MediaListController, ubc.midp.mobilephoto.core.ui.datamodel.MediaData);

	expose
		: lancs.midp.mobilephoto.optional.favourites.FavouritesAspect.initMenu(ubc.midp.mobilephoto.core.ui.screens.MediaListScreen);

	expose
		: lancs.midp.mobilephoto.alternative.photo.PhotoAspect.initMenu(ubc.midp.mobilephoto.core.ui.screens.MediaListScreen);

	expose
		: lancs.midp.mobilephoto.alternative.photo.PhotoAspect.constructor(ubc.midp.mobilephoto.core.ui.controller.AbstractController);

	expose
		: lancs.midp.mobilephoto.optional.capturevideo.CaptureVideoAspect.initMenu(ubc.midp.mobilephoto.core.ui.screens.MediaListScreen);

	expose
		: lancs.midp.mobilephoto.optional.capturephoto.CapturePhotoAspect.initMenu(ubc.midp.mobilephoto.core.ui.screens.MediaListScreen);

	expose
		: lancs.midp.mobilephoto.alternative.video.VideoAspect.initMenu(ubc.midp.mobilephoto.core.ui.screens.MediaListScreen);

	expose
		: lancs.midp.mobilephoto.alternative.video.VideoAspect.constructor(ubc.midp.mobilephoto.core.ui.controller.AbstractController);
}
