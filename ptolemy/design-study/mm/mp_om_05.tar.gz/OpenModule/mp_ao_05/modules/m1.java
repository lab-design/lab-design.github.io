/*********************/
/* datamodel package */
/*********************/
module DataModel {
	class ubc.midp.mobilephoto.core.ui.datamodel.*;
	friend lancs.midp.mobilephoto.optional.copyPhoto.CopyPhotoAspect;
	friend lancs.midp.mobilephoto.optional.favourites.FavouritesAspect;
	friend lancs.midp.mobilephoto.optional.sorting.CountViewsAspect;


	/* ImageAccessor */
	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.addImageData();

	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.loadImageDataFromRMS();

	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.updateImageInfoExec();

	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.loadImageBytesFromRMS();

	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.deleteSingleImageFromRMS();

	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.deletePhotoAlbum();

	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.getAlbumNames();

	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.getImageFromRecordStore(String, ubc.midp.mobilephoto.core.ui.datamodel.AlbumData);


	/* AlbumData */
	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.getImages();

	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.getImageFromRecordStoreEx();

	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.deleteImage(String, String, ubc.midp.mobilephoto.core.ui.datamodel.AlbumData);

	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.resetImageData();

	expose
		: lancs.midp.aspects.exceptionblocks.ControllerAspectEH.handleCommand1(String, ubc.midp.mobilephoto.core.ui.controller.AlbumController);
}


/**********************/
/* controller package */
/**********************/
module Controller {
	class ubc.midp.mobilephoto.core.ui.controller.*;


	/* AlbumController */
	expose
		: lancs.midp.aspects.exceptionblocks.ControllerAspectEH.resetImageData(ubc.midp.mobilephoto.core.ui.controller.AlbumController);


	/* PhotoListController */
	expose
		: lancs.midp.aspects.exceptionblocks.ControllerAspectEH.showImageList(String, ubc.midp.mobilephoto.core.ui.controller.PhotoListController);

	expose
		: lancs.midp.mobilephoto.optional.sorting.CountViewsAspect.appendImages(ubc.midp.mobilephoto.core.ui.controller.PhotoListController, ubc.midp.mobilephoto.core.ui.datamodel.ImageData[], ubc.midp.mobilephoto.core.ui.screens.PhotoListScreen);

	expose
		: lancs.midp.mobilephoto.optional.favourites.FavouritesAspect.appendImages(ubc.midp.mobilephoto.core.ui.controller.PhotoListController, ubc.midp.mobilephoto.core.ui.datamodel.ImageData[], ubc.midp.mobilephoto.core.ui.screens.PhotoListScreen);


	/* PhotoController */
	expose
		: lancs.midp.aspects.exceptionblocks.ControllerAspectEH.showImage(ubc.midp.mobilephoto.core.ui.controller.PhotoController);

	expose
		: lancs.midp.mobilephoto.optional.sorting.CountViewsAspect.showImage(ubc.midp.mobilephoto.core.ui.controller.PhotoController, String);

	expose
		: lancs.midp.mobilephoto.optional.sorting.CountViewsAspect.handleCommandAction(ubc.midp.mobilephoto.core.ui.controller.PhotoController, javax.microedition.lcdui.Command);

	expose
		: lancs.midp.mobilephoto.optional.favourites.FavouritesAspect.handleCommandAction(ubc.midp.mobilephoto.core.ui.controller.PhotoController, javax.microedition.lcdui.Command);

	expose
		: lancs.midp.mobilephoto.optional.copyPhoto.CopyPhotoAspect.setPhotoScreen(ubc.midp.mobilephoto.core.ui.controller.PhotoController, String, ubc.midp.mobilephoto.core.ui.screens.PhotoViewScreen);
}


/****************/
/* util package */
/****************/
module Util {
	class ubc.midp.mobilephoto.core.util.*;


	/* ImageUtil */
	expose
		: lancs.midp.aspects.exceptionblocks.UtilAspectEH.readInternalImageAsByteArrayEx();

	expose
		: lancs.midp.aspects.exceptionblocks.UtilAspectEH.getImageInfoFromBytes();

	expose
		: lancs.midp.aspects.exceptionblocks.UtilAspectEH.getBytesFromImageInfo();

	expose
		: lancs.midp.mobilephoto.optional.sorting.CountViewsAspect.createImageData(ubc.midp.mobilephoto.core.util.ImageUtil, String, String, String, int, String);

	expose
		: lancs.midp.mobilephoto.optional.sorting.CountViewsAspect.getBytesFromImageInfo(ubc.midp.mobilephoto.core.ui.datamodel.ImageData);

	expose
		: lancs.midp.mobilephoto.optional.favourites.PersisteFavoritesAspect.getBytesFromImageInfo(ubc.midp.mobilephoto.core.ui.datamodel.ImageData);

	expose
		: lancs.midp.mobilephoto.optional.favourites.FavouritesAspect.createImageData(ubc.midp.mobilephoto.core.util.ImageUtil, String, String, String, int, String);
}


/*******************/
/* screens package */
/*******************/
module Screens {
	class ubc.midp.mobilephoto.core.ui.screens.*;


	/* PhotoViewScreen */
	expose
		: lancs.midp.aspects.exceptionblocks.SCreensAspectEH.PhotoViewScreenConstructor(ubc.midp.mobilephoto.core.ui.datamodel.AlbumData, String);

	expose
		: lancs.midp.mobilephoto.optional.copyPhoto.CopyPhotoAspect.constructor(javax.microedition.lcdui.Image);


	/* PhotoListScreen */
	expose
		: lancs.midp.mobilephoto.optional.sorting.CountViewsAspect.initMenu(ubc.midp.mobilephoto.core.ui.screens.PhotoListScreen);

	expose
		: lancs.midp.mobilephoto.optional.favourites.FavouritesAspect.append(ubc.midp.mobilephoto.core.ui.controller.PhotoListController, ubc.midp.mobilephoto.core.ui.datamodel.ImageData);

	expose
		: lancs.midp.mobilephoto.optional.favourites.FavouritesAspect.initMenu(ubc.midp.mobilephoto.core.ui.screens.PhotoListScreen);
}
