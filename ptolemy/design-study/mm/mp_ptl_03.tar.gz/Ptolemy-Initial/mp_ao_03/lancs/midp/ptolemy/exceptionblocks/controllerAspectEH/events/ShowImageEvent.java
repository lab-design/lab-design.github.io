package lancs.midp.ptolemy.exceptionblocks.controllerAspectEH.events;

import javax.microedition.midlet.MIDlet;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;

public void event ShowImageEvent {
	MIDlet midlet;
	AlbumData album;
	String selectedImageName;
}
