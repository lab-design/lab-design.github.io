/*****************/
/* music package */
/*****************/
module Music {
	class lancs.midp.mobilephoto.alternative.music.*;
	friend lancs.midp.mobilephoto.optional.copyPhoto.CopyPhotoAspect;
	open DataModel;


	/* MusicPlayController */
	expose
		: lancs.midp.mobilephoto.optional.copyPhoto.CopyPhotoAspect.newMusicPlayController(lancs.midp.mobilephoto.alternative.music.MusicPlayController, String);


	/* MediaController */
	// FIXME - NOTE: this is here because it is an introduced method
	expose to lancs.midp.mobilephoto.optional.sorting.CountViewsAspect
		: execution(boolean ubc.midp.mobilephoto.core.ui.controller.MediaController.playMultiMedia(String));


	/* MultiMediaData */
	expose
		: lancs.midp.mobilephoto.optional.favourites.FavouritesAspect.newMultiMediaData(lancs.midp.mobilephoto.alternative.music.MultiMediaData, ubc.midp.mobilephoto.core.ui.datamodel.MediaData, String);

	expose
		: lancs.midp.mobilephoto.optional.sorting.CountViewsAspect.newMultiMediaData(lancs.midp.mobilephoto.alternative.music.MultiMediaData, ubc.midp.mobilephoto.core.ui.datamodel.MediaData, String);

	expose
		: lancs.midp.aspects.exceptionblocks.UtilAspectEH.getBytesFromMediaInfo();
}


/*********************/
/* datamodel package */
/*********************/
module DataModel {
	class ubc.midp.mobilephoto.core.ui.datamodel.*;
	friend lancs.midp.mobilephoto.optional.favourites.FavouritesAspect;
	friend lancs.midp.mobilephoto.optional.sorting.CountViewsAspect;


	/* MediaAccessor */
	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.addMediaData();

	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.loadMediaDataFromRMS();

	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.updateMediaInfoExec();

	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.loadMediaBytesFromRMS();

	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.deleteSingleMediaFromRMS();

	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.deleteAlbum();

	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.getAlbumNames();


	/* AlbumData */
	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.getMedias();

	expose
		: lancs.midp.aspects.exceptionblocks.DataModelAspectEH.resetMediaData();

	expose
		: lancs.midp.aspects.exceptionblocks.ControllerAspectEH.handleCommand1(String, ubc.midp.mobilephoto.core.ui.controller.AlbumController);
}


/***************************/
/* allow ITDs in SMSAspect */
/***************************/
module SMSITD {
	friend lancs.midp.mobilephoto.optional.sms.SMSAspect;
	open Music;
	open Screens;
}


/*****************************/
/* allow ITDs in PhotoAspect */
/*****************************/
module PhotoITD {
	friend lancs.midp.mobilephoto.alternative.photo.PhotoAspect;
	open Controller;
}


/*****************************/
/* allow ITDs in MusicAspect */
/*****************************/
module MusicITD {
	friend lancs.midp.mobilephoto.alternative.music.MusicAspect;
	open PhotoITD;
	// FIXME - this is wrong
	//open Screens;
	open SMSITD;
}


/**************/
/* ui package */
/**************/
module UI {
	class ubc.midp.mobilephoto.core.ui.*;


	/* MainUIMidlet */
	expose
		: lancs.midp.mobilephoto.optional.sms.SMSAspect.startApplication(ubc.midp.mobilephoto.core.ui.MainUIMidlet);

	expose
		: lancs.midp.mobilephoto.alternative.photoMusic.PhotoAndMusicAspect.startApp(ubc.midp.mobilephoto.core.ui.MainUIMidlet);

	expose
		: lancs.midp.mobilephoto.alternative.music.MusicAspect.startApp(ubc.midp.mobilephoto.core.ui.MainUIMidlet);

	expose
		: lancs.midp.mobilephoto.alternative.photo.PhotoAspect.startApp(ubc.midp.mobilephoto.core.ui.MainUIMidlet);
}


/**********************/
/* controller package */
/**********************/
module Controller {
	class ubc.midp.mobilephoto.core.ui.controller.*;


	/* BaseController */
	expose
		: lancs.midp.mobilephoto.alternative.photoMusic.PhotoAndMusicAspect.goToPreviousScreen(ubc.midp.mobilephoto.core.ui.controller.BaseController);


	/* AlbumController */
	expose
		: lancs.midp.aspects.exceptionblocks.ControllerAspectEH.resetMediaData(ubc.midp.mobilephoto.core.ui.controller.AlbumController);


	/* MediaListController */
	expose
		: lancs.midp.aspects.exceptionblocks.ControllerAspectEH.showMediaList(String, ubc.midp.mobilephoto.core.ui.controller.MediaListController);

	expose
		: lancs.midp.mobilephoto.optional.sorting.CountViewsAspect.appendMedias(ubc.midp.mobilephoto.core.ui.controller.MediaListController, ubc.midp.mobilephoto.core.ui.datamodel.MediaData[], ubc.midp.mobilephoto.core.ui.screens.MediaListScreen);

	expose
		: lancs.midp.mobilephoto.optional.favourites.FavouritesAspect.appendMedias(ubc.midp.mobilephoto.core.ui.controller.MediaListController, ubc.midp.mobilephoto.core.ui.datamodel.MediaData[], ubc.midp.mobilephoto.core.ui.screens.MediaListScreen);


	/* MediaController */
	expose
		: lancs.midp.aspects.exceptionblocks.ControllerAspectEH.showImage(ubc.midp.mobilephoto.core.ui.controller.MediaController);

	expose
		: lancs.midp.mobilephoto.optional.sorting.CountViewsAspect.showImage(ubc.midp.mobilephoto.core.ui.controller.MediaController, String);

	expose
		: lancs.midp.mobilephoto.optional.sorting.CountViewsAspect.handleCommandAction(ubc.midp.mobilephoto.core.ui.controller.MediaController, javax.microedition.lcdui.Command);

	expose
		: lancs.midp.mobilephoto.optional.favourites.FavouritesAspect.handleCommandAction(ubc.midp.mobilephoto.core.ui.controller.MediaController, javax.microedition.lcdui.Command);

	expose
		: lancs.midp.mobilephoto.optional.sms.SMSAspect.getMediaController(ubc.midp.mobilephoto.core.ui.controller.MediaController, String);

	expose
		: lancs.midp.mobilephoto.optional.copyPhoto.CopyPhotoAspect.getMediaController(ubc.midp.mobilephoto.core.ui.controller.MediaController, String);
}


/*********************/
/* copyPhoto package */
/*********************/
module SMS {
	class lancs.midp.mobilephoto.optional.copyPhoto.*;


	/* PhotoViewController */
	expose
		: lancs.midp.mobilephoto.optional.sms.SMSAspect.processCopy(lancs.midp.mobilephoto.optional.copyPhotoOrSMS.PhotoViewController, ubc.midp.mobilephoto.core.ui.screens.AddMediaToAlbum);

	expose
		: lancs.midp.mobilephoto.optional.sms.SMSAspect.processImageData(lancs.midp.mobilephoto.optional.copyPhotoOrSMS.PhotoViewController, String, String);

	expose
		: lancs.midp.mobilephoto.optional.sms.SMSAspect.addImageData();
}


/****************/
/* util package */
/****************/
module Util {
	class ubc.midp.mobilephoto.core.util.*;


	/* MediaUtil */
	expose
		: lancs.midp.aspects.exceptionblocks.UtilAspectEH.readInternalMediaAsByteArrayEx();

	expose
		: lancs.midp.aspects.exceptionblocks.UtilAspectEH.getMediaInfoFromBytes();

	expose
		: lancs.midp.aspects.exceptionblocks.UtilAspectEH.getBytesFromMediaInfo();

	expose
		: lancs.midp.mobilephoto.optional.sorting.CountViewsAspect.createMediaData(ubc.midp.mobilephoto.core.util.MediaUtil, String, String, String, int, String);

	expose
		: lancs.midp.mobilephoto.optional.sorting.CountViewsAspect.getBytesFromImageInfo(ubc.midp.mobilephoto.core.ui.datamodel.MediaData);

	expose
		: lancs.midp.mobilephoto.optional.favourites.PersisteFavoritesAspect.getBytesFromImageInfo(ubc.midp.mobilephoto.core.ui.datamodel.MediaData);

	expose
		: lancs.midp.mobilephoto.optional.favourites.FavouritesAspect.createMediaData(ubc.midp.mobilephoto.core.util.MediaUtil, String, String, String, int, String);
}


/*******************/
/* screens package */
/*******************/
module Screens {
	class ubc.midp.mobilephoto.core.ui.screens.*;


	/* PhotoViewScreen */
	expose
		: lancs.midp.aspects.exceptionblocks.SCreensAspectEH.PhotoViewScreenConstructor(ubc.midp.mobilephoto.core.ui.datamodel.AlbumData, String);

	expose
		: lancs.midp.mobilephoto.optional.copyPhoto.CopyPhotoAspect.constructor(javax.microedition.lcdui.Image);


	/* AlbumListScreen */
	expose
		: lancs.midp.mobilephoto.alternative.photoMusic.PhotoOrMusicAspect.initMenu(ubc.midp.mobilephoto.core.ui.screens.AlbumListScreen);


	/* MediaListScreen */
	expose
		: lancs.midp.mobilephoto.optional.sorting.CountViewsAspect.initMenu(ubc.midp.mobilephoto.core.ui.screens.MediaListScreen);

	expose
		: lancs.midp.mobilephoto.optional.favourites.FavouritesAspect.append(ubc.midp.mobilephoto.core.ui.controller.MediaListController, ubc.midp.mobilephoto.core.ui.datamodel.MediaData);

	expose
		: lancs.midp.mobilephoto.optional.favourites.FavouritesAspect.initMenu(ubc.midp.mobilephoto.core.ui.screens.MediaListScreen);

	expose
		: lancs.midp.mobilephoto.alternative.photo.PhotoAspect.initMenu(ubc.midp.mobilephoto.core.ui.screens.MediaListScreen);

	expose
		: lancs.midp.mobilephoto.alternative.photo.PhotoAspect.constructor(ubc.midp.mobilephoto.core.ui.controller.AbstractController);
}
