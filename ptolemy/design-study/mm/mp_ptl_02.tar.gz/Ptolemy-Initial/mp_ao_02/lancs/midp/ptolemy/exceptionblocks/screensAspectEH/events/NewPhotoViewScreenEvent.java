package lancs.midp.ptolemy.exceptionblocks.screensAspectEH.events;

public void event NewPhotoViewScreenEvent {
}
