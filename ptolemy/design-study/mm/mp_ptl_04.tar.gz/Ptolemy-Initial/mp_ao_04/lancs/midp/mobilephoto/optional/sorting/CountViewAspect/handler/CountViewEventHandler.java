package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.handler;

import java.util.Hashtable;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;

import ubc.midp.mobilephoto.core.ui.controller.BaseController;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import ubc.midp.mobilephoto.core.ui.datamodel.ImageData;
import ubc.midp.mobilephoto.core.ui.screens.PhotoListScreen;
import ubc.midp.mobilephoto.core.util.Constants;

import lancs.midp.mobilephoto.lib.exceptions.ImageNotFoundException;
import lancs.midp.mobilephoto.lib.exceptions.NullAlbumDataReference;
import ubc.midp.mobilephoto.core.util.ImageUtil;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.events.*;
import lancs.midp.ptolemy.exceptionblocks.controllerAspectEH.events.*;
import lancs.midp.ptolemy.exceptionblocks.utilAspectEH.events.*;
import edu.iastate.cs.ptolemy.runtime.*;

@Instantiation(Instantiation.Model.SINGLETON)
@Registration(Registration.Model.IMPLICIT)
@PrecedesHandler(lancs.midp.mobilephoto.optional.favourites.handler.PersisteFavoritesEventHandler.class)
public class CountViewEventHandler {
	
	
	public static boolean sort = false;
	public static final Command sortCommand = new Command("Sort by Views", Command.ITEM, 1);
	
	// [EF] Added in the scenario 02 
	private int ImageData.numberOfViews = 0;
	
	/**
	 * [EF] Added in the scenario 02 
	 */
	public void ImageData.increaseNumberOfViews() {
		this.numberOfViews++;
	}

	/**
	 * [EF] Added in the scenario 02 
	 * @return the numberOfViews
	 */
	public int ImageData.getNumberOfViews() {
		return numberOfViews;
	}
	
	/**
	 * [EF] Added in the scenario 02 
	 * @param views
	 */
	public void ImageData.setNumberOfViews(int views) {
		this.numberOfViews = views;
	}

	public CountViewEventHandler() {
		register(this);
	}

	public void handler(ShowImageEvent next) throws Throwable {
		invoke(next);
		
			ImageData image = next.album.getImageAccessor().getImageInfo(next.selectedImageName);
			image.numberOfViews = new Integer(image.numberOfViews+1);
			next.album.getImageAccessor().updateImageInfo(image, image);
			System.out.println("<* BaseController.handleCommand() *> Image = "+next.selectedImageName+ "; # views = "
					+image.numberOfViews);
	}
	
	when ShowImageEvent do handler;

	public void handler(InitMenuEvent next)throws Throwable{
		invoke(next);
		next.screen.addCommand(CountViewEventHandler.sortCommand);
	}
	
	when InitMenuEvent do handler;	

	public String handler(GetBytesFromImageInfoEvent next) throws Throwable {
		String byteString = invoke(next);
		
		// [EF] Added in scenatio 02
		byteString = byteString.concat(ImageUtil.DELIMITER);
		byteString = byteString.concat("" + next.ii.numberOfViews);
		
		return byteString;
	}
	
	when GetBytesFromImageInfoEvent do handler;


	public ImageData handler(CreateImageDataEvent next) throws Throwable {

		int endIndex = next.endIndex;
		int startIndex = endIndex + 1;
		endIndex = next.iiString.indexOf(ImageUtil.DELIMITER, startIndex);
		
		if (endIndex == -1)
			endIndex = next.iiString.length();
		
		// [EF] Added in the scenario 02 
		int numberOfViews = 0;
		try {
			numberOfViews = Integer.parseInt(next.iiString.substring(startIndex, endIndex));
		} catch (RuntimeException e) {
			numberOfViews = 0;
			e.printStackTrace();
		}
		
		ImageData imageData = invoke(next);
		
		imageData.numberOfViews = new Integer(numberOfViews);

		return imageData;
	}
	
	when CreateImageDataEvent do handler;

	public boolean handler(CommandActionEvent next)throws Throwable
	{ 
		boolean handled = invoke(next);
		
		if (handled) return true;
		
		String label = next.c.getLabel();
		System.out.println("<* CountViewsAspect.around handleCommandAction *> ::handleCommand: " + label);
		
		/** Case: Sort photos by number of views
		 * [EF] Added in the scenario 02 **/
		if (label.equals("Sort by Views")) {
			// TODO set sort = true
			sort = true;
			next.controller.showImageList(next.controller.getCurrentStoreName());
			next.controller.setCurrentStoreName( Constants.IMAGELIST_SCREEN );
			return true;
		}
		return false;
	}
	
	when CommandActionEvent do handler;

	public void handler(AppendImagesEvent next) throws Throwable{
		
		if (CountViewEventHandler.sort) {
			bubbleSort(next.images);
		}
		CountViewEventHandler.sort = false;
		
		invoke(next);
	}

	private void bubbleSort(ImageData[] images) {
		System.out.print("Sorting by BubbleSort...");		
		for (int end = images.length; end > 1; end --) {
			for (int current = 0; current < end - 1; current ++) {
				if (images[current].numberOfViews > images[current+1].numberOfViews) {
					exchange(images, current, current+1);
				}
			}
		}
		System.out.println("done.");
	}
	private void exchange(ImageData[] images, int pos1, int pos2) {
		ImageData tmp = images[pos1];
		images[pos1] = images[pos2];
		images[pos2] = tmp;
	}

	
	when AppendImagesEvent do handler;

	

	
}
