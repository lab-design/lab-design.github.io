package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.events;

import ubc.midp.mobilephoto.core.ui.datamodel.ImageData;

public void event AppendImagesEvent {
	ImageData[] images;
}
