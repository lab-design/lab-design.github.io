package lancs.midp.ptolemy.exceptionblocks.utilAspectEH.events;

import ubc.midp.mobilephoto.core.ui.datamodel.ImageData;

public String event GetBytesFromImageInfoEvent {
	ImageData ii;
}
