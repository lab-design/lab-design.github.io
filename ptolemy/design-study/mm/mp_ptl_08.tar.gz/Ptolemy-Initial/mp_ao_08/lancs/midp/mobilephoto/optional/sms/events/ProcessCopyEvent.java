package lancs.midp.mobilephoto.optional.sms.events;

import lancs.midp.mobilephoto.optional.copyPhoto.MediaViewController;
import ubc.midp.mobilephoto.core.ui.screens.AddMediaToAlbum;

public void event ProcessCopyEvent
{
	MediaViewController photoViewController;
	AddMediaToAlbum copyPhotoToAlbum;
}
