package lancs.midp.mobilephoto.alternative.music.handler;

import java.io.InputStream;
import java.util.HashMap;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.TextField;

import lancs.midp.mobilephoto.alternative.music.*;
import lancs.midp.mobilephoto.lib.exceptions.ImageNotFoundException;
import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;
import lancs.midp.mobilephoto.lib.exceptions.InvalidImageDataException;
import lancs.midp.mobilephoto.lib.exceptions.ImagePathNotValidException;
import javax.microedition.rms.RecordStoreFullException;
import ubc.midp.mobilephoto.core.ui.controller.*;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import ubc.midp.mobilephoto.core.ui.datamodel.MediaData;
import lancs.midp.mobilephoto.alternative.musicvideo.*;
import ubc.midp.mobilephoto.core.ui.screens.*;
import lancs.midp.mobilephoto.optional.sms.events.*;
import lancs.midp.mobilephoto.alternative.music.events.*;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.events.*;
import lancs.midp.mobilephoto.alternative.photomusicvideo.SelectMediaController;
import edu.iastate.cs.ptolemy.runtime.*;

@Instantiation(Instantiation.Model.SINGLETON)
@Registration(Registration.Model.IMPLICIT)
@PrecedesHandler(lancs.midp.mobilephoto.alternative.video.handler.VideoAspectHandler.class)
public class MusicAspectHandler {
	public static BaseController musicRootController;
	
	public static AlbumData musicModel;

	public MusicAspectHandler() { register(this); }

	public BaseController SelectMediaController.musicController;
	public AlbumData SelectMediaController.musicAlbumData;
	
	public BaseController SelectMediaController.getMusicController() {
		return musicController;
	}

	public void SelectMediaController.setMusicController(BaseController musicController) {
		musicController = musicController;
	}

	public AlbumData SelectMediaController.getMusicAlbumData() {
		return musicAlbumData;
	}

	public void SelectMediaController.setMusicAlbumData(AlbumData musicAlbumData) {
		musicAlbumData = musicAlbumData;
	}

	// [NC] Added in the scenario 07
	public boolean MediaController.playMultiMedia(String selectedMediaName) {
		InputStream storedMusic = null;
		try {
			MediaData mymedia = getAlbumData().getMediaInfo(selectedMediaName);
			if (mymedia instanceof MultiMediaData)
			{
				storedMusic = ((MusicAlbumData) getAlbumData()).getMusicFromRecordStore(getCurrentStoreName(), selectedMediaName);
				PlayMediaScreen playscree = new PlayMediaScreen(midlet, storedMusic, ((MultiMediaData)mymedia).getTypeMedia(), this);
				MusicPlayController controller = new MusicPlayController(midlet, getAlbumData(), (AlbumListScreen) getAlbumListScreen(), playscree);
				setNextController(controller);
			}
			return true;
		} catch (ImageNotFoundException e) {
			Alert alert = new Alert( "Error", "The selected item was not found in the mobile device", null, AlertType.ERROR);
			Display.getDisplay(midlet).setCurrent(alert, Display.getDisplay(midlet).getCurrent());
		    return false;
		} 
		catch (PersistenceMechanismException e) {
			Alert alert = new Alert( "Error", "The mobile database can open this item 1", null, AlertType.ERROR);
			Display.getDisplay(midlet).setCurrent(alert, Display.getDisplay(midlet).getCurrent());
			return false;
		}
	
	}
	
	// ********  MediaListScreen  ********* //
	
	// [NC] Added in the scenario 07: to support more than one screen purpose
	public static final int PLAYMUSIC = 2;
	
	// [NC] Added in the scenario 07
	public static final Command playCommand = new Command("Play", Command.ITEM, 1);
	

	// [NC] Added in the scenario 07
	TextField AddMediaToAlbum.itemtype = new TextField("Type of media", "", 20, TextField.ANY);

	// [NC] Added in the scenario 07
	public String AddMediaToAlbum.getItemType() {
		return itemtype.getString();
	}

	public void handler(StartApplicationEvent next) throws Throwable {
		invoke(next);

		MusicAspectHandler.musicModel = new MusicAlbumData();
		
		// [NC] Added in the scenario 07
		AlbumListScreen albumMusic = new AlbumListScreen();
		MusicAspectHandler.musicRootController = new BaseController(next.middlet, MusicAspectHandler.musicModel, albumMusic);
		
		MediaListController musicListController = new MediaListController(next.middlet, MusicAspectHandler.musicModel, albumMusic);
		musicListController.setNextController(MusicAspectHandler.musicRootController);
		
		AlbumController albumMusicController = new AlbumController(next.middlet, MusicAspectHandler.musicModel, albumMusic);
		albumMusicController.setNextController(musicListController);
		albumMusic.setCommandListener(albumMusicController);
		
		MusicAspectHandler.musicRootController.init(MusicAspectHandler.musicModel);
	}
	when StartApplicationEvent do handler;

	public void handler(AddMediaToAlbumCreatedEvent next) throws Throwable {
		invoke(next);
		next.screen.append(next.screen.getItemType());
	}
	when AddMediaToAlbumCreatedEvent do handler;

	public void handler(AddNewMediaToAlbumEvent next) throws Throwable {
		try {
			if (next.albumData instanceof MusicAlbumData){
				next.albumData.loadMediaDataFromRMS( next.controller.getCurrentStoreName());
				MediaData mymedia = next.albumData.getMediaInfo(next.label);
				MultiMediaData mmedi = new MultiMediaData(mymedia, ((AddMediaToAlbum) next.controller.getCurrentScreen()).getItemType());
				next.albumData.updateMediaInfo(mymedia, mmedi);
			}
		} catch (InvalidImageDataException e) {
			Alert alert = null;
			if (e instanceof ImagePathNotValidException)
				alert = new Alert("Error", "The path is not valid", null, AlertType.ERROR);
			else
				alert = new Alert("Error", "The file format is not valid", null, AlertType.ERROR);
			Display.getDisplay(next.controller.midlet).setCurrent(alert, Display.getDisplay(next.controller.midlet).getCurrent());
		} catch (PersistenceMechanismException e) {
			Alert alert = null;
			if (e.getCause() instanceof RecordStoreFullException)
				alert = new Alert("Error", "The mobile database is full", null, AlertType.ERROR);
			else
				alert = new Alert("Error", "The mobile database can not add a new photo", null, AlertType.ERROR);
			Display.getDisplay(next.controller.midlet).setCurrent(alert, Display.getDisplay(next.controller.midlet).getCurrent());
			
		} catch (ImageNotFoundException e) {
			Alert alert = new Alert("Error", "The selected item was not found in the mobile device", null, AlertType.ERROR);
			Display.getDisplay(next.controller.midlet).setCurrent(alert, Display.getDisplay(next.controller.midlet).getCurrent());
		//		return true; // TODO [EF] This should be the return value from method handleCommandAction.
		}

		// TODO [EF] Replicated handlers from the method handleCommandAction in MediaController. 
		// TODO Nelio, try to reuse these handlers somehow
	}
	when AddNewMediaToAlbumEvent do handler;

	public boolean handler(CommandActionEvent next) throws Throwable {
		boolean handled = invoke(next);
		
		if (handled) return true;
		
		String label = next.c.getLabel();
		System.out.println("<* MusicAspect.around handleCommandAction *> ::handleCommand: " + label);
		
		// [NC] Added in the scenario 07
		if (label.equals("Play")) {
			String selectedMediaName = ((MediaController)next.controller).getSelectedMediaName();
			return ((MediaController)next.controller).playMultiMedia(selectedMediaName);		
		}
		
		return false;
	}
	when CommandActionEvent do handler;

	public void handler(InitMenuEvent next) throws Throwable {
		invoke(next);
		if (next.screen.getTypeOfScreen() == MusicAspectHandler.PLAYMUSIC)
			next.screen.addCommand(MusicAspectHandler.playCommand);
	}
	when InitMenuEvent do handler;

	public MediaListScreen handler(MediaListScreenCreatedEvent next) throws Throwable {
		MediaListScreen listScreen = invoke(next);
		if (next.controller.getAlbumData() instanceof MusicAlbumData)
			listScreen.setTypeOfScreen(MusicAspectHandler.PLAYMUSIC);
		return listScreen;
	}
	when MediaListScreenCreatedEvent do handler;
}
