package lancs.midp.ptolemy.exceptionblocks.dataModelAspectEH.events;

import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;

public void event DeleteImageEvent {
	AlbumData album;
}
