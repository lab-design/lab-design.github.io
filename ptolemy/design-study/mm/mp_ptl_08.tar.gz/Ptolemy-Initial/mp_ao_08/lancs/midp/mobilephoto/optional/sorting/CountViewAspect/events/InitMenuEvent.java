package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.events;

import ubc.midp.mobilephoto.core.ui.screens.MediaListScreen;

public void event InitMenuEvent {
	MediaListScreen screen;
}
