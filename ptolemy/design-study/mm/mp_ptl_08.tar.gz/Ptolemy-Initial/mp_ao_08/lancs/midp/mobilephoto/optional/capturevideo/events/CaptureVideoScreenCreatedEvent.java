package lancs.midp.mobilephoto.optional.capturevideo.events;

import lancs.midp.mobilephoto.optional.capturephotoandvideo.CaptureVideoScreen;

public void event CaptureVideoScreenCreatedEvent {
	CaptureVideoScreen listScreen;
}
