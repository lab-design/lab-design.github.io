package lancs.midp.mobilephoto.optional.capturevideo.handler;

import java.io.ByteArrayOutputStream;

import javax.microedition.lcdui.Command;
import javax.microedition.media.control.RecordControl;

import ubc.midp.mobilephoto.core.ui.controller.MediaController;
import ubc.midp.mobilephoto.core.ui.screens.AlbumListScreen;
import ubc.midp.mobilephoto.core.ui.screens.MediaListScreen;
import lancs.midp.mobilephoto.optional.capturephotoandvideo.CaptureVideoScreen;
import lancs.midp.mobilephoto.optional.capturevideo.events.*;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.events.*;
import lancs.midp.mobilephoto.optional.capturevideo.*;
import lancs.midp.mobilephoto.alternative.video.handler.*;
import edu.iastate.cs.ptolemy.runtime.*;

@Instantiation(Instantiation.Model.SINGLETON)
@Registration(Registration.Model.IMPLICIT)
public class CaptureVideoAspectHandler {
	public static Command start = new Command("Start", Command.EXIT, 1);
	public static Command stop = new Command("Stop", Command.ITEM, 1);
	
	void CaptureVideoAspectHandler() { register(this); }

	public void handler(CaptureVideoScreenCreatedEvent next) throws Throwable {
		// [NC] Added in the scenario 08
		if (next.listScreen.typescreen == CAPTUREVIDEO){
			next.listScreen.addCommand(start);
			next.listScreen.addCommand(stop);
		}
	}
	when CaptureVideoScreenCreatedEvent do handler;
	
	public void CaptureVideoScreen.startCapture() {
		try {
			if (!recording) {
				rControl = (RecordControl) capturePlayer
						.getControl("RecordControl");
				if (rControl == null)
					throw new Exception("No RecordControl found!");
				byteOfArray = new ByteArrayOutputStream();
				rControl.setRecordStream(byteOfArray);
				rControl.startRecord();
				recording = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void CaptureVideoScreen.pauseCapture() {
		try {
			if (recording) {
				rControl.stopRecord();
				rControl.commit();
				recording = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public byte[] CaptureVideoScreen.getByteArrays() {
		return byteOfArray.toByteArray();
	}
	
	// ********  MediaListScreen  ********* //
	
	// [NC] Added in the scenario 08 
	public static Command captureVideoCommand = new Command("Capture Video", Command.ITEM, 1);
	
	public void handler(InitMenuEvent next) throws Throwable {
		// [NC] Added in the scenario 08 
		if (next.screen.getTypeOfScreen() == VideoAspectHandler.PLAYVIDEO)
		{		next.screen.addCommand(captureVideoCommand);
		}
	}
	when InitMenuEvent do handler;
	
	// ********  MediaController  ********* //
	
	public boolean handler(CommandActionEvent next) throws Throwable {
		boolean handled = invoke(next);
		
		if (handled) return true;
		
		String label = next.c.getLabel();
		System.out.println("<* CaptureVideoAspect.around handleCommandAction *> ::handleCommand: " + label);
		
		if (label.equals("Capture Video")) {
			
			CaptureVideoScreen playscree = new CaptureVideoScreen(next.controller.midlet, CAPTUREVIDEO);
			playscree.setVisibleVideo();
			VideoCaptureController newcontroller = new VideoCaptureController(next.controller.midlet, next.controller.getAlbumData(), (AlbumListScreen) next.controller.getAlbumListScreen(), playscree);
			next.controller.setNextController(newcontroller);
			playscree.setCommandListener(next.controller);
			return true;		
		}
		
		return false;
	}
	when CommandActionEvent do handler;
	
	// ********  CaptureVideoScreen  ********* //
	
	public final static int CAPTUREVIDEO = 2;
	
}
