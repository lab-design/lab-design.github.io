package lancs.midp.mobilephoto.alternative.music.events;

import ubc.midp.mobilephoto.core.ui.controller.AbstractController;
import ubc.midp.mobilephoto.core.ui.screens.MediaListScreen;
import lancs.midp.mobilephoto.alternative.music.MusicAlbumData;
import lancs.midp.mobilephoto.alternative.music.handler.MusicAspectHandler;

public MediaListScreen event MediaListScreenCreatedEvent {
	AbstractController controller;

}
