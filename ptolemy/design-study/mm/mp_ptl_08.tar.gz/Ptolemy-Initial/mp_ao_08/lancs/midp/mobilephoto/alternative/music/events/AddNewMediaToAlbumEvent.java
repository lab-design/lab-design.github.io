package lancs.midp.mobilephoto.alternative.music.events;

import ubc.midp.mobilephoto.core.ui.controller.MediaController;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;

public void event AddNewMediaToAlbumEvent {
	String label;
	AlbumData albumData;
	MediaController controller;
}
