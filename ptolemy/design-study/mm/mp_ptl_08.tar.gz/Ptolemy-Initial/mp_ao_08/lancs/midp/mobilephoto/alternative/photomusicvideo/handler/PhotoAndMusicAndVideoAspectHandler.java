package lancs.midp.mobilephoto.alternative.photoMusic.handler;

import javax.microedition.lcdui.Display;

import lancs.midp.mobilephoto.alternative.music.handler.MusicAspectHandler;
import lancs.midp.mobilephoto.alternative.photo.handler.PhotoAspectHandler;
import lancs.midp.mobilephoto.alternative.video.handler.VideoAspectHandler;
import lancs.midp.mobilephoto.alternative.photomusicvideo.SelectMediaController;
import lancs.midp.mobilephoto.alternative.photomusicvideo.SelectTypeOfMedia;
import ubc.midp.mobilephoto.core.ui.controller.BaseController;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import ubc.midp.mobilephoto.core.ui.screens.AlbumListScreen;
import lancs.midp.mobilephoto.optional.sms.events.*;
import ubc.midp.mobilephoto.core.ui.controller.ScreenSingleton;
import ubc.midp.mobilephoto.core.util.Constants;
import lancs.midp.mobilephoto.alternative.photoMusic.events.*;
import edu.iastate.cs.ptolemy.runtime.*;

@Instantiation(Instantiation.Model.SINGLETON)
@Registration(Registration.Model.IMPLICIT)
@PrecedesHandler(lancs.midp.mobilephoto.optional.sms.handler.SMSAspectHandler.class)
public class PhotoAndMusicAndVideoAspectHandler {
	private static SelectTypeOfMedia mainscreen;
	
	public PhotoAndMusicAndVideoAspectHandler() { register(this); }

	public static SelectTypeOfMedia getMainMenu(){
		return mainscreen;
	}
	
	public static void setMainMenu(SelectTypeOfMedia screen){
		mainscreen = screen;
	}

	public boolean handler(GoToPreviousEvent next) throws Throwable {
		boolean returned = invoke(next);
		if (returned) return true;
		
    	String currentScreenName = ScreenSingleton.getInstance().getCurrentScreenName();
		// [NC] Added in the scenario 07
		if ((currentScreenName == null) || (currentScreenName.equals(Constants.ALBUMLIST_SCREEN))) {	
			next.controller.setCurrentScreen(getMainMenu() );
			return true;
		}
		return false;
	}
	when GoToPreviousEvent do handler;

	public void handler(StartApplicationEvent next) throws Throwable {
		invoke(next);
		
		System.out.println("Start after photoandall ..."+next.middlet);
		BaseController imageRootController = PhotoAspectHandler.imageRootController;
		AlbumData imageModel = PhotoAspectHandler.imageModel;

		BaseController musicRootController = MusicAspectHandler.musicRootController;
		AlbumData musicModel = MusicAspectHandler.musicModel;
		
		BaseController videoRootController = VideoAspectHandler.videoRootController;
		AlbumData videoModel = VideoAspectHandler.videoModel;
		System.out.println("Obteve as referencias ");
		AlbumListScreen albumListScreen = (AlbumListScreen)imageRootController.getAlbumListScreen();
		
		// [NC] Added in the scenario 07
		System.out.println("Vai criar o selectmediacontroller ");
		SelectMediaController selectcontroller = new SelectMediaController(next.middlet, imageModel, albumListScreen);
		selectcontroller.setNextController(imageRootController);
		
		selectcontroller.setImageAlbumData(imageModel);
		selectcontroller.setImageController(imageRootController);
		
		selectcontroller.setMusicAlbumData(musicModel);
		selectcontroller.setMusicController(musicRootController);
		
		selectcontroller.setVideoAlbumData(videoModel);
		selectcontroller.setVideoController(videoRootController);
		System.out.println("Vai definir a tela principal");
		SelectTypeOfMedia mainscreen = new SelectTypeOfMedia();
		System.out.println("Crio a tela");
		mainscreen.initMenu();
		System.out.println("apagou os itens");
		mainscreen.append("Photos",null);
		mainscreen.append("Music",null);
		mainscreen.append("Videos",null);
		System.out.println("definiu os items");
		mainscreen.setCommandListener(selectcontroller);
		System.out.println("definiu o controler");
		Display.getDisplay(next.middlet).setCurrent(mainscreen);
		System.out.println("definiu a tela");
		setMainMenu(mainscreen);
		
		System.out.println("finish after photoandall ...");
	}
	when StartApplicationEvent do handler;
}
