package lancs.midp.mobilephoto.optional.sms.events;

public void event AddImageDataEvent {
}
