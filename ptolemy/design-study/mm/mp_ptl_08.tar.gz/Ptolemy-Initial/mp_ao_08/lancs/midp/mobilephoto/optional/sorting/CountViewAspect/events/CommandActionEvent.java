package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.events;

import javax.microedition.lcdui.Command;
import ubc.midp.mobilephoto.core.ui.controller.AbstractController;

public boolean event CommandActionEvent {
	AbstractController controller;
	Command c;
}
