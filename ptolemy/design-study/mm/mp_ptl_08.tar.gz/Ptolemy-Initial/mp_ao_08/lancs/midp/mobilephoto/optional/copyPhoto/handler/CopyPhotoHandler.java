package lancs.midp.mobilephoto.optional.copyPhoto.handler;

import javax.microedition.lcdui.Command;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;
import javax.microedition.rms.RecordStoreNotOpenException;

import ubc.midp.mobilephoto.core.ui.controller.MediaController;
import ubc.midp.mobilephoto.core.ui.datamodel.MediaAccessor;
import ubc.midp.mobilephoto.core.ui.datamodel.MediaData;
import lancs.midp.mobilephoto.alternative.photo.PhotoViewScreen;
import ubc.midp.mobilephoto.core.util.MediaUtil;
import lancs.midp.mobilephoto.optional.copyPhoto.MediaViewController;
import lancs.midp.mobilephoto.optional.copyPhoto.events.*;
import lancs.midp.ptolemy.exceptionblocks.dataModelAspectEH.events.*;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import edu.iastate.cs.ptolemy.runtime.*;

@Instantiation(Instantiation.Model.SINGLETON)
@Registration(Registration.Model.IMPLICIT)
@PrecedesHandler(lancs.midp.mobilephoto.optional.copyPhoto.handler.CopyPhotoAndVideoHandler.class)
public class CopyPhotoHandler {

	public CopyPhotoHandler() { register(this); }

	/* [EF] Added in scenario 05 */
	public static final Command copyCommand = new Command("Copy", Command.ITEM, 1);
	
	public void AlbumData.addMediaData(MediaData mediaData, String albumname) throws RecordStoreException {
		mediaAccessor.addMediaData(mediaData, albumname); 
	}

	public void MediaAccessor.addMediaData(MediaData mediaData, String albumname) throws RecordStoreException {
		try {
			imageRS = RecordStore.openRecordStore(album_label + albumname, true);
			imageInfoRS = RecordStore.openRecordStore(info_label + albumname, true);
			int rid2; // new record ID for ImageData (metadata)
			rid2 = imageInfoRS.getNextRecordID();
			mediaData.setRecordId(rid2);
			byte[] data1 = this.getByteFromMediaInfo(mediaData);
			imageInfoRS.addRecord(data1, 0, data1.length);
		} catch (RecordStoreException e) {
			throw new PersistenceMechanismException();
		}finally{
			try {
				imageRS.closeRecordStore();
				imageInfoRS.closeRecordStore();
			} catch (RecordStoreNotOpenException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (RecordStoreException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void handler(SetPhotoScreenEvent next)throws Throwable {
		MediaViewController control = new MediaViewController(next.controller.midlet, next.controller.getAlbumData(), next.controller.getAlbumListScreen(), next.imageName);
		control.setNextController(next.controller);
	
		invoke(next);
	}
	when SetPhotoScreenEvent do handler;

	public void handler(PhotoViewScreenCreatedEvent next) throws Throwable {
		invoke(next);
		
		next.f.addCommand(CopyPhotoHandler.copyCommand);
	}
	when PhotoViewScreenCreatedEvent do handler;
}
