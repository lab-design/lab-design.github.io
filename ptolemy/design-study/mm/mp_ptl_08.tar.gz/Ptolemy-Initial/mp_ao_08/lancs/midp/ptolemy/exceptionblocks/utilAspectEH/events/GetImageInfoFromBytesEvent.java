package lancs.midp.ptolemy.exceptionblocks.utilAspectEH.events;

import ubc.midp.mobilephoto.core.ui.datamodel.MediaData;

public MediaData event GetImageInfoFromBytesEvent {
}
