package lancs.midp.mobilephoto.optional.smsorcapturephotoorvideo.handler;

import java.util.Hashtable;
import ubc.midp.mobilephoto.core.ui.datamodel.MediaData;
import ubc.midp.mobilephoto.core.ui.screens.AddMediaToAlbum;
import lancs.midp.mobilephoto.alternative.photo.PhotoViewScreen;
import lancs.midp.mobilephoto.lib.exceptions.InvalidImageDataException;
import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;
import lancs.midp.mobilephoto.optional.copyPhoto.MediaViewController;
import lancs.midp.mobilephoto.optional.sms.events.*;
import lancs.midp.mobilephoto.optional.sms.handler.*;
import lancs.midp.mobilephoto.optional.smsorcapturephoto.handler.*;
import edu.iastate.cs.ptolemy.runtime.*;

@Instantiation(Instantiation.Model.SINGLETON)
@Registration(Registration.Model.IMPLICIT)
public class SmsOrCapturePhotoOrVideoHandler {
	 private byte[] AddMediaToAlbum.CapturedMedia = null;
	 
	 private byte[] PhotoViewScreen.byteImage = null;
	 
	 public byte[] AddMediaToAlbum.getCapturedMedia() {
			return CapturedMedia;
		}

	public void AddMediaToAlbum.setCapturedMedia(byte[] capturedMedia) {
			CapturedMedia = capturedMedia;
	}
	
	public byte[] PhotoViewScreen.getImage(){
		return byteImage;
	}
	
	public void PhotoViewScreen.setImage(byte[] img){
		byteImage = img;
	}
	
	public void SmsOrCapturePhotoOrVideoHandler() { register(this); }

	public void handler(ProcessCopyEvent next) throws Throwable {
		invoke(next);
		if (((PhotoViewScreen)next.photoViewController.getCurrentScreen()).isFromSMS()){
			next.copyPhotoToAlbum.setCapturedMedia(((PhotoViewScreen)next.photoViewController.getCurrentScreen()).getImage());
		}
	}
	when ProcessCopyEvent do handler;

	public void handler(ProcessImageDataEvent next) throws Throwable {
		byte[] imgByte= ((AddMediaToAlbum)next.photoViewController.getCurrentScreen()).getCapturedMedia();
		if (imgByte == null){
			invoke(next);
		}else{
			next.photoViewController.getAlbumData().addImageData(next.photoName, imgByte, next.albumname);
		}		
		return;
	}
	when ProcessImageDataEvent do handler;
}
