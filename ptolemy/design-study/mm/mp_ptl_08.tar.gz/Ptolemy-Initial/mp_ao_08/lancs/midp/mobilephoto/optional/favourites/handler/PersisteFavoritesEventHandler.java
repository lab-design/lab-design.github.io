package lancs.midp.mobilephoto.optional.favourites.handler;

import ubc.midp.mobilephoto.core.ui.datamodel.MediaData;
import ubc.midp.mobilephoto.core.util.MediaUtil;
import lancs.midp.ptolemy.exceptionblocks.utilAspectEH.events.*;
import edu.iastate.cs.ptolemy.runtime.*;

@Instantiation(Instantiation.Model.SINGLETON)
@Registration(Registration.Model.IMPLICIT)
public class PersisteFavoritesEventHandler{
	
	public PersisteFavoritesEventHandler() { register(this); }

	public String handler(GetBytesFromImageInfoEvent next) throws Throwable{
			
			String byteString = invoke(next);
			
			// [EF] Added in scenario 03
			byteString = byteString.concat(MediaUtil.DELIMITER);
			if (next.ii.isFavorite()) byteString = byteString.concat("true");
			else byteString = byteString.concat("false");
			
	//		System.out.println("<* FavouritesAspect.around getBytesFromImageInfo *> ...ends");
			
			return byteString;
	}
	when GetBytesFromImageInfoEvent do handler;
}
