package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.events;

import ubc.midp.mobilephoto.core.ui.datamodel.MediaData;

public MediaData event CreateImageDataEvent {
	String fidString;
	String albumLabel;
	String imageLabel; 
	int endIndex;
	String iiString;
}
