package lancs.midp.mobilephoto.optional.copyPhoto.handler;

import javax.microedition.lcdui.Command;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;
import javax.microedition.rms.RecordStoreNotOpenException;

import ubc.midp.mobilephoto.core.ui.controller.MediaController;
import ubc.midp.mobilephoto.core.ui.datamodel.MediaAccessor;
import ubc.midp.mobilephoto.core.ui.datamodel.MediaData;
import lancs.midp.mobilephoto.alternative.photo.PhotoViewScreen;
import ubc.midp.mobilephoto.core.util.MediaUtil;
import lancs.midp.mobilephoto.lib.exceptions.InvalidImageDataException;
import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;
import lancs.midp.mobilephoto.optional.copyPhoto.MediaViewController;
import lancs.midp.mobilephoto.optional.copyPhoto.events.*;
import edu.iastate.cs.ptolemy.runtime.*;

@Instantiation(Instantiation.Model.SINGLETON)
@Registration(Registration.Model.IMPLICIT)
@PrecedesHandler(lancs.midp.mobilephoto.optional.copyPhoto.handler.CopyPhotoAndMusicHandler.class)
public class CopyPhotoAndVideoHandler extends CopyPhotoHandler{
	/* [EF] Added in scenario 05 */
	public static final Command copyCommand = new Command("Copy", Command.ITEM, 1);

	public CopyPhotoAndVideoHandler() { register(this); }

	public void handler(PlayVideoScreenCreatedEvent next) throws Throwable{
		invoke(next);
		
		next.f.addCommand(CopyPhotoHandler.copyCommand);
	}
	when PlayVideoScreenCreatedEvent do handler;

	public void handler(SetPhotoScreenEvent next)throws Throwable {
		MediaViewController control = new MediaViewController(next.controller.midlet, next.controller.getAlbumData(), next.controller.getAlbumListScreen(), next.imageName);
		control.setNextController(next.controller);
	
		invoke(next);
	}
	when SetPhotoScreenEvent do handler;
}
