package lancs.midp.mobilephoto.optional.copyPhoto.events;

import lancs.midp.mobilephoto.alternative.video.PlayVideoScreen;

public void event PlayVideoScreenCreatedEvent {
	PlayVideoScreen f;
}
