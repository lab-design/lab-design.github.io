package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.events;

import ubc.midp.mobilephoto.core.ui.datamodel.MediaData;

public void event AppendImagesEvent {
	MediaData[] images;
}
