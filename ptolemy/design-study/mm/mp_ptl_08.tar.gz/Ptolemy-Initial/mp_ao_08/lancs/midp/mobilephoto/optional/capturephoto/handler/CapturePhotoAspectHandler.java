package lancs.midp.mobilephoto.optional.capturephoto;

import javax.microedition.lcdui.Command;

import lancs.midp.mobilephoto.optional.smsorcapturephotoorvideo.handler.*;
import lancs.midp.mobilephoto.optional.capturephotoandvideo.CaptureVideoScreen;
import lancs.midp.mobilephoto.optional.copyPhoto.MediaViewController;

import ubc.midp.mobilephoto.core.ui.controller.MediaController;
import ubc.midp.mobilephoto.core.ui.screens.AddMediaToAlbum;
import ubc.midp.mobilephoto.core.ui.screens.AlbumListScreen;
import ubc.midp.mobilephoto.core.ui.screens.MediaListScreen;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import java.util.Hashtable;

import javax.microedition.lcdui.Display;
import lancs.midp.mobilephoto.alternative.photo.handler.*;
import lancs.midp.mobilephoto.optional.capturevideo.events.*;
import lancs.midp.mobilephoto.optional.capturevideo.events.*;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.events.*;
import edu.iastate.cs.ptolemy.runtime.*;

@Instantiation(Instantiation.Model.SINGLETON)
@Registration(Registration.Model.IMPLICIT)
public class CapturePhotoAspectHandler {

	void CapturePhotoAspectHandler() { register(this); }

	// ********  MediaController  ********* //
	public boolean handler(CommandActionEvent next) throws Throwable {
		boolean handled = invoke(next);

		if (handled)
			return true;

		String label = next.c.getLabel();
		System.out
				.println("<* CapturePhotoAspect.around handleCommandAction *> ::handleCommand: "
						+ label);

		if (label.equals("Capture Photo")) {
			CaptureVideoScreen playscree = new CaptureVideoScreen(next.controller.midlet, CAPTUREPHOTO);
			playscree.setVisibleVideo();
			MediaViewController newcontroller = new MediaViewController(next.controller.midlet, next.controller.getAlbumData(), (AlbumListScreen) next.controller.getAlbumListScreen(), "New photo");
			newcontroller.setCpVideoScreen(playscree);
			next.controller.setNextController(newcontroller);
			playscree.setCommandListener(next.controller);
			return true;		
		}
		else if (label.equals("Take photo")){
			System.out.println("Olha para a captura"+((MediaViewController)next.controller).getCpVideoScreen());
			byte[] newfoto = ((MediaViewController)next.controller).getCpVideoScreen().takePicture();
			System.out.println("Obteve a imagem");
			AddMediaToAlbum copyPhotoToAlbum = new AddMediaToAlbum("Copy Photo to Album");
			System.out.println("Crio a screen");
			copyPhotoToAlbum.setPhotoName("New picture");
			copyPhotoToAlbum.setLabelPhotoPath("Copy to Album:");
			copyPhotoToAlbum.setCommandListener(next.controller);
			
			copyPhotoToAlbum.setCapturedMedia(newfoto);
			System.out.println("Definiu a imagem");
	        Display.getDisplay(next.controller.midlet).setCurrent(copyPhotoToAlbum);
			return true;		
		}
		return false;
	}
	when CommandActionEvent do handler;

	// ********  MediaController  ********* //
	private CaptureVideoScreen MediaViewController.cpVideoScreen = null;
	
	public CaptureVideoScreen MediaViewController.getCpVideoScreen() {
		return cpVideoScreen;
	}

	public void MediaViewController.setCpVideoScreen(CaptureVideoScreen cpVideoScreen) {
		this.cpVideoScreen = cpVideoScreen;
	}
	
	// ********  CaptureVideoScreen  ********* //
	
	public static Command takephoto = new Command("Take photo", Command.EXIT, 1);

	public final static int CAPTUREPHOTO = 1;

	public void handler(CaptureVideoScreenCreatedEvent next) throws Throwable {
		// [NC] Added in the scenario 08
		if (next.listScreen.typescreen == CAPTUREPHOTO){
			next.listScreen.addCommand(takephoto);
		}
	}
	when CaptureVideoScreenCreatedEvent do handler;

	public byte[] CaptureVideoScreen.takePicture() {
		try {
				Alert alert = new Alert("Error", "The mobile database is full", null, AlertType.INFO);
				alert.setTimeout(5000);
				display.setCurrent(alert);
				byte[] imageArray = videoControl.getSnapshot(null);

				return imageArray;

			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}
	
	// ********  MediaListScreen  ********* //
	
	// [NC] Added in the scenario 08 
	public static Command capturePhotoCommand = new Command("Capture Photo", Command.ITEM, 1);
	
	public void handler(InitMenuEvent next) throws Throwable {
		// [NC] Added in the scenario 08 
		if (next.screen.getTypeOfScreen() == PhotoAspectHandler.SHOWPHOTO)
		{		next.screen.addCommand(capturePhotoCommand);
		}
	}
	when InitMenuEvent do handler;
}
