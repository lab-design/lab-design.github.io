/*
 * Created on Sep 28, 2004
 */
package ubc.midp.mobilephoto.core.ui.datamodel;

import java.io.IOException;
import java.util.Hashtable;

import javax.microedition.lcdui.Image;
import javax.microedition.rms.RecordStoreException;

import lancs.midp.mobilephoto.lib.exceptions.ImageNotFoundException;
import lancs.midp.mobilephoto.lib.exceptions.InvalidImageDataException;
import lancs.midp.mobilephoto.lib.exceptions.InvalidPhotoAlbumNameException;
import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;
import lancs.midp.mobilephoto.lib.exceptions.UnavailablePhotoAlbumException;

import ubc.midp.mobilephoto.core.ui.datamodel.MediaData;
import lancs.midp.ptolemy.exceptionblocks.dataModelAspectEH.events.*;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.events.*;

/**
 * @author tyoung
 * 
 * This class represents the data model for Photo Albums. A Photo Album object
 * is essentially a list of photos or images, stored in a Hashtable. Due to
 * constraints of the J2ME RecordStore implementation, the class stores a table
 * of the images, indexed by an identifier, and a second table of image metadata
 * (ie. labels, album name etc.)
 * 
 * This uses the ImageAccessor class to retrieve the image data from the
 * recordstore (and eventually file system etc.)
 */
public abstract class AlbumData {

	// [EF] Scenario 02 changed modifier public to private and generate get and set methods.
	// [EF] As a result, aspect DataModelAspectEH has to be changed.
	protected MediaAccessor mediaAccessor;

	/**
	 *  Load any photo albums that are currently defined in the record store
	 */
	public String[] getAlbumNames() {

		//Shouldn't load all the albums each time
		//Add a check somewhere in ImageAccessor to see if they've been
		//loaded into memory already, and avoid the extra work...
		String albums[] = null;
		try {
			announce GetAlbumNamesEvent()
			{
				mediaAccessor.loadAlbums();
				albums = mediaAccessor.getAlbumNames();
			}
		} catch (RecordStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return albums;
	}

	/**
	 *  Get the names of all images for a given Photo Album that exist in the Record Store.
	 * @throws UnavailablePhotoAlbumException 
	 * @throws InvalidImageDataException 
	 * @throws PersistenceMechanismException 
	 */
	public MediaData[] getMedias(String recordName) throws UnavailablePhotoAlbumException {

		MediaData[] result = null;
		try {
			announce GetImageNamesEvent()
			{
				result = mediaAccessor.loadMediaDataFromRMS(recordName);
			}
		} catch (RecordStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;

	}

	/**
	 *  Define a new user photo album. This results in the creation of a new
	 *  RMS Record store.
	 * @throws PersistenceMechanismException 
	 * @throws InvalidPhotoAlbumNameException 
	 */
	public void createNewAlbum(String albumName) throws PersistenceMechanismException, InvalidPhotoAlbumNameException {
		try {
			mediaAccessor.createNewAlbum(albumName);
		} catch (RecordStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void deleteAlbum(String albumName) throws PersistenceMechanismException {
		try {
			mediaAccessor.deleteAlbum(albumName);
		} catch (RecordStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void addNewMediaToAlbum(String label, String path, String album) throws InvalidImageDataException, PersistenceMechanismException {
		try {
			mediaAccessor.addMediaData(label, path, album);
		} catch (RecordStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 *  Delete a photo from the photo album. This permanently deletes the image from the record store
	 * @throws PersistenceMechanismException 
	 * @throws InvalidPhotoAlbumNameException 
	 */
	public void deleteMedia(String mediaName, String storeName) throws PersistenceMechanismException, ImageNotFoundException {
		try {
			announce DeleteImageEvent(this)
			{
				mediaAccessor.deleteSingleMediaFromRMS(mediaName, storeName);
			}
		} catch (RecordStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 *  Reset the image data for the application. This is a wrapper to the ImageAccessor.resetImageRecordStore
	 *  method. It is mainly used for testing purposes, to reset device data to the default album and photos.
	 * @throws PersistenceMechanismException
	 */
	public void resetMediaData() throws PersistenceMechanismException {
		try {
			announce ResetImageDataEvent()
			{
				mediaAccessor.resetMediaRecordStore();
			}
		} catch (RecordStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Get the hashtable that stores the image metadata in memory.
	 * @return Returns the imageInfoTable.
	 */
	public MediaData getMediaInfo(String mediaName) throws ImageNotFoundException {
		return mediaAccessor.getMediaInfo(mediaName);
	}

	/**
	 * Update the hashtable that stores the image metadata in memory
	 * @param imageInfoTable
	 *            The imageInfoTable to set.
	 */
	public MediaData[] loadMediaDataFromRMS(String recordName) {
		return mediaAccessor.loadMediaDataFromRMS(recordName);
	}

	public boolean updateMediaInfo(MediaData oldData, MediaData newData) {
		return mediaAccessor.updateMediaInfo(oldData, newData);
	}

	public byte[] loadMediaBytesFromRMS(String recordName, int recordId) {
		return mediaAccessor.loadMediaBytesFromRMS(recordName, recordId);
	}

	/**
	 * [EF] Add in order to have access to ImageData
	 * @param imageAccessor
	 */
	public void setMediaAccessor(MediaAccessor mediaAccessor) {
		this.mediaAccessor = mediaAccessor;
	}

	/**
	 * [EF] Add in order to have access to ImageData
	 * @return
	 */
	public MediaAccessor getMediaAccessor() {
		return mediaAccessor;
	}
}
