package ubc.midp.mobilephoto.core.ui.screens;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.TextField;
import lancs.midp.mobilephoto.alternative.music.handler.*;
import lancs.midp.mobilephoto.alternative.music.events.*;

public class AddMediaToAlbum extends Form {
	
	TextField labeltxt = new TextField("Photo label", "", 15, TextField.ANY);
	TextField photopathtxt = new TextField("Path", "", 20, TextField.ANY);
	
	Command ok;
	Command cancel;

	public AddMediaToAlbum(String title) {
		super(title);
		this.append(labeltxt);
		this.append(photopathtxt);
		ok = new Command("Save Add Photo", Command.SCREEN, 0);
		cancel = new Command("Cancel", Command.EXIT, 1);
		this.addCommand(ok);
		this.addCommand(cancel);
		
		itemtype = new TextField("Type of media", "", 20, TextField.ANY);
		announce AddMediaToAlbumCreatedEvent(this) {}
	}
	
	public String getPhotoName(){
		return labeltxt.getString();
	}

	public void setPhotoName(String photoName) {
		labeltxt.setString(photoName);
	}
	
	public String getPath() {
		return photopathtxt.getString();
	}

	public void setLabelPhotoPath(String label) {
		photopathtxt.setLabel(label);
	}
}
