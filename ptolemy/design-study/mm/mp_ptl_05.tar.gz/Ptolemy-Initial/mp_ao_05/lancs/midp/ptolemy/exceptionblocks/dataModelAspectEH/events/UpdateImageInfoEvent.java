package lancs.midp.ptolemy.exceptionblocks.dataModelAspectEH.events;

public void event UpdateImageInfoEvent {
}
