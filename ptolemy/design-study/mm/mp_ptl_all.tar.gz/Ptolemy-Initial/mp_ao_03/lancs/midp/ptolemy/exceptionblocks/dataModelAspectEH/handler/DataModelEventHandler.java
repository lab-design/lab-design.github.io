package lancs.midp.ptolemy.exceptionblocks.dataModelAspectEH.handler;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Image;
import javax.microedition.rms.RecordStoreFullException;

import lancs.midp.mobilephoto.lib.exceptions.*;
import ubc.midp.mobilephoto.core.ui.controller.BaseController;
import lancs.midp.ptolemy.exceptionblocks.dataModelAspectEH.events.*;
import ubc.midp.mobilephoto.core.ui.datamodel.*;
import javax.microedition.rms.RecordStoreException;
import javax.microedition.rms.RecordStoreNotOpenException;
import edu.iastate.cs.ptolemy.runtime.*;

@Instantiation(Instantiation.Model.SINGLETON)
@Registration(Registration.Model.IMPLICIT)
public class DataModelEventHandler {
	
	public DataModelEventHandler() { register(this); }

	public void handler(GetAlbumNamesEvent next) throws Throwable {
		try {
			invoke(next);
		} catch (InvalidImageDataException e) {
			e.printStackTrace();
		} catch (PersistenceMechanismException e) {
			e.printStackTrace();
		}
	}
	
	when GetAlbumNamesEvent do handler;
	
	public void handler(UpdateImageInfoEvent next) throws Throwable {
		try {
			invoke(next);
		} catch (RecordStoreNotOpenException e) {
			// do nothing
		}
	}
	
	when UpdateImageInfoEvent do handler;
	
	public void handler(ResetImageDataEvent next) throws Throwable {
		try {
			invoke(next);
		} catch (InvalidImageDataException e) {
			e.printStackTrace();
		}
	}
	
	when ResetImageDataEvent do handler;
	
	public void handler(RecordStoreExceptionEvent next) throws Throwable {
		try {
			invoke(next);
		} catch (RecordStoreException e) {
			throw new PersistenceMechanismException(e);
		}
	}
	when RecordStoreExceptionEvent do handler;
	
	public void handler(GetImageNamesEvent next) throws Throwable {
		try {
			invoke(next);
		} catch (PersistenceMechanismException e) {
			throw new UnavailablePhotoAlbumException(e);
		} catch (InvalidImageDataException e) {
			throw new UnavailablePhotoAlbumException(e);
		}
	}
	
	when GetImageNamesEvent do handler;
	
	public Image handler(GetImageFromRecordStoreEvent next) throws Throwable {
		try {
			return invoke(next);
		} catch (NullAlbumDataReference e) {
			next.album.setImageAccessor(new ImageAccessor(next.album));
			return null;
		} catch (ImageNotFoundException e) {
			Alert alert = new Alert( "Error", "The selected image can not be found", null, AlertType.ERROR);
			alert.setTimeout(5000);
			return null;
		} catch (PersistenceMechanismException e) {
			Alert alert = new Alert( "Error", "It was not possible to recover the selected image", null, AlertType.ERROR);
			alert.setTimeout(5000);
			return null;
		}
	}
	
	when GetImageFromRecordStoreEvent do handler;
	
	public void handler(DeleteImageEvent next) throws Throwable {
		try {
			invoke(next);
		} catch (NullAlbumDataReference e) {
			next.album.setImageAccessor(new ImageAccessor(next.album));
			e.printStackTrace();
		} 
	}
	
	when DeleteImageEvent do handler;
}

