package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.events;

import javax.microedition.lcdui.Command;
import ubc.midp.mobilephoto.core.ui.controller.BaseController;

public boolean event CommandActionEvent {
	BaseController controller;
	Command c;
}
