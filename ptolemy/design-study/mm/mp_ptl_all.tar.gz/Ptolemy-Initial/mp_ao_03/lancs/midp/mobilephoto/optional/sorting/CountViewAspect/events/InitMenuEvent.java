package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.events;

import ubc.midp.mobilephoto.core.ui.screens.PhotoListScreen;

public void event InitMenuEvent {
	PhotoListScreen screen;
}
