package lancs.midp.mobilephoto.optional.sms.events;

import ubc.midp.mobilephoto.core.ui.screens.PhotoViewScreen;

public void event LoadImageEvent {
	
	PhotoViewScreen screen; 

}
