package lancs.midp.mobilephoto.optional.sms.handler;

import java.util.HashMap;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Image;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;

import ubc.midp.mobilephoto.core.ui.datamodel.ImageAccessor;
import ubc.midp.mobilephoto.core.ui.datamodel.ImageData;
import ubc.midp.mobilephoto.core.ui.screens.AddPhotoToAlbum;
import ubc.midp.mobilephoto.core.ui.screens.PhotoViewScreen;
import ubc.midp.mobilephoto.core.util.ImageUtil;

import lancs.midp.mobilephoto.lib.exceptions.InvalidImageDataException;
import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;
import lancs.midp.ptolemy.exceptionblocks.dataModelAspectEH.events.*;
import lancs.midp.mobilephoto.optional.copyPhoto.events.*;

import lancs.midp.mobilephoto.optional.sms.events.*;
import ubc.midp.mobilephoto.sms.*;
import edu.iastate.cs.ptolemy.runtime.*;

@Instantiation(Instantiation.Model.SINGLETON)
@Registration(Registration.Model.IMPLICIT)
@PrecedesHandler(lancs.midp.mobilephoto.optional.copyPhoto.handler.CopyPhotoHandler.class)
public class SMSAspectHandler {
	public static final Command smscopyCommand = new Command("Send Photo by SMS", Command.ITEM, 1);
	public static Image img = null;
	
	private Image AddPhotoToAlbum.image = null;
	
	public Image AddPhotoToAlbum.getImage() {
		return image;
	}

	public void AddPhotoToAlbum.setImage(Image image) {
		this.image = image;
	}

	private boolean PhotoViewScreen.fromSMS = false;
	
	public Image PhotoViewScreen.getImage(){
		return image;
	}
	public boolean PhotoViewScreen.isFromSMS() {
		return fromSMS;
	}
	public void PhotoViewScreen.setFromSMS(boolean fromSMS) {
		this.fromSMS = fromSMS;
	}

	public SMSAspectHandler() { register(this); }

	public byte[] ImageAccessor.getByteFromImage(Image img){
		int w = img.getWidth();
		int h = img.getHeight();
		int data_int[] = new int[ w * h ];
		img.getRGB( data_int, 0, w, 0, 0, w, h );
		byte[] data_byte = new byte[ w * h * 3 ];
		for ( int i = 0; i < w * h; ++i )
		{
		int color = data_int[ i ];
		int offset = i * 3;
		data_byte[ offset ] = ( byte ) ( ( color & 0xff0000 ) >> 16 );
		data_byte[ offset +
		1 ] = ( byte ) ( ( color & 0xff00 ) >> 8 );
		data_byte[ offset + 2 ] = ( byte ) ( ( color & 0xff ) );
		}
		return data_byte;
	}
	
	public void ImageAccessor.addImageData(String photoname, Image imgdata, String albumname)
				throws InvalidImageDataException, PersistenceMechanismException {
		try {
			imageRS = RecordStore.openRecordStore(ALBUM_LABEL + albumname, true);
			imageInfoRS = RecordStore.openRecordStore(INFO_LABEL + albumname, true);
			int rid; // new record ID for Image (bytes)
			int rid2; // new record ID for ImageData (metadata)
				
			ImageUtil converter = new ImageUtil();
			
			byte[] data1 = getByteFromImage(imgdata);
			rid = imageRS.addRecord(data1, 0, data1.length);
			ImageData ii = new ImageData(rid, ImageAccessor.ALBUM_LABEL	+ albumname, photoname);
			rid2 = imageInfoRS.getNextRecordID();				
			ii.setRecordId(rid2);
			String data1String = converter.getBytesFromImageInfo(ii); 
			data1 = data1String.getBytes();
			imageInfoRS.addRecord(data1, 0, data1.length);
			
			imageRS.closeRecordStore();
			
			imageInfoRS.closeRecordStore();
		} catch (RecordStoreException e) {
			throw new PersistenceMechanismException();
		}
	}

	public void handler(StartApplicationEvent next)throws Throwable{
		invoke(next);
		SmsReceiverController controller = new SmsReceiverController(next.middlet, next.middlet.model, next.middlet.album);
		controller.setNextController(next.middlet.albumController);
		SmsReceiverThread smsR = new SmsReceiverThread(next.middlet, next.middlet.model, next.middlet.album, controller);
		System.out.println("SmsController::Starting SMSReceiver Thread");
		new Thread(smsR).start();
	}
	when StartApplicationEvent do handler;

	public void handler(ProcessImageDataEvent next)throws Throwable{
		ImageData imageData = null;
		img = null;
		
		img = ((AddPhotoToAlbum)next.photoViewController.getCurrentScreen()).getImage();
		if (img == null){
//			imageData = invoke(next);
			invoke(next);
		}
		if (img != null){
			next.imageAccessor.addImageData(next.photoName, img, next.albumname);
		}		

		return;
//		return imageData;
	}
	when ProcessImageDataEvent do handler;

	public void handler(ProcessCopyEvent next)throws Throwable{
		invoke(next);
		
		if (((PhotoViewScreen)next.photoViewController.getCurrentScreen()).isFromSMS()){
			next.copyPhotoToAlbum.setImage(((PhotoViewScreen)next.photoViewController.getCurrentScreen()).getImage());
		}
	}
	when ProcessCopyEvent do handler;

	public void handler(PhotoViewScreenCreatedEvent next)throws Throwable{
		invoke(next);
		next.f.addCommand(smscopyCommand);
	}
	when PhotoViewScreenCreatedEvent do handler;

	public void handler(LoadImageEvent next)throws Throwable{
		if (next.screen.fromSMS){
		   return;
		}
		else 
		{
		   invoke(next);
		}
	}
	when LoadImageEvent do handler;

	public void handler(GetPhotoControllerEvent next)throws Throwable{
		invoke(next);
		SmsSenderController smscontroller = new SmsSenderController(next.controller.midlet, next.controller.getAlbumData(), 
					next.controller.getAlbumListScreen(), next.imageName);
		smscontroller.setNextController(next.controller);
		return;
	}
	when GetPhotoControllerEvent do handler;

	public void handler(AddImageDataEvent next)throws Throwable{
		if (img == null){
			invoke(next);
		}
	}
	when AddImageDataEvent do handler;
}
