package lancs.midp.mobilephoto.optional.sms.events;

import ubc.midp.mobilephoto.core.ui.controller.PhotoController;

public void event GetPhotoControllerEvent {
	
	PhotoController controller;
	String imageName;
}
