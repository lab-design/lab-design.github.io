package lancs.midp.mobilephoto.optional.copyPhoto.events;

import ubc.midp.mobilephoto.core.ui.screens.PhotoViewScreen;

public void event PhotoViewScreenCreatedEvent {
	PhotoViewScreen f;
}
