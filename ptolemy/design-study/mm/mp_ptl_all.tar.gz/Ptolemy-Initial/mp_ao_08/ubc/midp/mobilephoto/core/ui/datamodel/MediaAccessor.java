/*
 * Created on Sep 13, 2004
 *
 */
package ubc.midp.mobilephoto.core.ui.datamodel;

import java.io.IOException;
import java.util.Vector;
import java.util.Hashtable;

import javax.microedition.lcdui.Image;
import javax.microedition.rms.RecordEnumeration;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;
import javax.microedition.rms.RecordStoreFullException;
import javax.microedition.rms.RecordStoreNotFoundException;

import lancs.midp.mobilephoto.lib.exceptions.*;
import lancs.midp.ptolemy.exceptionblocks.dataModelAspectEH.events.*;
import ubc.midp.mobilephoto.core.util.MediaUtil;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.events.*;
import lancs.midp.mobilephoto.optional.sms.events.*;
import lancs.midp.mobilephoto.alternative.musicvideo.*;

/**
 * @author trevor
 * 
 * This is the main data access class. It handles all the connectivity with the
 * RMS record stores to fetch and save data associated with MobilePhoto TODO:
 * Refactor into stable interface for future updates. We may want to access data
 * from RMS, or eventually direct from the 'file system' on devices that support
 * the FileConnection optional API.
 * 
 */
public abstract class MediaAccessor {

	// Note: Our midlet only ever has access to Record Stores it created
	// For now, use naming convention to create record stores used by
	// MobilePhoto
	public static String album_label; // "mpa- all album names
	// are prefixed with
	// this label
	public static String info_label; // "mpi- all album info
	// stores are prefixed with
	// this label
	public static String default_album_name; // default
	// album
	// name

	protected Hashtable mediaInfoTable = new Hashtable();

	protected String[] albumNames; // User defined names of photo albums

	// Record Stores
	public RecordStore imageRS = null;
	public RecordStore imageInfoRS = null;

	/*
	 * Constructor
	 */
	public MediaAccessor(String a, String i, String d) {
		album_label = a;
		info_label = i;
		default_album_name = d;
	}

	/**
	 * Load all existing photo albums that are defined in the record store.
	 * 
	 * @throws IOException 
	 * @throws RecordStoreException 
	 */
	public void loadAlbums() throws RecordStoreException, IOException {
		// Try to find any existing Albums (record stores)

		String[] currentStores = RecordStore.listRecordStores();

		if (currentStores != null) {
			System.out.println("ImageAccessor::loadAlbums: Found: "
					+ currentStores.length + " existing record stores");
			String[] temp = new String[currentStores.length];
			int count = 0;

			// Only use record stores that follow the naming convention defined
			for (int i = 0; i < currentStores.length; i++) {
				String curr = currentStores[i];

				// If this record store is a photo album...
				if (curr.startsWith(album_label)) {

					// Strip out the mpa- identifier
					curr = curr.substring(4);
					// Add the album name to the array
					temp[i] = curr;
					count++;
				}
			}

			// Re-copy the contents into a smaller array now that we know the
			// size
			albumNames = new String[count];
			int count2 = 0;
			for (int i = 0; i < temp.length; i++) {
				if (temp[i] != null) {
					albumNames[count2] = temp[i];
					count2++;
				}
			}
		} else {
			System.out
					.println("ImageAccessor::loadAlbums: 0 record stores exist. Creating default one.");
			resetMediaRecordStore();
			loadAlbums();
		}
	}

	/**
	 * Reset the album data for MobilePhoto. This will delete all existing photo
	 * data from the record store and re-create the default album and photos.
	 * 
	 * @throws IOException 
	 * @throws RecordStoreException 
	 */
	public void resetMediaRecordStore() throws RecordStoreException, IOException {

		String storeName = null;
		String infoStoreName = null;

		// remove any existing album stores...
		if (albumNames != null) {
			for (int i = 0; i < albumNames.length; i++) {
				try {//Scenario 9: I'm not going to aspectize.
					// Delete all existing stores containing Image objects as
					// well as the associated ImageInfo objects
					// Add the prefixes labels to the info store

					storeName = album_label + albumNames[i];
					infoStoreName = info_label + albumNames[i];

					RecordStore.deleteRecordStore(storeName);
					RecordStore.deleteRecordStore(infoStoreName);

				} catch (RecordStoreException e) {
					System.out.println("No record store named " + storeName
							+ " to delete.");
					System.out.println("...or...No record store named "
							+ infoStoreName + " to delete.");
					System.out.println("Ignoring Exception: " + e);
					// ignore any errors...
				}
			}
		} else {
			// Do nothing for now
			System.out
					.println("ImageAccessor::resetImageRecordStore: albumNames array was null. Nothing to delete.");
		}

		// Now, create a new default album for testing
		addMediaData("Tucan Sam", "/images/Tucan.png",
				MediaAccessor.default_album_name);
		// Add Penguin
		addMediaData("Linux Penguin", "/images/Penguin.png",
				MediaAccessor.default_album_name);
		// Add Duke
		addMediaData("Duke (Sun)", "/images/Duke1.PNG",
				MediaAccessor.default_album_name);
		addMediaData("UBC Logo", "/images/ubcLogo.PNG",
				MediaAccessor.default_album_name);
		// Add Gail
		addMediaData("Gail", "/images/Gail1.PNG",
				MediaAccessor.default_album_name);
		// Add JG
		addMediaData("J. Gosling", "/images/Gosling1.PNG",
				MediaAccessor.default_album_name);
		// Add GK
		addMediaData("Gregor", "/images/Gregor1.PNG",
				MediaAccessor.default_album_name);
		// Add KDV
		addMediaData("Kris", "/images/Kdvolder1.PNG",
				MediaAccessor.default_album_name);

	}

	public void addMediaArrayOfBytes(String photoname, String albumname, byte[] data1) {
		try {
			imageRS = RecordStore.openRecordStore(album_label + albumname, true);
			imageInfoRS = RecordStore.openRecordStore(info_label + albumname, true);

			int rid; // new record ID for Image (bytes)
			int rid2; // new record ID for ImageData (metadata)
			rid = imageRS.addRecord(data1, 0, data1.length);
			MediaData ii = new MediaData(rid,
					album_label + albumname, photoname);
			rid2 = imageInfoRS.getNextRecordID();
			ii.setRecordId(rid2);
			data1 = getByteFromMediaInfo(ii);
			imageInfoRS.addRecord(data1, 0, data1.length);
			imageRS.closeRecordStore();
			imageInfoRS.closeRecordStore();
		} catch (RecordStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public byte[] getByteFromMediaInfo(MediaData ii)
	throws InvalidImageDataException {
// [EF] Stub to avoid compilation error  
return null;
}

	public void addMediaData(String photoname, String path, String albumname) {
		try {
			announce AddImageDataEvent() {
				announce RecordStoreExceptionEvent()
				{
					imageRS = RecordStore.openRecordStore(album_label + albumname, true);
					imageInfoRS = RecordStore.openRecordStore(info_label + albumname,
							true);
		
					int rid; // new record ID for Image (bytes)
					int rid2; // new record ID for ImageData (metadata)
		
					MediaUtil converter = new MediaUtil();
		
					// NOTE: For some Siemen's phone, all images have to be less than
					// 16K
					// May have to check for this, or try to convert to a lesser format
					// for display on Siemen's phones (Could put this in an Aspect)
		
					// Add Tucan
					byte[] data1 = converter.readMediaAsByteArray(path);
					rid = imageRS.addRecord(data1, 0, data1.length);
					MediaData ii = new MediaData(rid, MediaAccessor.album_label
							+ albumname, photoname);
					rid2 = imageInfoRS.getNextRecordID();
					ii.setRecordId(rid2);
					data1 = converter.getBytesFromMediaInfo(ii).getBytes();
					imageInfoRS.addRecord(data1, 0, data1.length);
		
					imageRS.closeRecordStore();
		
					imageInfoRS.closeRecordStore();
				}
			}
		} catch (RecordStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * This will populate the imageInfo hashtable with the ImageInfo object,
	 * referenced by label name and populate the imageTable hashtable with Image
	 * objects referenced by the RMS record Id
	 * 
	 * @throws RecordStoreException 
	 */
	public MediaData[] loadMediaDataFromRMS(String recordName) {
		MediaData[] labelArray = null;

		try {
			announce RecordStoreExceptionEvent()
			{
				Vector imagesVector = new Vector();
	
				String infoStoreName = MediaAccessor.info_label + recordName;
		
				RecordStore infoStore;
					infoStore = RecordStore.openRecordStore(infoStoreName, false);
				RecordEnumeration isEnum = infoStore.enumerateRecords(null, null, false);
		
				while (isEnum.hasNextElement()) {
					// Get next record
					int currentId = isEnum.nextRecordId();
					byte[] data = infoStore.getRecord(currentId);
		
					// Convert the data from a byte array into our ImageData
					// (metadata) object
					MediaData iiObject = getMediaFromBytes(data);
		
					// Add the info to the metadata hashtable
					String label = iiObject.getMediaLabel();
					imagesVector.addElement(label);
					getMediaInfoTable().put(label, iiObject);
		
				}
		
				infoStore.closeRecordStore();
		
				// Re-copy the contents into a smaller array
				labelArray = new MediaData[imagesVector.size()];
				imagesVector.copyInto(labelArray);
			}
		} catch (RecordStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return labelArray;
	}

	/**
	 * Update the Image metadata associated with this named photo
	 */
	public boolean updateMediaInfo(MediaData oldData, MediaData newData) {
		boolean success = false;
		try {
			announce UpdateImageInfoEvent()
			{
				RecordStore infoStore = null;
			
			
				// Parse the Data store name to get the Info store name
				String infoStoreName = oldData.getParentAlbumName();
				infoStoreName = MediaAccessor.info_label
						+ infoStoreName.substring(MediaAccessor.album_label
								.length());
		
				infoStore = RecordStore.openRecordStore(infoStoreName, false);
	
				MediaUtil converter = new MediaUtil();
				byte[] imageDataBytes = converter.getBytesFromMediaInfo(newData).getBytes();
	
				infoStore.setRecord(oldData.getRecordId(), imageDataBytes, 0,
						imageDataBytes.length);
		
				
				// Update the Hashtable 'cache'
				setMediaInfo(oldData.getMediaLabel(), newData);
		
				infoStore.closeRecordStore();
			}
		} catch (RecordStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return success;
	}

	/**
	 * Retrieve the metadata associated with a specified image (by name)
	 */
	public MediaData getMediaInfo(String imageName) {

		MediaData ii = (MediaData) getMediaInfoTable().get(imageName);

		if (ii == null)
			throw new ImageNotFoundException(imageName +" was NULL in ImageAccessor Hashtable.");
			

		return ii;

	}

	/**
	 * Update the hashtable with new ImageInfo data
	 */
	public void setMediaInfo(String imageName, MediaData newData) {

		getMediaInfoTable().put(newData.getMediaLabel(), newData);

	}

	/**
	 * Fetch a single image from the Record Store This should be used for
	 * loading images on-demand (only when they are viewed or sent via SMS etc.)
	 * to reduce startup time by loading them all at once.
	 * 
	 * @throws RecordStoreException 
	 */
	public Image loadSingleMediaFromRMS(String recordName, String imageName,
			int recordId) throws RecordStoreException {

		Image img = null;
		byte[] imageData = loadMediaBytesFromRMS(recordName,
				recordId);
		img = Image.createImage(imageData, 0, imageData.length);
		return img;
	}

	/**
	 * Get the data for an Image as a byte array. This is useful for sending
	 * images via SMS or HTTP
	 * 
	 * @throws RecordStoreException 
	 */
	public byte[] loadMediaBytesFromRMS(String recordName,
			int recordId) {

		byte[] imageData = null;

		try {
			announce RecordStoreExceptionEvent()
			{
				RecordStore albumStore = RecordStore.openRecordStore(recordName,false);
				imageData = albumStore.getRecord(recordId);
				albumStore.closeRecordStore();
			} 
		} catch (RecordStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return imageData;
	}

	/**
	 * Delete a single (specified) image from the (specified) record store. This
	 * will permanently delete the image data and metadata from the device.
	 * 
	 * @throws RecordStoreException 
	 */
	public boolean deleteSingleMediaFromRMS(String storeName, String imageName) throws RecordStoreException {

		boolean success = false;

		// Open the record stores containing the byte data and the meta data
		// (info)
		// Verify storeName is name without pre-fix
		announce RecordStoreExceptionEvent()
		{
			imageRS = RecordStore
					.openRecordStore(album_label + storeName, true);
			imageInfoRS = RecordStore.openRecordStore(info_label + storeName,
					true);

			MediaData imageData = getMediaInfo(imageName);
			int rid = imageData.getForeignRecordId();

			imageRS.deleteRecord(rid);
			imageInfoRS.deleteRecord(rid);

			imageRS.closeRecordStore();
			imageInfoRS.closeRecordStore();

		// TODO: It's not clear from the API whether the record store needs to
		// be closed or not...
			
		}
		return success;
	}

	/**
	 * Define a new photo album for mobile photo users. This creates a new
	 * record store to store photos for the album.
	 * 
	 * @throws RecordStoreException 
	 */
	public void createNewAlbum(String albumName) throws RecordStoreException {
		
		RecordStore newAlbumRS = null;
		RecordStore newAlbumInfoRS = null;
			if (albumName.equals("")){
				System.out.println("Deve ter levantado ex");
				throw new InvalidPhotoAlbumNameException();
				
			}
			String[] names  = getAlbumNames();
			for (int i = 0; i < names.length; i++) {
				if (names[i].equals(albumName))
					throw new InvalidPhotoAlbumNameException();
			}
			
			
					newAlbumRS = RecordStore.openRecordStore(album_label + albumName,
						true);
			newAlbumInfoRS = RecordStore.openRecordStore(
					info_label + albumName, true);
			newAlbumRS.closeRecordStore();
			newAlbumInfoRS.closeRecordStore();
	

	}

	public void deleteAlbum(String albumName) throws RecordStoreException {
		announce RecordStoreExceptionEvent()
		{
			RecordStore.deleteRecordStore(album_label + albumName);
			RecordStore.deleteRecordStore(info_label + albumName);
		}
	}

	/**
	 * Get the list of photo album names currently loaded.
	 * 
	 * @return Returns the albumNames.
	 */
	public String[] getAlbumNames() {
		return albumNames;
	}

	public Hashtable getMediaInfoTable() {
		return mediaInfoTable;
	}

	protected abstract void resetRecordStore() throws IOException, RecordStoreException;
	
	protected abstract MediaData getMediaFromBytes(byte[] data) throws RecordStoreException;
	
//	protected abstract byte[] getMediaArrayOfByte(byte[] data) throws RecordStoreException;

	protected void removeRecords() {
		String storeName = null;
		String infoStoreName = null;

		// remove any existing album stores...
		if (albumNames != null) {
			for (int i = 0; i < albumNames.length; i++) {
				try {
					// Delete all existing stores containing Image objects as
					// well as the associated ImageInfo objects
					// Add the prefixes labels to the info store

					storeName = album_label + albumNames[i];
					infoStoreName = info_label + albumNames[i];

					System.out.println("<* ImageAccessor.resetVideoRecordStore() *> delete "+storeName);
					
					RecordStore.deleteRecordStore(storeName);
					RecordStore.deleteRecordStore(infoStoreName);

				} catch (RecordStoreException e) {
					System.out.println("No record store named " + storeName
							+ " to delete.");
					System.out.println("...or...No record store named "
							+ infoStoreName + " to delete.");
					System.out.println("Ignoring Exception: " + e);
					// ignore any errors...
				}
			}
		} else {
			// Do nothing for now
			System.out
					.println("ImageAccessor::resetVideoRecordStore: albumNames array was null. Nothing to delete.");
		}
	}
}