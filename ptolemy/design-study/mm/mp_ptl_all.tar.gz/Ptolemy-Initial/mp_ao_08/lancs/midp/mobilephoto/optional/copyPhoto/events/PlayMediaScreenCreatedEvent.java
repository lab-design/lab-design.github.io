package lancs.midp.mobilephoto.optional.copyPhoto.events;

import lancs.midp.mobilephoto.alternative.music.PlayMediaScreen;

public void event PlayMediaScreenCreatedEvent {
	PlayMediaScreen f;
}
