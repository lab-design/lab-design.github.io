package lancs.midp.mobilephoto.alternative.video.handler;

import lancs.midp.mobilephoto.alternative.video.*;
import java.io.InputStream;
import java.util.HashMap;
import javax.microedition.rms.RecordStoreException;
import java.io.IOException;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Display;

import lancs.midp.mobilephoto.alternative.musicvideo.MultiMediaData;
import lancs.midp.mobilephoto.alternative.photomusicvideo.SelectMediaController;
import lancs.midp.mobilephoto.lib.exceptions.ImageNotFoundException;
import lancs.midp.mobilephoto.lib.exceptions.InvalidImageDataException;
import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;
import ubc.midp.mobilephoto.core.ui.MainUIMidlet;
import ubc.midp.mobilephoto.core.ui.controller.AbstractController;
import ubc.midp.mobilephoto.core.ui.controller.AlbumController;
import ubc.midp.mobilephoto.core.ui.controller.BaseController;
import ubc.midp.mobilephoto.core.ui.controller.MediaController;
import ubc.midp.mobilephoto.core.ui.controller.MediaListController;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import ubc.midp.mobilephoto.core.ui.datamodel.MediaData;
import ubc.midp.mobilephoto.core.ui.screens.AlbumListScreen;
import ubc.midp.mobilephoto.core.ui.screens.MediaListScreen;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.events.*;
import lancs.midp.mobilephoto.optional.sms.events.*;
import lancs.midp.mobilephoto.alternative.music.events.*;
import edu.iastate.cs.ptolemy.runtime.*;

@Instantiation(Instantiation.Model.SINGLETON)
@Registration(Registration.Model.IMPLICIT)
@PrecedesHandler(lancs.midp.mobilephoto.alternative.photo.handler.PhotoAspectHandler.class)
public class VideoAspectHandler {
	public VideoAspectHandler() { register(this); }

	public static BaseController videoRootController;

	public static AlbumData videoModel;

	// ********  SelectMediaController  ********* //
	public BaseController SelectMediaController.videoController;
	public AlbumData SelectMediaController.videoAlbumData;

	public BaseController SelectMediaController.getVideoController() {
		return videoController;
	}

	public void SelectMediaController.setVideoController(BaseController videoController) {
		this.videoController = videoController;
	}

	public AlbumData SelectMediaController.getVideoAlbumData() {
		return videoAlbumData;
	}

	public void SelectMediaController.setVideoAlbumData(AlbumData videoAlbumData) {
		this.videoAlbumData = videoAlbumData;
	}
	
	public void handler(StartApplicationEvent next) throws Throwable {
		System.out.println("entrou before Video ..");
		videoModel = new VideoAlbumData();
		
		AlbumListScreen albumVideo = new AlbumListScreen();
		videoRootController = new BaseController(next.middlet, videoModel, albumVideo);
		
		MediaListController videoListController = new MediaListController(next.middlet, videoModel, albumVideo);
		videoListController.setNextController(videoRootController);
		
		AlbumController albumVideoController = new AlbumController(next.middlet, videoModel, albumVideo);
		albumVideoController.setNextController(videoListController);
		albumVideo.setCommandListener(albumVideoController);
		System.out.println("saiu before Video ..");
		
		invoke(next);
	}
	when StartApplicationEvent do handler;
	
	// ********  AlbumData  ********* //
	public void AlbumData.addVideoData(String videoname, String albumname, byte[] video) throws IOException, RecordStoreException {
		if (mediaAccessor instanceof VideoMediaAccessor)
			((VideoMediaAccessor)mediaAccessor).addVideoData(videoname, albumname, video);
	}
	
// ********  MediaController  ********* //
	
	public boolean handler(CommandActionEvent next) throws Throwable {
		boolean handled = invoke(next);
		
		if (handled) return true;
		
		String label = next.c.getLabel();
		System.out.println("<* VideoAspect.around handleCommandAction *> ::handleCommand: " + label);
		
		// [NC] Added in the scenario 07
		if (label.equals("Play Video")) {
			String selectedMediaName = ((MediaController)next.controller).getSelectedMediaName();
			return ((MediaController)next.controller).playVideoMedia(selectedMediaName);		
		}
		
		return false;
	}
	when CommandActionEvent do handler;
	
	private boolean MediaController.playVideoMedia(String selectedMediaName) throws IOException, RecordStoreException {
		InputStream storedMusic = null;
		try {
			MediaData mymedia = getAlbumData().getMediaInfo(selectedMediaName);
			
			if (mymedia instanceof MultiMediaData)
			{
				storedMusic = ((VideoAlbumData) getAlbumData()).getVideoFromRecordStore(getCurrentStoreName(), selectedMediaName);
				PlayVideoScreen playscree = new PlayVideoScreen(midlet,storedMusic, ((MultiMediaData)mymedia).getTypeMedia(),this);
				playscree.setVisibleVideo();
				PlayVideoController controller = new PlayVideoController(midlet, getAlbumData(), (AlbumListScreen) getAlbumListScreen(), playscree);
				setNextController(controller);
			}
			return true;
		} catch (ImageNotFoundException e) {
			Alert alert = new Alert( "Error", "The selected item was not found in the mobile device", null, AlertType.ERROR);
			Display.getDisplay(midlet).setCurrent(alert, Display.getDisplay(midlet).getCurrent());
		    return false;
		} 
		catch (PersistenceMechanismException e) {
			Alert alert = new Alert( "Error", "The mobile database can open this item 1", null, AlertType.ERROR);
			Display.getDisplay(midlet).setCurrent(alert, Display.getDisplay(midlet).getCurrent());
			return false;
		}
	
	}
	
	// ********  MediaListScreen  ********* //
	
	// [NC] Added in the scenario 07: to support more than one screen purpose
	public static final int PLAYVIDEO = 3;
	
	// [NC] Added in the scenario 07
	public static final Command playCommand = new Command("Play Video", Command.ITEM, 1);
	
	public void handler(InitMenuEvent next) throws Throwable {
		invoke(next);
		
		if (next.screen.getTypeOfScreen() == PLAYVIDEO)
			next.screen.addCommand(playCommand);
	}
	when InitMenuEvent do handler;

	public MediaListScreen handler(MediaListScreenCreatedEvent next) throws Throwable {
		MediaListScreen listScreen = invoke(next);
		if (next.controller.getAlbumData() instanceof VideoAlbumData)
			listScreen.setTypeOfScreen(VideoAspectHandler.PLAYVIDEO);
		return listScreen;
	}
	when MediaListScreenCreatedEvent do handler;
}
