package lancs.midp.mobilephoto.optional.smsorcapturephoto.handler;

import javax.microedition.rms.RecordStoreException;
import java.io.IOException;
import lancs.midp.mobilephoto.lib.exceptions.InvalidImageDataException;
import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import lancs.midp.mobilephoto.alternative.photo.ImageMediaAccessor;

public class SmSOrCapturePhotoHandler {
	public void AlbumData.addImageData(String photoname, byte[] imgdata, String albumname) throws IOException, RecordStoreException {
		if (mediaAccessor instanceof ImageMediaAccessor)
			((ImageMediaAccessor)mediaAccessor).addImageData(photoname, imgdata, albumname);
	}
	
	public void ImageMediaAccessor.addImageData(String photoname, byte[] imgdata, String albumname) throws IOException, RecordStoreException {
			addMediaArrayOfBytes(photoname, albumname, imgdata);
	}
}
