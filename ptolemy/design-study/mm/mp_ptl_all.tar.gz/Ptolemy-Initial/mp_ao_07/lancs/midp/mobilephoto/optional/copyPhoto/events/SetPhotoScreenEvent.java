package lancs.midp.mobilephoto.optional.copyPhoto.events;

import ubc.midp.mobilephoto.core.ui.controller.MediaController;
import lancs.midp.mobilephoto.alternative.photo.PhotoViewScreen;

public void event SetPhotoScreenEvent {
	MediaController controller;
	String imageName;
	PhotoViewScreen canv;
}
