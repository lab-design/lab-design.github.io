package lancs.midp.mobilephoto.alternative.photoMusic.events;

import ubc.midp.mobilephoto.core.ui.controller.BaseController;

public boolean event GoToPreviousEvent {
	BaseController controller;
}
