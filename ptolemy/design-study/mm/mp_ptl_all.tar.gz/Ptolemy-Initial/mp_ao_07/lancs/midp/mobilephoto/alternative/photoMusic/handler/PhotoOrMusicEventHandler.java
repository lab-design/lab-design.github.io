package lancs.midp.mobilephoto.alternative.photoMusic.handler;

import javax.microedition.lcdui.Command;
import lancs.midp.mobilephoto.alternative.photoMusic.events.*;
import edu.iastate.cs.ptolemy.runtime.*;

@Instantiation(Instantiation.Model.SINGLETON)
@Registration(Registration.Model.IMPLICIT)
public class PhotoOrMusicEventHandler {
	public static final Command exitCommand = new Command("Back", Command.STOP, 2);

	public PhotoOrMusicEventHandler() { register(this); }

	public void handler(InitMenuEvent next) throws Throwable {
		next.screen.addCommand(exitCommand);
		invoke(next);
	}
	when InitMenuEvent do handler;
}
