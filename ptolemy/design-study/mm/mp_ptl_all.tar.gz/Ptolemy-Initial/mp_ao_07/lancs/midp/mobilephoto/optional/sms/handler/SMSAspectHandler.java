package lancs.midp.mobilephoto.optional.sms.handler;

import java.util.HashMap;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Image;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;

import ubc.midp.mobilephoto.core.ui.datamodel.MediaAccessor;
import ubc.midp.mobilephoto.core.ui.datamodel.MediaData;
import ubc.midp.mobilephoto.core.ui.screens.AddMediaToAlbum;
import lancs.midp.mobilephoto.alternative.photo.PhotoViewScreen;
import ubc.midp.mobilephoto.core.util.MediaUtil;

import lancs.midp.mobilephoto.lib.exceptions.InvalidImageDataException;
import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;
import lancs.midp.ptolemy.exceptionblocks.dataModelAspectEH.events.*;
import lancs.midp.mobilephoto.optional.copyPhoto.events.*;

import lancs.midp.mobilephoto.optional.sms.events.*;
import ubc.midp.mobilephoto.sms.*;
import ubc.midp.mobilephoto.core.ui.controller.*;
import ubc.midp.mobilephoto.core.ui.screens.*;
import ubc.midp.mobilephoto.core.ui.datamodel.*;
import lancs.midp.mobilephoto.alternative.photo.handler.PhotoAspectHandler;
import lancs.midp.mobilephoto.alternative.photo.ImageMediaAccessor;
import edu.iastate.cs.ptolemy.runtime.*;

@Instantiation(Instantiation.Model.SINGLETON)
@Registration(Registration.Model.IMPLICIT)
@PrecedesHandler(lancs.midp.mobilephoto.optional.copyPhoto.handler.CopyPhotoHandler.class)
public class SMSAspectHandler {
	public static final Command smscopyCommand = new Command("Send Photo by SMS", Command.ITEM, 1);
	public static Image img = null;
	
	private Image AddMediaToAlbum.image = null;
	
	public Image AddMediaToAlbum.getImage() {
		return image;
	}

	public void AddMediaToAlbum.setImage(Image image) {
		this.image = image;
	}

	public void AlbumData.addNewMediaToAlbum(String photoName, Image img, String albumname) {
		try{
			((ImageMediaAccessor)mediaAccessor).addImageData(photoName, img, albumname);
		}catch(Exception e){
			System.out.println("Error "+e.getMessage());
		}
	}

	private boolean PhotoViewScreen.fromSMS = false;
	
	public Image PhotoViewScreen.getImage(){
		return image;
	}
	public boolean PhotoViewScreen.isFromSMS() {
		return fromSMS;
	}
	public void PhotoViewScreen.setFromSMS(boolean fromSMS) {
		this.fromSMS = fromSMS;
	}

	public SMSAspectHandler() { register(this); }

	public byte[] ImageMediaAccessor.getByteFromImage(Image img){
		int w = img.getWidth();
		int h = img.getHeight();
		int data_int[] = new int[ w * h ];
		img.getRGB( data_int, 0, w, 0, 0, w, h );
		byte[] data_byte = new byte[ w * h * 3 ];
		for ( int i = 0; i < w * h; ++i )
		{
		int color = data_int[ i ];
		int offset = i * 3;
		data_byte[ offset ] = ( byte ) ( ( color & 0xff0000 ) >> 16 );
		data_byte[ offset +
		1 ] = ( byte ) ( ( color & 0xff00 ) >> 8 );
		data_byte[ offset + 2 ] = ( byte ) ( ( color & 0xff ) );
		}
		return data_byte;
	}
	
	public void ImageMediaAccessor.addImageData(String photoname, Image imgdata, String albumname)
				throws InvalidImageDataException, PersistenceMechanismException {
		try {
			imageRS = RecordStore.openRecordStore(album_label + albumname, true);
			imageInfoRS = RecordStore.openRecordStore(info_label + albumname, true);
			int rid; // new record ID for Image (bytes)
			int rid2; // new record ID for ImageData (metadata)
				
			MediaUtil converter = new MediaUtil();
			
			byte[] data1 = getByteFromImage(imgdata);
			rid = imageRS.addRecord(data1, 0, data1.length);
			MediaData ii = new MediaData(rid, MediaAccessor.album_label	+ albumname, photoname);
			rid2 = imageInfoRS.getNextRecordID();				
			ii.setRecordId(rid2);
			String data1String = converter.getBytesFromMediaInfo(ii); 
			data1 = data1String.getBytes();
			imageInfoRS.addRecord(data1, 0, data1.length);
			
			imageRS.closeRecordStore();
			
			imageInfoRS.closeRecordStore();
		} catch (RecordStoreException e) {
			throw new PersistenceMechanismException();
		}
	}

	public void handler(StartApplicationEvent next)throws Throwable{
		invoke(next);
		BaseController imageRootController = PhotoAspectHandler.imageRootController;
		AlbumData imageModel = PhotoAspectHandler.imageModel;
		
		AlbumListScreen albumListScreen = (AlbumListScreen)imageRootController.getAlbumListScreen(); // [EF]
		SmsReceiverController controller = new SmsReceiverController(next.middlet, imageModel, albumListScreen);
		controller.setNextController(imageRootController);
		SmsReceiverThread smsR = new SmsReceiverThread(next.middlet, imageModel, albumListScreen, controller);
		System.out.println("SmsController::Starting SMSReceiver Thread");
		new Thread(smsR).start();
	}
	when StartApplicationEvent do handler;

	public void handler(ProcessImageDataEvent next)throws Throwable{
		MediaData imageData = null;
		SMSAspectHandler.img = null;
		
		SMSAspectHandler.img = ((AddMediaToAlbum)next.photoViewController.getCurrentScreen()).getImage();
		if (SMSAspectHandler.img == null){
//			imageData = invoke(next);
			invoke(next);
		}
		if (SMSAspectHandler.img != null){
			next.photoViewController.getAlbumData().addNewMediaToAlbum(next.photoName, SMSAspectHandler.img, next.albumname);
		}		

		return;
//		return imageData;
	}
	when ProcessImageDataEvent do handler;

	public void handler(ProcessCopyEvent next)throws Throwable{
		invoke(next);
		
		if (((PhotoViewScreen)next.photoViewController.getCurrentScreen()).fromSMS){
			next.copyPhotoToAlbum.setImage(((PhotoViewScreen)next.photoViewController.getCurrentScreen()).getImage());
		}
	}
	when ProcessCopyEvent do handler;

	public void handler(PhotoViewScreenCreatedEvent next)throws Throwable{
		invoke(next);
		next.f.addCommand(SMSAspectHandler.smscopyCommand);
	}
	when PhotoViewScreenCreatedEvent do handler;

	public void handler(LoadImageEvent next)throws Throwable{
		if (next.screen.fromSMS){
		   return;
		}
		else 
		{
		   invoke(next);
		}
	}
	when LoadImageEvent do handler;

	public void handler(GetPhotoControllerEvent next)throws Throwable{
		invoke(next);
		SmsSenderController smscontroller = new SmsSenderController(next.controller.midlet, next.controller.getAlbumData(), 
					(AlbumListScreen)next.controller.getAlbumListScreen(), next.imageName);
		smscontroller.setNextController(next.controller);
		return;
	}
	when GetPhotoControllerEvent do handler;

	public void handler(AddImageDataEvent next)throws Throwable{
		if (SMSAspectHandler.img == null){
			invoke(next);
		}
	}
	when AddImageDataEvent do handler;
}
