package lancs.midp.mobilephoto.optional.sms.events;

import lancs.midp.mobilephoto.alternative.photo.PhotoViewScreen;

public void event LoadImageEvent {
	
	PhotoViewScreen screen; 

}
