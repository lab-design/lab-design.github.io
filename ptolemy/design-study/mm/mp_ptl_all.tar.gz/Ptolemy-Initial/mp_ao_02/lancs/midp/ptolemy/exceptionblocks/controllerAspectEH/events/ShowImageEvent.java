package lancs.midp.ptolemy.exceptionblocks.controllerAspectEH.events;

import javax.microedition.midlet.MIDlet;

public void event ShowImageEvent {
	MIDlet midlet;
	String selectedImageName;
}
