package lancs.midp.aspects.exceptionblocks.dataModelAspectEH.annotations;

import java.lang.annotation.*;

@Retention(RetentionPolicy.CLASS)
public @interface DeleteSingleImageFromRMSEvent
{
}
