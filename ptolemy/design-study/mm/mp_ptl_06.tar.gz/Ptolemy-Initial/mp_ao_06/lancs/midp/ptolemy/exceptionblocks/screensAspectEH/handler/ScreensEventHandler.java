package lancs.midp.ptolemy.exceptionblocks.screensAspectEH.handler;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;

import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;
import lancs.midp.mobilephoto.lib.exceptions.ImageNotFoundException;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import ubc.midp.mobilephoto.core.ui.screens.PhotoViewScreen;

import lancs.midp.ptolemy.exceptionblocks.screensAspectEH.events.*;
import edu.iastate.cs.ptolemy.runtime.*;

@Instantiation(Instantiation.Model.SINGLETON)
@Registration(Registration.Model.IMPLICIT)
public class ScreensEventHandler {
	
	public ScreensEventHandler() { register(this); }

	public void handler(NewPhotoViewScreenEvent next) throws Throwable {
		try {
			invoke(next);
		} catch (ImageNotFoundException e) {
			Alert alert = new Alert( "Error", "The selected image can not be found", null, AlertType.ERROR);
			alert.setTimeout(5000);
		} catch (PersistenceMechanismException e) {
			Alert alert = new Alert( "Error", "It was not possible to recovery the selected image", null, AlertType.ERROR);
			alert.setTimeout(5000);
		}
	}
	
	when NewPhotoViewScreenEvent do handler;
}

