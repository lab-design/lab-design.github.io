package lancs.midp.ptolemy.exceptionblocks.utilAspectEH.events;

public void event ReadImageAsByteArrayEvent {
	String imageFile;	
}
