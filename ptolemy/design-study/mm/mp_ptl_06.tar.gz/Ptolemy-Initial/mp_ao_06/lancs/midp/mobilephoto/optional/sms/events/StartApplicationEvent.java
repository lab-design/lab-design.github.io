package lancs.midp.mobilephoto.optional.sms.events;

import ubc.midp.mobilephoto.core.ui.MainUIMidlet;

public void event StartApplicationEvent {
	MainUIMidlet middlet;
}
