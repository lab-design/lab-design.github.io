package lancs.midp.mobilephoto.optional.sms.events;

import lancs.midp.mobilephoto.optional.copyPhoto.PhotoViewController;
import ubc.midp.mobilephoto.core.ui.datamodel.ImageAccessor;

public void event ProcessImageDataEvent
{
	PhotoViewController photoViewController;
	ImageAccessor imageAccessor;
	String photoName;
	String albumname;
}
