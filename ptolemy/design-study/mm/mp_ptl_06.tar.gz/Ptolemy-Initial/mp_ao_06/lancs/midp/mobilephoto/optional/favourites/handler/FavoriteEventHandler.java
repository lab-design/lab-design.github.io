package lancs.midp.mobilephoto.optional.favourites.handler;

import java.util.HashMap;

import javax.microedition.lcdui.*;

import lancs.midp.mobilephoto.lib.exceptions.ImageNotFoundException;
import lancs.midp.mobilephoto.lib.exceptions.NullAlbumDataReference;

import ubc.midp.mobilephoto.core.ui.controller.*;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import ubc.midp.mobilephoto.core.ui.datamodel.ImageData;
import ubc.midp.mobilephoto.core.util.Constants;
import ubc.midp.mobilephoto.core.util.ImageUtil;

import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.events.*;
import lancs.midp.ptolemy.exceptionblocks.controllerAspectEH.events.*;
import edu.iastate.cs.ptolemy.runtime.*;

@Instantiation(Instantiation.Model.SINGLETON)
@Registration(Registration.Model.IMPLICIT)
@PrecedesHandler(lancs.midp.mobilephoto.optional.sorting.CountViewAspect.handler.CountViewEventHandler.class)
public class FavoriteEventHandler {
	
	public FavoriteEventHandler() {
		register(this);
	}

	public static boolean isfavorite = false;
	public static final Command favoriteCommand = new Command("Set Favorite", Command.ITEM, 1);
	public static final Command viewFavoritesCommand = new Command("View Favorites", Command.ITEM, 1);
		
	// [EF] Added in the scenario 03 
	private boolean ImageData.favorite = false;
	
	/**
	 * [EF] Added in the scenario 03
	 */
	public void ImageData.toggleFavorite() {
		this.favorite = ! favorite;
	}
	
	/**
	 * [EF] Added in the scenario 03
	 * @param favorite
	 */
	public void ImageData.setFavorite(boolean favorite){
		this.favorite = favorite;
	}

	/**
	 * [EF] Added in the scenario 03
	 * @return the favorite
	 */
	public boolean ImageData.isFavorite() {
		return favorite;
	}

	public void handler(InitMenuEvent next) throws Throwable{
		invoke(next);
		next.screen.addCommand(FavoriteEventHandler.favoriteCommand);
		next.screen.addCommand(FavoriteEventHandler.viewFavoritesCommand);
	}
	when InitMenuEvent do handler;

	public ImageData handler(CreateImageDataEvent next) throws Throwable{
		
		boolean favorite = false;
		int endIndex = next.endIndex;
		int startIndex = endIndex + 1;
		endIndex = next.iiString.indexOf(ImageUtil.DELIMITER, startIndex);
		
		if (endIndex == -1)
			endIndex = next.iiString.length();

		favorite = (next.iiString.substring(startIndex, endIndex)).equalsIgnoreCase("true");
		
		ImageData imageData = invoke(next);
		
		imageData.setFavorite(favorite);

//		System.out.println("<* FavouritesAspect.around createImageData *> ...ends");
		
		return imageData;

	}
	when CreateImageDataEvent do handler;

	public boolean handler(CommandActionEvent next) throws Throwable {
		boolean handled = invoke(next);
		
		if (handled) return true;
		
		String label = next.c.getLabel();
		System.out.println("<* FavouritesAspect.around handleCommandAction *> ::handleCommand: " + label);
		
		/** Case: Set photo as favorite 
		 * [EF] Added in the scenario 03 **/
		if (label.equals("Set Favorite")) {
		   	String selectedImageName = next.controller.getSelectedImageName();
			try {
				ImageData image = next.controller.getAlbumData().getImageAccessor().getImageInfo(selectedImageName);
				image.toggleFavorite();
				next.controller.updateImage(image);
				//System.out.println("<* FavouritesAspect.handleCommand() *> Image = "+selectedImageName+ "; Favorite = "+image.isFavorite());
				System.out.println("<* FavouritesAspect.handleCommand() *> Image = "
						+selectedImageName+ "; Favorite = "+image.isFavorite());
			} catch (ImageNotFoundException e) {
				Alert alert = new Alert( "Error", "The selected photo was not found in the mobile device", null, AlertType.ERROR);
				Display.getDisplay(next.controller.midlet).setCurrent(alert, Display.getDisplay(next.controller.midlet).getCurrent());
			} catch (NullAlbumDataReference e) {
				next.controller.setAlbumData( new AlbumData() );
				Alert alert = new Alert( "Error", "The operation is not available. Try again later !", null, AlertType.ERROR);
				Display.getDisplay(next.controller.midlet).setCurrent(alert, Display.getDisplay(next.controller.midlet).getCurrent());
			}
			return true;
				
		/** Case: View favorite photos 
		 * [EF] Added in the scenario 03 **/
		} else if (label.equals("View Favorites")) {
			isfavorite = true;
			next.controller.showImageList(next.controller.getCurrentStoreName());
    		ScreenSingleton.getInstance().setCurrentScreenName( Constants.IMAGELIST_SCREEN );
			return true;
		}
		
		return false;
	}
	when CommandActionEvent do handler;

	public void handler(AppendImagesEvent next) throws Throwable{
		// [EF] Check if favorite is true (Add in the Scenario 03)
		if (isfavorite) {
			for (int i = 0; i < next.images.length; i++)
				if ( !(next.images[i].isFavorite()) ) 
					next.images[i] = null;
		}
		invoke(next);
		return;
	}
	when AppendImagesEvent do handler;
}
