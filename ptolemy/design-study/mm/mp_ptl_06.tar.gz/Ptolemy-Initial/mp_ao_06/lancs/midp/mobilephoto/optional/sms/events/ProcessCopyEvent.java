package lancs.midp.mobilephoto.optional.sms.events;

import lancs.midp.mobilephoto.optional.copyPhoto.PhotoViewController;
import ubc.midp.mobilephoto.core.ui.screens.AddPhotoToAlbum;

public void event ProcessCopyEvent
{
	PhotoViewController photoViewController;
	AddPhotoToAlbum copyPhotoToAlbum;
}
