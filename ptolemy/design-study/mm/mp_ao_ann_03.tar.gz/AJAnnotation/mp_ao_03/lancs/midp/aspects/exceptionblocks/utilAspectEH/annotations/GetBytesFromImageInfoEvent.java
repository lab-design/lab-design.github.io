package lancs.midp.aspects.exceptionblocks.utilAspectEH.annotations;

import java.lang.annotation.*;

@Retention(RetentionPolicy.CLASS)
public @interface GetBytesFromImageInfoEvent
{
}
