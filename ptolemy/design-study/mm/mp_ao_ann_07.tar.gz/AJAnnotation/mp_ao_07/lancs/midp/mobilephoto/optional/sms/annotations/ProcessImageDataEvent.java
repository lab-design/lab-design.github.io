package lancs.midp.mobilephoto.optional.sms.annotations;

import java.lang.annotation.*;

@Retention(RetentionPolicy.CLASS)
public @interface ProcessImageDataEvent
{
}
