package lancs.midp.mobilephoto.alternative.music.annotations;

import java.lang.annotation.*;

@Retention(RetentionPolicy.CLASS)
public @interface MediaListScreenCreatedEvent
{
}
