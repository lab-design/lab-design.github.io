
/***
 * This class modularizes the display update concern. 
 * For the moment it is mimicking the following binding
 *  void around(FigureElement changedFE) FEChanged : handler   
 */
public class DisplayUpdate implements FEChanged.PtolemyEventHandler { //This will be auto-generated

	public DisplayUpdate(){
		// This is register(this);
		FEChanged.PtolemyEventFrame.register(this); //This will be auto-generated 
	}
	public void handler(FEChanged inner){
		System.out.println("  Inside display update: Before");
		inner.proceed();
                Display.update();
		System.out.println("  Inside display update: After");
	}
}
