/***
 * A class mimicking an Observer with
 * the following binding 
 *  void around(int x, int y, int z) E : handler   
 */
public class Observer implements Event.PtolemyEventHandler { //This will be auto-generated
	public Observer(){
		// This is register(this);
		Event.PtolemyEventFrame.register(this); //This will be auto-generated 
	}
	public void handler(Event inner){
		System.out.println("  Inside the Observer before the proceed call #1.");
		inner.proceed();
		System.out.println("  Inside the Observer after the proceed call #1.");
		System.out.println("  Inside the Observer before the proceed call #2.");
		inner.proceed();
		System.out.println("  Inside the Observer after the proceed call #2.");
	}
}
