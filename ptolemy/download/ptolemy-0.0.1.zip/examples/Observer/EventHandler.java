/***
 * A class mimicking the type of handlers.
 * This class will be auto-generated. 
 */
public interface EventHandler{
   public void handler(Event inner);
}
