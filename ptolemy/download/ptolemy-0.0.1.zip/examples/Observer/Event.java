/***
 * An event type E
 * evtype E { x, y, z}
 */
import java.util.*;
public void evtype Event {
    int x;
    int y;
    int z;
}
