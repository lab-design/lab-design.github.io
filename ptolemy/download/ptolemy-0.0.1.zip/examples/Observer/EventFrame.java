/* A class mimicking the active objects table in the operational
 * semantics of Ptolemy.
 * 
 */
public final class EventFrame implements Event{
	private static java.util.List<EventHandler> 
	eventHandlers = 
		java.util.Collections.synchronizedList(
				new java.util.ArrayList<EventHandler>());
	/***
	 * A method mimicking the register
	 */
	public static void Register(EventHandler handler){
                if(eventHandlers == null){
        		eventHandlers = 
                		java.util.Collections.synchronizedList(
                                new java.util.ArrayList<EventHandler>());
		    	}
		eventHandlers.add(handler);
		cachedEventFrameSet = null; // For now simple invalidation is good
		                 // I will implement, better reuse of 
		                 // partially valid results later.
	}

	// The rationale for keeping the reference local
	// instead of the global may be because in a multi-threaded
	// environment, event announcements may come from multiple 
	// threads at once, but this call-by-need-like implementation
	// if good for the moment. 
	private static Event body;
	private static EventFrame cachedEventFrameSet;
	public static void Announce(Event ev){
		if(eventHandlers == null)
			ev.proceed();
		else {
			body = ev;
			if(cachedEventFrameSet == null ){
				java.util.Iterator<EventHandler> i =	
					eventHandlers.iterator();
				cachedEventFrameSet = new EventFrame(i);
			}
			cachedEventFrameSet.invoke();
		}
	}
	private EventHandler handler;
	private EventFrame nextFrame;
	private EventFrame(java.util.Iterator<EventHandler> chain){
	    if(chain.hasNext()){
		handler = chain.next();
		nextFrame = new EventFrame(chain);
		return;
		}
	    nextFrame = null;
	}
	private void invoke(){
	    if(nextFrame!=null){
		handler.handler(this);
                return;
		}
	    handler.handler(EventFrame.body);
	}
	public void proceed(){
	    if(nextFrame.handler!=null){
	       nextFrame.handler.handler(nextFrame);
               return;
               }
	    EventFrame.body.proceed();
	}
	public int x() { return EventFrame.body.x();}
	public int y() { return EventFrame.body.y();}
	public int z() { return EventFrame.body.z();}
}
