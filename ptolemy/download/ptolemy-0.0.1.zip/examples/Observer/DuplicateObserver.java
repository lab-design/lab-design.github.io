/***
 * A class mimicking the handler class with
 * the following binding 
 *  void around(int x, int y, int z) E : handler   
 */
public class DuplicateObserver implements Event.PtolemyEventHandler { // Finally this should be auto-generated
	public DuplicateObserver(){
	   // This is register(this);
	   Event.PtolemyEventFrame.register(this); // Finally this should be auto-generated 
	}
	public void handler(Event inner){
	   System.out.println("   Duplicate Observer before the proceed call #1.");
	   inner.proceed();
 	   System.out.println("   Duplicate Observer after the proceed call #1.");
	   System.out.println("   Duplicate Observer before the proceed call #2.");
	   inner.proceed();
	   System.out.println("   Duplicate Observer after the proceed call #2.");
	}
}
