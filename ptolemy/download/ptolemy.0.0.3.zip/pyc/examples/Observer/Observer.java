/***
 * An Observer with the following binding 
 *  when Event do handler;
 */
public class Observer implements Event.PtolemyEventHandler { //This will be auto-generated
	public Observer(){
		register(this);  
	}
	public void handler(Event inner){
		System.out.println("  Inside the Observer before the proceed call #1.");
		inner.proceed();
		System.out.println("  Inside the Observer after the proceed call #1.");
		System.out.println("  Inside the Observer before the proceed call #2.");
		inner.proceed();
		System.out.println("  Inside the Observer after the proceed call #2.");
	}
        when Event do handler;
}
