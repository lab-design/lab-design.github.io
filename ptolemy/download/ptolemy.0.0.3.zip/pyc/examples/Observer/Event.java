/***
 * An event type E
 * evtype E { x, y, z}
 */
import java.util.*;
public void evtype Event {
    Object subject;
}
