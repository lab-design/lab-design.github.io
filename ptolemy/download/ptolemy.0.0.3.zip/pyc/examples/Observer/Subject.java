
public class Subject {
	/***
	 * A method, which announces an event of evtype E (ignoring the 
	 * printing i.e. all print statements) */

	  public void work() {
             System.out.println("Before the event statement.");
             Object subject = this;
	     event Event {
               System.out.println("            Before the event body.");
               System.out.println("            After the event body.");
	       }

	     System.out.println("After the event statement");		    
	}
}

