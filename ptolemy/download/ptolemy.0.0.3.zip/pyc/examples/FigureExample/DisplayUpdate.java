/***
 * This class modularizes the display update concern. 
 */
public class DisplayUpdate 
     implements FEChanged.PtolemyEventHandler {

  public DisplayUpdate(){
    register(this);  
   }
  public void handler(FEChanged inner){
    System.out.println("  Inside display update: Before");
    inner.proceed();
    Display.update();
    System.out.println("  Inside display update: After");
   }

   when FEChanged do handler;
}
