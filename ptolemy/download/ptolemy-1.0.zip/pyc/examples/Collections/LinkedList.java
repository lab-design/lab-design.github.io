/* -*- Mode: Java; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*-
 *
 * This file is part of the Ptolemy project at Iowa State University.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/.
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 * 
 * For more details and the latest version of this code please see
 * http://www.cs.iastate.edu/~ptolemy/
 *
 * Contributor(s):   
 */
/**
 * This class demonstrates a subject in Ptolemy. It models a LinkedList 
 * that also announces <i>events</i> when elements are added and removed from 
 * the list. Two events <code>ElementAdded</code> and <code>ElementRemoved</code>
 * are announced by the methods <code>add</code> and <code>remove</code> 
 * in this class.
 *
 * @author  Hridesh Rajan
 * @version $Revision: 1.2 $, $Date: 2010/03/01 00:30:55 $
 *
 * @see ElementAdded
 * @see ElementRemoved
 */
public class LinkedList implements Collection{
	
	private Node listhead;
	
	/***
	 * This method adds an element to the underlying structure 
	 * and announces the <i>event</i> <code>ElementAdded</code>. 
	 * @param element
	 */
	public void add(Element element) {
        System.out.println("In LinkedList.add Method before announce.");		
		announce ElementAdded(this, element) {
	        System.out.println("    In LinkedList.add Method in announce expression body.");		
			Node temp = listhead;
			listhead = new Node();
			listhead.data = element;
			listhead.next = temp;
		}
        System.out.println("In LinkedList.add Method after Announce.");		
	}

	/***
	 * This method removes an element from the underlying structure 
	 * and announces the <i>event</i> <code>ElementRemoved</code>. 
	 * @param element
	 */
	public void remove(Element element) {
        System.out.println("In LinkedList.remove Method before Announce.");		
		announce ElementRemoved(this, element){
	        System.out.println("    In LinkedList.remove Method in announce expression body.");		
			Node temp = listhead;
			for(;!(temp.next==null || temp.next.data == element);temp=temp.next);
			if(temp.next!=null) temp.next = temp.next.next; 
		}
        System.out.println("In LinkedList.remove Method after Announce.");		
	}

	public boolean contains(Element element) {
		return false;
	}
	
	private class Node {
		Object data;
		Node next;
	}
}
