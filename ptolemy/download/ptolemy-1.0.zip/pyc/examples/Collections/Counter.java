/* -*- Mode: Java; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*-
 *
 * This file is part of the Ptolemy project at Iowa State University.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/.
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 * 
 * For more details and the latest version of this code please see
 * http://www.cs.iastate.edu/~ptolemy/
 *
 * Contributor(s):   
 */

/**
 * This Ptolemy <i>handler</i> is run when any class announces
 * <i>event</i> <code>ElementAdded</code>. The logic in this 
 * class simply counts these calls.
 * 
 * @author  Hridesh Rajan
 * @version $Revision: 1.2 $, $Date: 2010/03/01 00:30:55 $
 *
 */
public class Counter {

	long count;

	/***
	 * This <i>binding declaration</i> says to run the method handler
	 * when any class announces the event <code>ElementAdded</code>.
	 */
	when ElementAdded do increment;
	
	public void increment(ElementAdded next) throws Throwable {
		// This line says to run the rest of the handlers for ElementAdded
		// event. So in essence <code>Counter</code> acts as an 
		// <code>after advice</code> in AspectJ.
        System.out.println("  In Counter.increment Method before invoke call.");		
		invoke(next); 
        System.out.println("  In Counter.increment Method after invoke call.");		
		count++;
	}
	
	/***
	 * This <i>binding declaration</i> says to run the method handler
	 * when any class announces the event <code>ElementRemoved</code>.
	 */
	when ElementRemoved do decrement;
	
	public void decrement(ElementRemoved next) throws Throwable {
		// This line says to run the rest of the handlers for ElementAdded
		// event. So in essence <code>Counter</code> acts as an 
		// <code>after advice</code> in AspectJ. 
        System.out.println("  In Counter.decrement Method before invoke call.");		
		invoke(next); 
        System.out.println("  In Counter.decrement Method after invoke call.");		
		count--;
	}

	public Counter(){ 
		/**
		 *  Ptolemy allows dynamic activation and deactivation of handlers.
		 *  The following registration is activately the Counter handler so all
		 *  event announcements for ElementAdded cause handler method to
		 *  be run with <code>this</code> as the receiver object.
		 */
        System.out.println("In Counter constructor registering to receive event notifications.");		
		register(this);  
	}
	
	public long getCount() { return count; }
}
