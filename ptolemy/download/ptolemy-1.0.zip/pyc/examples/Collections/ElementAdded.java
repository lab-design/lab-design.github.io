/* -*- Mode: Java; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*-
 *
 * This file is part of the Ptolemy project at Iowa State University.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/.
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 * 
 * For more details and the latest version of this code please see
 * http://www.cs.iastate.edu/~ptolemy/
 *
 * Contributor(s):   
 */
/**
 * This <i>event</i> is announced by all conforming collections,
 * when any element is added to that collection. It makes two 
 * <i>context variables</i> available: <code>collection</code>
 * and <code>element</code> that are bound to the collection
 * to which the element is being added and the added element 
 * respectively. 
 * 
 * @author  Hridesh Rajan
 * @version $Revision: 1.2 $, $Date: 2010/03/01 00:30:55 $
 *
 */
public void event ElementAdded{
	Collection collection;
	Element element;
}
