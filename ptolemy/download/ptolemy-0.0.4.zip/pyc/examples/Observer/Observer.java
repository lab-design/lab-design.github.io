/***
 * An Observer with the following binding 
 *  when Event do handler;
 */
public class Observer { 
	public Observer(){
		register(this);  
	}
	public void handler(Event inner){
		System.out.println("  Inside the Observer before the proceed call #1.");
		inner.invoke();
		System.out.println("  Inside the Observer after the proceed call #1.");
		System.out.println("  Inside the Observer before the proceed call #2.");
		inner.invoke();
		System.out.println("  Inside the Observer after the proceed call #2.");
	}
        when Event do handler;
}
