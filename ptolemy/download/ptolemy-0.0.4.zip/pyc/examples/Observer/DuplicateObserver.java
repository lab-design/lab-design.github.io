/***
 * A duplicate observer class with the following binding 
 *  when Event do handler;
 */
public class DuplicateObserver { 
	public DuplicateObserver(){
	   register(this); 
	}
	public void handler(Event inner){
	   System.out.println("   Duplicate Observer before the proceed call #1.");
	   inner.invoke();
 	   System.out.println("   Duplicate Observer after the proceed call #1.");
	   System.out.println("   Duplicate Observer before the proceed call #2.");
	   inner.invoke();
	   System.out.println("   Duplicate Observer after the proceed call #2.");
	}
        when Event do handler;
}
