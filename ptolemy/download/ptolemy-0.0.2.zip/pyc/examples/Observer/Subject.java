
public class Subject {
	int f;
	/***
	 * A method, which announces an event of evtype E (ignoring the 
	 * printing i.e. all print statements) */

	  public void work() {
	     int l1 = 0, l2 = 0;
             System.out.println("Before the event statement. field val:"
                               + f + " local var1 val:" + l1 +
                               " local var2 val:" + l2);

             int x = l1, y = l2, z = f;
	     event Event {
               System.out.println("            Before the event body.");
               int i=0;
               i++;
               x = 0;
               f++;
               System.out.println("            After the event body.");
	       }

	     f++;
	     System.out.println("After the inner expression. field val:" 
				+ f + " local var1 val:" + l1 + 
				" local var2 val:" + l2);		    
	}
}

