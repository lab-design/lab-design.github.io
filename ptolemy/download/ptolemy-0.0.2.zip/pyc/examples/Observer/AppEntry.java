
public class AppEntry {
	public static void main(String args[]) {
		Subject s = new Subject();
		new Observer();
                new DuplicateObserver();
		s.work();
	}
}

