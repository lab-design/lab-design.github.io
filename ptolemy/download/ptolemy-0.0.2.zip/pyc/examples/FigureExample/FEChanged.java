/***
 * Event type FEChanged 
 */
import java.util.*;
public void evtype FEChanged {
    FigureElement changedFE;
}
