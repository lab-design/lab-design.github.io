
public class XAxis extends Line {
	public XAxis(Point p1, Point p2) {
		super(p1, p2);
	}
	public void moveBy(int dx, int dy){
		
	}
}
