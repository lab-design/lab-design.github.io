
import java.util.*;

public class Display {
	static java.util.ArrayList<FigureElement> FigElemList = 
		new ArrayList<FigureElement>();

	public static void addFigureElement(FigureElement fe) { 
		FigElemList.add(fe);
	}

	public static void update() {
		ListIterator<FigureElement>iter = FigElemList.listIterator(0);
		while(iter.hasNext()) {
			iter.next().draw();
		}
	}
}
