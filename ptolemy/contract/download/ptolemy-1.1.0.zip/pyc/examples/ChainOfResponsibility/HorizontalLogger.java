
public class HorizontalLogger{
	
	public HorizontalLogger(){
		register(this);
	}
	
	public void handler(FEChanged rest){
		invoke(rest);
		if(canHandle(rest.horizontal))
			handle(rest.changedFE);
	}
					  
	private boolean canHandle(boolean horizontal){
		if(horizontal)
			return true;
		else
			return false;
	}

	
	private void handle(FigureElement changedFE){
		System.out.println("Horizontal Change");
	}
	
	when FEChanged do handler;
}