
public interface FigureElement {
	void draw();
	void moveBy(int dx, int dy);
}
