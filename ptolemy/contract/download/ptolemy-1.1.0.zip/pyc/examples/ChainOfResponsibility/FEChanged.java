/***
 * Event type FEChanged 
 */
public void event FEChanged {
    FigureElement changedFE;
    boolean horizontal;
    
    //Translucid Contract
    requires changedFE != null
    assumes {
    	invoke(next);
    }
    ensures changedFE != null
    
}
