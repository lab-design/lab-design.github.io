
/**
 * Implements the driver for the Chain of Responsibility example.<p>
 * 
 * @author  Mehdi Bagherzadeh
 * @version $Revision: 1.2 $, $Date: 2010/03/13$
 */
public class AppEntry {
	public static void main(String args[]) {
		
		Point p1 = new Point(0,0);
		Point p2 = new Point(0,100);
		//Line l1 = new Line(p1, p2);
		
		VerticalLogger verticalLogger= new VerticalLogger();
		HorizontalLogger horizontalLogger= new HorizontalLogger();
		
		p1.setX(10);
		p1.setY(30);
	}
}

