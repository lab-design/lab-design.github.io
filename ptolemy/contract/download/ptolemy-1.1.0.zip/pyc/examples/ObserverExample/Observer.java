/*
 * This file is part of the Ptolemy project at Iowa State University.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/.
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 * 
 * For more details and the latest version of this code please see
 * http://www.cs.iastate.edu/~ptolemy/
 *
 * Contributor(s):
 */

/***
 * An Observer with the following binding 
 *  when Event do handler;
 */
public class Observer { 
	public Observer(){
		//register instances of the DuplicateObserver 
		//to be notified when events it has bindings for are announced.
		//Specifically, DuplicateObserver instances will be notified when
		//events of type Event are announce.
		register(this);  
	}
	public void handler(Event rest){
		refining preserves rest.subject == old(rest.subject){
			System.out.println("  Inside the Observer before the proceed call #1.");
		}
		//run the original body of the event announcement
		invoke(rest);
		refining preserves rest.subject == old(rest.subject){

			System.out.println("  Inside the Observer after the proceed call #1.");
			System.out.println("  Inside the Observer before the proceed call #2.");
		}
		 //run the original body of the event announcement again
		invoke(rest);
		refining preserves rest.subject == old(rest.subject){
			System.out.println("  Inside the Observer after the proceed call #2.");
		}
	}
    
	//bind the handler method to event announcements of type Event
	when Event do handler;
}
