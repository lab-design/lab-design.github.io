/* -*- Mode: Java; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*-
 *
 * This file is part of the Ptolemy project at Iowa State University.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/.
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 * 
 * For more details and the latest version of this code please see
 * http://www.cs.iastate.edu/~ptolemy/
 *
 * Contributor(s):   
 */

/**
 * Implements the driver for the Collections example.<p>
 * 
 * @author  Hridesh Rajan
 * @version $Revision: 1.2 $, $Date: 2010/03/09$
 */
public class AppEntry {
	
	public static void main(String args[]) {
		new AppEntry().test();
	}
	
	public void test(){
        System.out.println("Creating a list of integers.");		
        Collection listOfInt = new LinkedList();
        System.out.println("Creating a counter to count the elements.");		
        Counter c = new Counter();
        System.out.println("\nAdding 5 to the list of integers.");		
        listOfInt.add(new MyInteger(5));
        System.out.println("\nAdding 6 to the list of integers.");		
        listOfInt.add(new MyInteger(6));
        System.out.println("\nAdding 7 to the list of integers.");		
        Element seven = new MyInteger(7);
        listOfInt.add(seven);
        System.out.println("\nRemoving 7 from the list of integers.");		   
        listOfInt.remove(seven);
        System.out.println("\nTotal number of elements in collections (should be 2):" + c.getCount());		
	}
	
	public class MyInteger implements Element{
		int value; 
		public MyInteger(int value){ this.value = value; }
	}

}

