public class Main{
	public static void main(String[] args){
		System.out.println("[AOSD.11, Replacement Example]");
		Point p = new Point();
		Log l = new Log();
		p.setX(12);
	}
}