class Display{
	public static void update(Point p){
		System.out.println("[Display.Update]");
	}
}