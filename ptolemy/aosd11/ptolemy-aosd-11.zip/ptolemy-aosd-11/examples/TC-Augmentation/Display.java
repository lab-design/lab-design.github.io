class Display{
	public static void update(){
		System.out.println("[Display.Update]");
	}
}