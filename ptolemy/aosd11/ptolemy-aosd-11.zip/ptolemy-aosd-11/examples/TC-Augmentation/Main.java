public class Main{
	public static void main(String[] args){
		System.out.println();
		System.out.println("[AOSD.11, After Augmentation Example]");
		System.out.println();
		Point p = new Point();
		Update l = new Update();
		p.setX(12);
	}
}