public class Main{
	public static void main(String[] args){
		System.out.println();
		System.out.println("[AOSD.11, Narrowing Example]");
		System.out.println();
		Point p = new Point();
		p.fixed = true;
		Enforce l = new Enforce();
		p.setX(12);
	}
}