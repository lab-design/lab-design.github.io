public class Fig{
	public boolean fixed;
}