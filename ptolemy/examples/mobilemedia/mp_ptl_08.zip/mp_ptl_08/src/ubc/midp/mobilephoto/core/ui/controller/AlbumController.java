/*
 * Lancaster University
 * Computing Department
 * 
 * Created by Eduardo Figueiredo
 * Date: 22 Jun 2007
 * 
 */
package ubc.midp.mobilephoto.core.ui.controller;

import java.io.IOException;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.List;
import javax.microedition.rms.RecordStoreException;
import javax.microedition.rms.RecordStoreFullException;

import lancs.midp.mobilephoto.lib.exceptions.InvalidPhotoAlbumNameException;
import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;
import ubc.midp.mobilephoto.core.ui.MainUIMidlet;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import ubc.midp.mobilephoto.core.ui.screens.AlbumListScreen;
import ubc.midp.mobilephoto.core.ui.screens.NewLabelScreen;
import ubc.midp.mobilephoto.core.util.Constants;
import lancs.midp.ptolemy.exceptionblocks.dataModelAspectEH.events.*;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event.*;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.handler.*;
import lancs.midp.ptolemy.command.events.*;
import ubc.midp.mobilephoto.core.ui.controller.basecontroller.event.*;

/**
 * @author Eduardo Figueiredo
 * Added in the Scenario 04.
 * Purpose: simplify method handleCommand() in the BaseController.
 */
public class AlbumController extends AbstractController {

	public AlbumController(MainUIMidlet midlet, AlbumData albumData, AlbumListScreen albumListScreen) {
		super(midlet, albumData, albumListScreen);
		register(this);
	}
	
	/* (non-Javadoc)
	 * @see ubc.midp.mobilephoto.core.ui.controller.ControllerInterface#handleCommand(javax.microedition.lcdui.Command, javax.microedition.lcdui.Displayable)
	 */
	public boolean handleCommand(Command command) throws RecordStoreException, IOException {
		String label = command.getLabel();
      	System.out.println( "<* AlbumController.handleCommand() *>: " + label);
		
		/**
		 *  TODO [EF] I think this confirmation questions are complicating the implementation
		 *  [EF] How do you know that "Yes - Delete" is to delete Photo Album instead of Photo?
		 *  Case: Yes delete Photo Album  **/
		if (label.equals("Yes - Delete")) {
			AbstractController controler = this;
			event DeletePhotoAlbumEvent
			{
				getAlbumData().deleteAlbum(getCurrentStoreName());
			}
			goToPreviousScreen();
			return true;	
		/** 
		 * [EF] Same question. How do you know that "No - Delete" is to delete Photo Album instead of Photo?
		 * Case: No delete Photo Album **/
		}else if (label.equals("No - Delete")) {
			goToPreviousScreen();
			return true;	
		}
      	
		return false;
	}
	
    public void handler(CommandEvent next) throws Throwable {
    	switch (next.type()) {
    	case DELETEALBUM:
    		/** Case: Delete Album Photo**/
    		System.out.println("Delete Album here");
    		List down = (List) Display.getDisplay(midlet).getCurrent();
    		ScreenSingleton.getInstance().setCurrentScreenName(Constants.CONFIRMDELETEALBUM_SCREEN);
    		ScreenSingleton.getInstance().setCurrentStoreName(down.getString(down.getSelectedIndex()));
    		String message = "Would you like to remove the album "+ScreenSingleton.getInstance().getCurrentStoreName();
    		Alert deleteConfAlert = new Alert("Delete Album", message,null,AlertType.CONFIRMATION);
    		deleteConfAlert.setTimeout(Alert.FOREVER);
    		deleteConfAlert.addCommand(new Command("Yes - Delete", Command.OK, 2));
    		deleteConfAlert.addCommand(new Command("No - Delete", Command.CANCEL, 2));
    		setAlbumListAsCurrentScreen(deleteConfAlert);
    		deleteConfAlert.setCommandListener(this);
    		return;

    	case NEWPHOTOALBUM:
    		/** Case: Create PhotoAlbum **/
    		System.out.println("Create new Album here");			
    		ScreenSingleton.getInstance().setCurrentScreenName(Constants.NEWALBUM_SCREEN);
    		NewLabelScreen canv = new NewLabelScreen("Add new Album", NewLabelScreen.NEW_ALBUM);
    		setCurrentScreen(canv);
    		canv = null;
    		return;

    	case RESET:
    	    /** Case: Reset PhotoAlbum data **/
    	    resetMediaData();
    	    ScreenSingleton.getInstance().setCurrentScreenName(Constants.ALBUMLIST_SCREEN);
    		return;

    	default:
    			break;
    	}
    	next.invoke();
	}
    when CommandEvent do handler;

    /** Case: Save new Photo Album  **/
    public void handler(SaveCommandEvent next) throws Throwable {
    	next.invoke();
    	event SaveCommandExceptionEvent{
			getAlbumData().createNewAlbum(next.name());
    	}
		goToPreviousScreen();
    }
    when SaveCommandEvent do handler;

    /**
	 * This option is mainly for testing purposes. If the record store
	 * on the device or emulator gets into an unstable state, or has too 
	 * many images, you can reset it, which clears the record stores and
	 * re-creates them with the default images bundled with the application 
	 */
	private void resetMediaData() throws RecordStoreException, IOException {
		AbstractController controler = this;
		event ResetImageDataEvent
		{
			getAlbumData().resetMediaData();
		}
        
        //Clear the names from the album list
        for (int i = 0; i < getAlbumListScreen().size(); i++) {
        	getAlbumListScreen().delete(i);
        }
        
        //Get the default ones from the album
        String[] albumNames = getAlbumData().getAlbumNames();
        for (int i = 0; i < albumNames.length; i++) {
        	if (albumNames[i] != null) {
        		//Add album name to menu list
        		getAlbumListScreen().append(albumNames[i], null);
        	}
        }
        setCurrentScreen(getAlbumListScreen());
    }

    private void goToPreviousScreen() throws RecordStoreException, IOException {
	    System.out.println("<* AlbumController.goToPreviousScreen() *>");
		((AlbumListScreen)getAlbumListScreen()).repaintListAlbum(getAlbumData().getAlbumNames());
		setCurrentScreen( getAlbumListScreen() );
		ScreenSingleton.getInstance().setCurrentScreenName(Constants.ALBUMLIST_SCREEN);
    }
}
