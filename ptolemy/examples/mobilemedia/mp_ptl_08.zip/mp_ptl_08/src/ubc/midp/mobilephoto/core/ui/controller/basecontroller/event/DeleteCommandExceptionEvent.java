package ubc.midp.mobilephoto.core.ui.controller.basecontroller.event;

import ubc.midp.mobilephoto.core.ui.MainUIMidlet;

public void evtype DeleteCommandExceptionEvent {
	MainUIMidlet midlet;

}
