/*
 * Lancaster University
 * Computing Department
 * 
 * Created by Eduardo Figueiredo
 * Date: 11 Aug 2007
 * 
 */
package ubc.midp.mobilephoto.core.ui.controller;

import java.io.IOException;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.List;
import javax.microedition.rms.RecordStoreException;

import ubc.midp.mobilephoto.core.ui.MainUIMidlet;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import lancs.midp.mobilephoto.alternative.musicvideo.MediaData;
import ubc.midp.mobilephoto.core.ui.screens.AlbumListScreen;
import ubc.midp.mobilephoto.core.ui.screens.MediaListScreen;
import ubc.midp.mobilephoto.core.util.Constants;
import lancs.midp.ptolemy.exceptionblocks.controllerAspectEH.event.*;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event.*;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.handler.*;
import lancs.midp.ptolemy.command.events.*;
import ubc.midp.mobilephoto.core.ui.controller.basecontroller.event.*;

/**
 * @author Eduardo Figueiredo
 *
 */
public class MediaListController extends AbstractController {

	/**
	 * @param midlet
	 * @param nextController
	 * @param albumData
	 * @param albumListScreen
	 */
	public MediaListController(MainUIMidlet midlet, AlbumData albumData, AlbumListScreen albumListScreen) {
		super(midlet, albumData, albumListScreen);
		register(this);
	}

	/* (non-Javadoc)
	 * @see ubc.midp.mobilephoto.core.ui.controller.ControllerInterface#handleCommand(java.lang.String)
	 */
	public boolean handleCommand(Command command) throws RecordStoreException {
		return false;
	}

    public void handler(CommandActionEvent next) throws Throwable {
    	next.invoke();
    	MediaListController controller = this;
    	Command c = next.c();
    	event MediaListControllerCommandActionEvent {}
	}
    when CommandActionEvent do handler;

    public void handler(CommandEvent next) throws Throwable {
    	switch (next.type()) {
    	case SELECT:
    		/** Case: Select PhotoAlbum to view **/
    		// Get the name of the PhotoAlbum selected, and load image list from
    		// RecordStore
    		List down = (List) Display.getDisplay(midlet).getCurrent();
    		ScreenSingleton.getInstance().setCurrentStoreName(down.getString(down.getSelectedIndex()));
    		showMediaList(getCurrentStoreName());
    		ScreenSingleton.getInstance().setCurrentScreenName( Constants.IMAGELIST_SCREEN);
    		return;

    	default:
    			break;
    	}
    	next.invoke();
	}
    when CommandEvent do handler;

    /**
     * Show the list of images in the record store
	 * TODO: Refactor - Move this to ImageList class
	 */
	public void showMediaList(String recordName) throws RecordStoreException {
		MediaListController controler = this;
		MediaListController controller = this;
		event ShowImageListEvent
		{
			if (recordName == null)
				recordName = getCurrentStoreName();
			
			MediaController mediaController = new MediaController(midlet, getAlbumData(), (AlbumListScreen)getAlbumListScreen());
			mediaController.setNextController(controler);
			
			MediaListScreen imageList = new MediaListScreen();
			imageList.setCommandListener(mediaController);
			
			//Command selectCommand = new Command("Open", Command.ITEM, 1);
			imageList.initMenu();
			
			MediaData[] images = null;
			
			images = getAlbumData().getMedias(recordName);
			
			if (images==null) return;
			
			event AppendImagesEvent
			{
				//loop through array and add labels to list
				for (int i = 0; i < images.length; i++) {
					if (images[i] != null) {
						//Add album name to menu list
						
						imageList.append(images[i].getMediaLabel(), null);						
					}
				}
			}

			setCurrentScreen(imageList);
			//currentMenu = "list";
		}
	}
	
	public void postCommand(Command command) throws RecordStoreException, IOException {
        System.out.println("BaseController::postCommand - Current controller is: " + this.getClass().getName());
        //If the current controller cannot handle the command, pass it to the next
        //controller in the chain.
        if (handleCommand(command) == false) {
        	ControllerInterface next = getNextController();
            if (next != null) {
                System.out.println("Passing to next controller in chain: " + next.getClass().getName());
                next.postCommand(command);
            } else {
                System.out.println("BaseController::postCommand - Reached top of chain. No more handlers for command: " + command);
            }
        }
	}
}
