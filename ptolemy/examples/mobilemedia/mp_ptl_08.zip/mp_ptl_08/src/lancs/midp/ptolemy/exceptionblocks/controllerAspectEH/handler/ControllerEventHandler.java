package lancs.midp.ptolemy.exceptionblocks.controllerAspectEH.handler;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Display;
import javax.microedition.rms.RecordStoreFullException;

import lancs.midp.mobilephoto.lib.exceptions.*;
import ubc.midp.mobilephoto.core.ui.controller.BaseController;
import lancs.midp.ptolemy.exceptionblocks.controllerAspectEH.event.*;

public class ControllerEventHandler {
	
	public ControllerEventHandler() { register(this); }

	public void handler(DeletePhotoAlbumEvent next) throws Throwable {
		try {
			next.invoke();
		} catch (PersistenceMechanismException e) {
			Alert alert = new Alert( "Error", "The mobile database can not delete this photo album", null, AlertType.ERROR);
	        Display.getDisplay(next.controler().midlet).setCurrent(alert, Display.getDisplay(next.controler().midlet).getCurrent());
		}
		
	}
	
	when DeletePhotoAlbumEvent do handler;
	
	public void handler(ShowImageListEvent next) throws Throwable {
		try {
			next.invoke();
		} catch (UnavailablePhotoAlbumException e) {
			Alert alert = new Alert( "Error", "The list of photos can not be recovered", null, AlertType.ERROR);
			Display.getDisplay(next.controler().midlet).setCurrent(alert, Display.getDisplay(next.controler().midlet).getCurrent());
		    return;
		}
	}
	
	when ShowImageListEvent do handler;
	
	public void handler(ShowImageEvent next) throws Throwable {
		try {
			next.invoke();
		} catch (ImageNotFoundException e) {
			Alert alert = new Alert( "Error", "The selected photo was not found in the mobile device", null, AlertType.ERROR);
			Display.getDisplay(next.controler().midlet).setCurrent(alert, Display.getDisplay(next.controler().midlet).getCurrent());
	        return;
		} catch (PersistenceMechanismException e) {
			Alert alert = new Alert( "Error", "The mobile database can open this photo", null, AlertType.ERROR);
			Display.getDisplay(next.controler().midlet).setCurrent(alert, Display.getDisplay(next.controler().midlet).getCurrent());
	        return;
		}
	}
	
	when ShowImageEvent do handler;
	
	public void handler(ResetImageDataEvent next) throws Throwable {
		try
		{
			next.invoke();
		} catch (PersistenceMechanismException e) {
			Alert alert = null;
			if (e.getCause() instanceof RecordStoreFullException)
				alert = new Alert( "Error", "The mobile database is full", null, AlertType.ERROR);
			else
				alert = new Alert( "Error", "It is not possible to reset the database", null, AlertType.ERROR);
			Display.getDisplay(next.controler().midlet).setCurrent(alert, Display.getDisplay(next.controler().midlet).getCurrent());
		}	
	}
	
	when ResetImageDataEvent do handler;
}

