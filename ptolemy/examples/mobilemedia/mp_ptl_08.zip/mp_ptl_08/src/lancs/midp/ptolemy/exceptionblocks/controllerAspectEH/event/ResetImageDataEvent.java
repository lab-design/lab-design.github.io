package lancs.midp.ptolemy.exceptionblocks.controllerAspectEH.event;

import java.util.*;

import ubc.midp.mobilephoto.core.ui.controller.BaseController;

public void evtype ResetImageDataEvent {
	BaseController controler;
}
