package lancs.midp.mobilephoto.optional.capturevideo.event;

import lancs.midp.mobilephoto.optional.capturephotoandvideo.CaptureVideoScreen;

public void evtype CaptureVideoScreenCreatedEvent {
	CaptureVideoScreen listScreen;
}
