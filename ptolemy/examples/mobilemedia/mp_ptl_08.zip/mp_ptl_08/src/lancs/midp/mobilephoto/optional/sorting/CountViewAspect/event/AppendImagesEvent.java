package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event;

import ubc.midp.mobilephoto.core.ui.controller.MediaListController;
import lancs.midp.mobilephoto.alternative.musicvideo.MediaData;
import ubc.midp.mobilephoto.core.ui.screens.MediaListScreen;

public void evtype AppendImagesEvent {
	
	MediaListController controller;
	MediaData[] images;
	MediaListScreen imageList;
}
