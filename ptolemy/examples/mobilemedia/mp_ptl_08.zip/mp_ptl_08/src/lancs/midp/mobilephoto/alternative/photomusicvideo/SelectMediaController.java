// [NC] Added in the scenario 07

package lancs.midp.mobilephoto.alternative.photomusicvideo;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.List;

import ubc.midp.mobilephoto.core.ui.MainUIMidlet;
import ubc.midp.mobilephoto.core.ui.controller.AbstractController;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import lancs.midp.mobilephoto.alternative.photo.handler.*;
import lancs.midp.mobilephoto.alternative.video.handler.*;
import lancs.midp.mobilephoto.alternative.music.handler.*;
import javax.microedition.rms.RecordStoreException;
import java.io.IOException;

public class SelectMediaController extends AbstractController {

	public SelectMediaController(MainUIMidlet midlet, AlbumData imageAlbumData,	List albumListScreen) {
		super(midlet, imageAlbumData, albumListScreen);
	}
	
	public boolean handleCommand(Command command) throws IOException, RecordStoreException {
		String label = command.getLabel();
      	System.out.println( "<* SelectMediaController.handleCommand() *>: " + label);
		
     	if (label.equals("Select")) {
 			List down = (List) Display.getDisplay(midlet).getCurrent();
 	
 			if (down.getString(down.getSelectedIndex()).equals("Photos"))
 				PhotoAspectHandler.getImageController(this).init(PhotoAspectHandler.getImageAlbumData(this));
 
 			if (down.getString(down.getSelectedIndex()).equals("Music"))
 				MusicAspectHandler.getMusicController(this).init(MusicAspectHandler.getMusicAlbumData(this));
 
 			if (down.getString(down.getSelectedIndex()).equals("Videos"))
 				VideoAspectHandler.getVideoController(this).init(VideoAspectHandler.getVideoAlbumData(this));
      	}
      	return false;
	}

}
