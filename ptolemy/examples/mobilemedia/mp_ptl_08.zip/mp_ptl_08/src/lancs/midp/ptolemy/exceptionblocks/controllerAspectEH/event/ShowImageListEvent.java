package lancs.midp.ptolemy.exceptionblocks.controllerAspectEH.event;

import java.util.*;

import ubc.midp.mobilephoto.core.ui.controller.MediaListController;

public void evtype ShowImageListEvent {
	MediaListController controler;
}
