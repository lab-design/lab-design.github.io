package lancs.midp.mobilephoto.alternative.photoMusic.event;

import ubc.midp.mobilephoto.core.ui.controller.BaseController;

public boolean evtype GoToPreviousEvent {
	BaseController controller;
}
