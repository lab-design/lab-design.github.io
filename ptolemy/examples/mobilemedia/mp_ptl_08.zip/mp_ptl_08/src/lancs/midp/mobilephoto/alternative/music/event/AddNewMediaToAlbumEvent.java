package lancs.midp.mobilephoto.alternative.music.event;

import ubc.midp.mobilephoto.core.ui.controller.MediaController;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;

public void evtype AddNewMediaToAlbumEvent {
	String label;
	AlbumData albumData;
	MediaController controller;
}
