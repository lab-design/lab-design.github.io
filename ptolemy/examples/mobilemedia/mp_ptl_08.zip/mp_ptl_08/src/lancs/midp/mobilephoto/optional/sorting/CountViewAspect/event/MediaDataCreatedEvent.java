package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event;

import lancs.midp.mobilephoto.alternative.musicvideo.MediaData;

public void evtype MediaDataCreatedEvent {
	MediaData instance;
}
