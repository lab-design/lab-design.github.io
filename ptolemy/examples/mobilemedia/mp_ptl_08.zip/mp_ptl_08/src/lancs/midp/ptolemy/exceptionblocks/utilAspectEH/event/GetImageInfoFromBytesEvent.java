package lancs.midp.ptolemy.exceptionblocks.utilAspectEH.event;

import java.util.*;
import lancs.midp.mobilephoto.alternative.musicvideo.MediaData;

public MediaData evtype GetImageInfoFromBytesEvent {

}
