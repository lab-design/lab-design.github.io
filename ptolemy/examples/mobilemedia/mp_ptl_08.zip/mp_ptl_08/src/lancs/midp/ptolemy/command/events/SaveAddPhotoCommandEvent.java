package lancs.midp.ptolemy.command.events;

public void evtype SaveAddPhotoCommandEvent {
		String label;
		String path;
}
