package lancs.midp.mobilephoto.optional.sms.handler;

import java.util.HashMap;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Image;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;

import ubc.midp.mobilephoto.core.ui.datamodel.MediaAccessor;
import lancs.midp.mobilephoto.alternative.musicvideo.MediaData;
import ubc.midp.mobilephoto.core.ui.screens.AddMediaToAlbum;
import lancs.midp.mobilephoto.alternative.photo.PhotoViewScreen;
import ubc.midp.mobilephoto.core.util.MediaUtil;

import lancs.midp.mobilephoto.lib.exceptions.InvalidImageDataException;
import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;

import ubc.midp.mobilephoto.sms.*;
import lancs.midp.mobilephoto.optional.sms.event.*;
import lancs.midp.ptolemy.exceptionblocks.dataModelAspectEH.events.*;
import lancs.midp.mobilephoto.optional.copyPhoto.event.*;
import ubc.midp.mobilephoto.core.ui.controller.*;
import ubc.midp.mobilephoto.core.ui.datamodel.*;

import lancs.midp.mobilephoto.alternative.photo.handler.PhotoAspectHandler;
import lancs.midp.mobilephoto.alternative.photo.ImageMediaAccessor;
import ubc.midp.mobilephoto.core.ui.screens.*;

public class SMSAspectHandler {
	public static final Command smscopyCommand = new Command("Send Photo by SMS", Command.ITEM, 1);
	public static HashMap<PhotoViewScreen, Boolean> fromSMSHashMap = new HashMap<PhotoViewScreen, Boolean>();

	public SMSAspectHandler() { register(this); }

		public static boolean isFromSMS(PhotoViewScreen photoViewScreen){
		Boolean fromSMS = new Boolean(false);
		if(fromSMSHashMap.containsKey(photoViewScreen))
			fromSMS = fromSMSHashMap.get(photoViewScreen);
		return fromSMS.booleanValue();
	}
	
	public static void setFromSMS(PhotoViewScreen photoViewScreen, boolean fromSMS){
		Boolean fromSMSValue = null;
		if(fromSMSHashMap.containsKey(photoViewScreen))
			fromSMSValue = fromSMSHashMap.get(photoViewScreen);
			
		fromSMSValue = new Boolean(fromSMS);
	}
	
	public void handler(StartApplicationEvent next)throws Throwable{
		next.invoke();
		BaseController imageRootController = PhotoAspectHandler.imageRootController;
		AlbumData imageModel = PhotoAspectHandler.imageModel;
		
		AlbumListScreen albumListScreen = (AlbumListScreen)imageRootController.getAlbumListScreen(); // [EF]
		SmsReceiverController controller = new SmsReceiverController(next.middlet(), imageModel, albumListScreen);
		controller.setNextController(imageRootController);
		SmsReceiverThread smsR = new SmsReceiverThread(next.middlet(), imageModel, albumListScreen, controller);
		System.out.println("SmsController::Starting SMSReceiver Thread");
		new Thread(smsR).start();
	}
	when StartApplicationEvent do handler;

	public void handler(GetPhotoControllerEvent next)throws Throwable{
		next.invoke();
		SmsSenderController smscontroller = new SmsSenderController(next.controller().midlet, next.controller().getAlbumData(), 
					(AlbumListScreen)next.controller().getAlbumListScreen(), next.imageName());
		smscontroller.setNextController(next.controller());
		return;
	}
	when GetPhotoControllerEvent do handler;

	public void handler(LoadImageEvent next)throws Throwable{
		if (SMSAspectHandler.isFromSMS(next.screen())){
			   return;
		}
		else 
		{
			   next.invoke();
		}
	}
	when LoadImageEvent do handler;

	public void handler(PhotoViewScreenCreatedEvent next)throws Throwable{
		next.invoke();
		next.f().addCommand(SMSAspectHandler.smscopyCommand);
	}
	when PhotoViewScreenCreatedEvent do handler;
}
