package lancs.midp.mobilephoto.alternative.photoMusic.event;

import ubc.midp.mobilephoto.core.ui.screens.AlbumListScreen;

public void evtype InitMenuEvent {
	AlbumListScreen screen;
}
