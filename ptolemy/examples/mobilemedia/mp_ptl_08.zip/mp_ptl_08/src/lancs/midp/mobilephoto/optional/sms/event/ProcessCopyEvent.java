package lancs.midp.mobilephoto.optional.sms.event;

import lancs.midp.mobilephoto.optional.copyPhoto.PhotoViewController;
import ubc.midp.mobilephoto.core.ui.screens.AddMediaToAlbum;

public void evtype ProcessCopyEvent {
	PhotoViewController photoViewController;
	AddMediaToAlbum copyPhotoToAlbum;
}
