package lancs.midp.mobilephoto.alternative.music.event;

import ubc.midp.mobilephoto.core.ui.controller.MediaController;

public void evtype AddNewMediaToAlbumExceptionEvent {
	MediaController controller;
}
