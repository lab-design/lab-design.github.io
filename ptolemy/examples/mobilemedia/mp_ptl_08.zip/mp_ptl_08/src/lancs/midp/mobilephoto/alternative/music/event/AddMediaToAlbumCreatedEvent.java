package lancs.midp.mobilephoto.alternative.music.event;

import ubc.midp.mobilephoto.core.ui.screens.AddMediaToAlbum;

public void evtype AddMediaToAlbumCreatedEvent {
	AddMediaToAlbum screen;
}
