package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event;

import ubc.midp.mobilephoto.core.util.MediaUtil;
import lancs.midp.mobilephoto.alternative.musicvideo.MediaData;

public MediaData evtype CreateImageDataEvent {
	MediaUtil mediaUtil;
	String fidString;
	String albumLabel;
	String imageLabel; 
	int endIndex;
	String iiString;
}
