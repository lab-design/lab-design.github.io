package lancs.midp.mobilephoto.optional.copyPhoto.event;

import lancs.midp.mobilephoto.alternative.video.PlayVideoScreen;

public void evtype PlayVideoScreenCreatedEvent {
	PlayVideoScreen f;
}
