package lancs.midp.mobilephoto.optional.favourites.handler;

import java.util.HashMap;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;

import lancs.midp.mobilephoto.lib.exceptions.ImageNotFoundException;
import lancs.midp.mobilephoto.lib.exceptions.NullAlbumDataReference;

import ubc.midp.mobilephoto.core.ui.controller.*;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import lancs.midp.mobilephoto.alternative.musicvideo.MediaData;
import ubc.midp.mobilephoto.core.ui.screens.MediaListScreen;
import ubc.midp.mobilephoto.core.util.Constants;
import ubc.midp.mobilephoto.core.util.MediaUtil;

import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event.*;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event.*;

public class FavoriteEventHandler {

	public static boolean favorite = false;
	public static final Command favoriteCommand = new Command("Set Favorite", Command.ITEM, 1);
	public static final Command viewFavoritesCommand = new Command("View Favorites", Command.ITEM, 1);
	
	public static HashMap<MediaData, Boolean>  favoriteHashMap = new HashMap<MediaData, Boolean>(); 
	
	public FavoriteEventHandler() { register(this); }

	public static void toggleFavorite(MediaData imageData) {
		Boolean favoriteValue = null;
		
		if (favoriteHashMap.containsKey(imageData)){
			favoriteValue = favoriteHashMap.get(imageData);
			favoriteValue = new Boolean(!favoriteValue.booleanValue());
		}
	}
	
	/**
	 * [EF] Added in the scenario 03
	 * @param favorite
	 */
	public static void setFavorite(MediaData imageData, boolean favorite){
		Boolean favoriteValue = null;
		if (favoriteHashMap.containsKey(imageData)){
			favoriteValue = favoriteHashMap.get(imageData);
			favoriteValue = new Boolean(favorite);
		}
		else
		{
			favoriteHashMap.put(imageData, new Boolean(favorite));
		}
	}

	/**
	 * [EF] Added in the scenario 03
	 * @return the favorite
	 */
	public static boolean isFavorite(MediaData imageData){
		boolean favoriteValue = false;
		if (favoriteHashMap.containsKey(imageData)){
			favoriteValue = (favoriteHashMap.get(imageData)).booleanValue();
		}
		return favoriteValue;
	}

	public void handler(InitMenuEvent next) throws Throwable{
		next.invoke();
		next.screen().addCommand(FavoriteEventHandler.favoriteCommand);
		next.screen().addCommand(FavoriteEventHandler.viewFavoritesCommand);
	}
	when InitMenuEvent do handler;
	
	public void handler(AppendImagesEvent next) throws Throwable{
		boolean flag = true;
		// [EF] Check if favorite is true (Add in the Scenario 03)
		if (FavoriteEventHandler.favorite) {
			for (int i = 0; i < next.images().length; i++)
				if ( !(FavoriteEventHandler.isFavorite(next.images()[i])) ) 
					flag = false;
		}
		if (flag){ 
			//return invoke();
			next.invoke();
		}
		FavoriteEventHandler.favorite = false;
		//return 0;
		return;
	}
	when AppendImagesEvent do handler;
	
	public void handler(MediaControllerCommandActionEvent next) throws Throwable {
		next.invoke();
		
		System.out.println("<* FavouritesAspect.around handleCommandAction *> ::handleCommand: " + next.c().getLabel());
		
		/** Case: Set photo as favorite 
		 * [EF] Added in the scenario 03 **/
		if (next.c() == FavoriteEventHandler.favoriteCommand) {
		   	String selectedImageName = next.controller().getSelectedMediaName();
			try {
				MediaData image = next.controller().getAlbumData().mediaAccessor.getMediaInfo(selectedImageName);
				//image.toggleFavorite();
				FavoriteEventHandler.toggleFavorite(image);
				next.controller().setImage(image);
				//System.out.println("<* FavouritesAspect.handleCommand() *> Image = "+selectedImageName+ "; Favorite = "+image.isFavorite());
				System.out.println("<* FavouritesAspect.handleCommand() *> Image = "
						+selectedImageName+ "; Favorite = "+FavoriteEventHandler.isFavorite(image));
			} catch (ImageNotFoundException e) {
				Alert alert = new Alert( "Error", "The selected photo was not found in the mobile device", null, AlertType.ERROR);
				Display.getDisplay(next.controller().midlet).setCurrent(alert, Display.getDisplay(next.controller().midlet).getCurrent());
			} catch (NullAlbumDataReference e) {
				Alert alert = new Alert( "Error", "The operation is not available. Try again later !", null, AlertType.ERROR);
				Display.getDisplay(next.controller().midlet).setCurrent(alert, Display.getDisplay(next.controller().midlet).getCurrent());
			}
				
		/** Case: View favorite photos 
		 * [EF] Added in the scenario 03 **/
		} else if (next.c() == FavoriteEventHandler.viewFavoritesCommand) {
			FavoriteEventHandler.favorite = true;
			next.controller().showMediaList(next.controller().getCurrentStoreName());
			ScreenSingleton.getInstance().setCurrentScreenName(Constants.IMAGELIST_SCREEN);
		}
	}
	when MediaControllerCommandActionEvent do handler;

	public MediaData handler(CreateImageDataEvent next) throws Throwable{
		boolean favorite = false;
		int endIndex = next.endIndex();
		int startIndex = endIndex + 1;
		endIndex = next.iiString().indexOf(MediaUtil.DELIMITER, startIndex);
		
		if (endIndex == -1)
			endIndex = next.iiString().length();

		favorite = (next.iiString().substring(startIndex, endIndex)).equalsIgnoreCase("true");
		MediaData imageData = next.invoke();
		
		//imageData.setFavorite(favorite);
		FavoriteEventHandler.setFavorite(imageData, favorite);

//		System.out.println("<* FavouritesAspect.around createImageData *> ...ends");
		
		return imageData;
	}
	when CreateImageDataEvent do handler;
}
