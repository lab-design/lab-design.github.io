package lancs.midp.mobilephoto.optional.copyPhoto.event;

import ubc.midp.mobilephoto.core.ui.controller.MediaController;
import lancs.midp.mobilephoto.alternative.photo.PhotoViewScreen;

public void evtype SetPhotoScreenEvent {
	MediaController controller;
	String imageName;
	PhotoViewScreen canv;
}
