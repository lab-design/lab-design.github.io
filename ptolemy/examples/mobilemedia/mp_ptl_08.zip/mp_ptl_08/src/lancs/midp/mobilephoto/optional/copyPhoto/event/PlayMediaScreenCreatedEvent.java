package lancs.midp.mobilephoto.optional.copyPhoto.event;

import lancs.midp.mobilephoto.alternative.music.PlayMediaScreen;

public void evtype PlayMediaScreenCreatedEvent {
	PlayMediaScreen f;
}
