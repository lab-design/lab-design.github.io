package lancs.midp.ptolemy.exceptionblocks.controllerAspectEH.event;

import java.util.*;

import ubc.midp.mobilephoto.core.ui.controller.MediaController;

public void evtype ShowImageEvent {
	MediaController controler;
	String selectedImageName;
	
}
