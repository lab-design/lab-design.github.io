package lancs.midp.mobilephoto.alternative.music.handler;

import java.io.InputStream;
import java.util.HashMap;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.TextField;

import lancs.midp.mobilephoto.alternative.music.*;
import lancs.midp.mobilephoto.lib.exceptions.ImageNotFoundException;
import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;
import lancs.midp.mobilephoto.lib.exceptions.InvalidImageDataException;
import lancs.midp.mobilephoto.lib.exceptions.ImagePathNotValidException;
import javax.microedition.rms.RecordStoreFullException;
import ubc.midp.mobilephoto.core.ui.controller.*;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import lancs.midp.mobilephoto.alternative.photomusicvideo.SelectMediaController;
import lancs.midp.mobilephoto.alternative.musicvideo.*;
import ubc.midp.mobilephoto.core.ui.screens.*;
import lancs.midp.mobilephoto.optional.sms.event.*;
import lancs.midp.mobilephoto.alternative.music.event.*;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event.*;

public class MusicAspectHandler {
	public static BaseController musicRootController;
	
	public static AlbumData musicModel;
	public static HashMap<AddMediaToAlbum, TextField> addMediaToAlbumItemTypeHashMap = new  HashMap<AddMediaToAlbum, TextField>();
	public static HashMap<SelectMediaController, BaseController> musicController = new  HashMap<SelectMediaController, BaseController>();
	public static HashMap<SelectMediaController, AlbumData> musicAlbumData = new  HashMap<SelectMediaController, AlbumData>();

	public MusicAspectHandler() { register(this); }

	public static BaseController getMusicController(SelectMediaController controller) {
		return musicController.get(controller);
	}

	public static void setMusicController(SelectMediaController controller, BaseController musicControler) {
		musicController.put(controller, musicControler);
	}

	public static AlbumData getMusicAlbumData(SelectMediaController controller) {
		return musicAlbumData.get(controller);
	}

	public static void setMusicAlbumData(SelectMediaController controller, AlbumData data) {
		musicAlbumData.put(controller, data);
	}

	public static boolean playMultiMedia(MediaController mediaController, String selectedMediaName) {
		InputStream storedMusic = null;
		try {
			MediaData mymedia = mediaController.getAlbumData().getMediaInfo(selectedMediaName);
			if (mymedia instanceof MultiMediaData)
			{
				storedMusic = ((MusicAlbumData) mediaController.getAlbumData()).getMusicFromRecordStore(mediaController.getCurrentStoreName(), selectedMediaName);
				PlayMediaScreen playscree = new PlayMediaScreen(mediaController.midlet, storedMusic, ((MultiMediaData)mymedia).getTypeMedia(), musicRootController);
				MusicPlayController controller = new MusicPlayController(mediaController.midlet, mediaController.getAlbumData(), (AlbumListScreen) mediaController.getAlbumListScreen(), playscree);
				mediaController.setNextController(controller);
			}
			return true;
		} catch (ImageNotFoundException e) {
			Alert alert = new Alert( "Error", "The selected item was not found in the mobile device", null, AlertType.ERROR);
			Display.getDisplay(mediaController.midlet).setCurrent(alert, Display.getDisplay(mediaController.midlet).getCurrent());
		    return false;
		} 
		catch (PersistenceMechanismException e) {
			Alert alert = new Alert( "Error", "The mobile database can open this item 1", null, AlertType.ERROR);
			Display.getDisplay(mediaController.midlet).setCurrent(alert, Display.getDisplay(mediaController.midlet).getCurrent());
			return false;
		}
	
	}
	
	// ********  MediaListScreen  ********* //
	
	// [NC] Added in the scenario 07: to support more than one screen purpose
	public static final int PLAYMUSIC = 2;
	
	// [NC] Added in the scenario 07
	public static final Command playCommand = new Command("Play", Command.ITEM, 1);
	

	public static String getItemType(AddMediaToAlbum addMediatoAlbum) {
		TextField textField = null;
		if(addMediaToAlbumItemTypeHashMap.containsKey(addMediatoAlbum)){
			textField = addMediaToAlbumItemTypeHashMap.get(addMediatoAlbum);
			return textField.getString();
		}
		else
			return "";
	}

	public void handler(StartApplicationEvent next) throws Throwable {
		MusicAspectHandler.musicModel = new MusicAlbumData();
		
		// [NC] Added in the scenario 07
		AlbumListScreen albumMusic = new AlbumListScreen();
		MusicAspectHandler.musicRootController = new BaseController(next.middlet(), MusicAspectHandler.musicModel, albumMusic);
		
		MediaListController musicListController = new MediaListController(next.middlet(), MusicAspectHandler.musicModel, albumMusic);
		musicListController.setNextController(MusicAspectHandler.musicRootController);
		
		AlbumController albumMusicController = new AlbumController(next.middlet(), MusicAspectHandler.musicModel, albumMusic);
		albumMusicController.setNextController(musicListController);
		albumMusic.setCommandListener(albumMusicController);
		
		next.invoke();
	}
	when StartApplicationEvent do handler;
	
	public void handler(AddNewMediaToAlbumExceptionEvent next) throws Throwable {
		try
		{
			next.invoke();
		} catch (InvalidImageDataException e) {
			Alert alert = null;
			if (e instanceof ImagePathNotValidException)
				alert = new Alert("Error", "The path is not valid", null, AlertType.ERROR);
			else
				alert = new Alert("Error", "The file format is not valid", null, AlertType.ERROR);
			Display.getDisplay(next.controller().midlet).setCurrent(alert, Display.getDisplay(next.controller().midlet).getCurrent());
		} catch (PersistenceMechanismException e) {
			Alert alert = null;
			if (e.getCause() instanceof RecordStoreFullException)
				alert = new Alert("Error", "The mobile database is full", null, AlertType.ERROR);
			else
				alert = new Alert("Error", "The mobile database can not add a new photo", null, AlertType.ERROR);
			Display.getDisplay(next.controller().midlet).setCurrent(alert, Display.getDisplay(next.controller().midlet).getCurrent());
			
		} catch (ImageNotFoundException e) {
			Alert alert = new Alert("Error", "The selected item was not found in the mobile device", null, AlertType.ERROR);
			Display.getDisplay(next.controller().midlet).setCurrent(alert, Display.getDisplay(next.controller().midlet).getCurrent());
		//		return true; // TODO [EF] This should be the return value from method handleCommandAction.
		}
	}
	when AddNewMediaToAlbumExceptionEvent do handler;

	public void handler(AddMediaToAlbumCreatedEvent next) throws Throwable {
		next.invoke();
		next.screen().append(MusicAspectHandler.getItemType(next.screen()));
	}
	when AddMediaToAlbumCreatedEvent do handler;

	public void handler(AddNewMediaToAlbumEvent next) throws Throwable {
		MediaController controller = next.controller();
		event AddNewMediaToAlbumExceptionEvent {
			if (next.albumData() instanceof MusicAlbumData){
				next.albumData().loadMediaDataFromRMS( next.controller().getCurrentStoreName());
				MediaData mymedia = next.albumData().getMediaInfo(next.label());
				MultiMediaData mmedi = new MultiMediaData(mymedia, MusicAspectHandler.getItemType((AddMediaToAlbum) next.controller().getCurrentScreen()));
				next.albumData().updateMediaInfo(mymedia, mmedi);
			}
		}
		
	// TODO [EF] Replicated handlers from the method handleCommandAction in MediaController. 
		// TODO Nelio, try to reuse these handlers somehow
	}
	when AddNewMediaToAlbumEvent do handler;

	public void handler(MediaControllerCommandActionEvent next) throws Throwable {
		next.invoke();
		
		// [NC] Added in the scenario 07
		if (next.c() == MusicAspectHandler.playCommand) {
			String selectedMediaName = next.controller().getSelectedMediaName();
			MusicAspectHandler.playMultiMedia(next.controller(), selectedMediaName);		
		}
	}
	when MediaControllerCommandActionEvent do handler;

	public void handler(InitMenuEvent next) throws Throwable {
		next.invoke();
		if (next.screen().getTypeOfScreen() == MusicAspectHandler.PLAYMUSIC)
			next.screen().addCommand(MusicAspectHandler.playCommand);
	}
	when InitMenuEvent do handler;

	public MediaListScreen handler(MediaListScreenCreatedEvent next) throws Throwable {
		MediaListScreen listScreen = next.invoke();
		if (next.controller().getAlbumData() instanceof MusicAlbumData)
			listScreen.setTypeOfScreen(MusicAspectHandler.PLAYMUSIC);
		return listScreen;
	}
	when MediaListScreenCreatedEvent do handler;
}
