package lancs.midp.ptolemy.exceptionblocks.dataModelAspectEH.events;

import java.util.*;

import ubc.midp.mobilephoto.core.ui.datamodel.*;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import javax.microedition.lcdui.Image;

public Image evtype GetImageFromRecordStoreEvent {
	AlbumData album;
}
