package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Displayable;

public void evtype CommandActionEvent {
	Command c;
	Displayable d;
}
