package lancs.midp.mobilephoto.optional.sms.event;

import lancs.midp.mobilephoto.alternative.photo.PhotoViewScreen;

public void evtype LoadImageEvent {
	
	PhotoViewScreen screen; 

}
