package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event;

import javax.microedition.lcdui.Command;
import lancs.midp.mobilephoto.optional.copyPhoto.PhotoViewController;

public void evtype PhotoViewControllerCommandActionEvent {
	PhotoViewController controller;
	Command c;
}
