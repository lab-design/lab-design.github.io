package lancs.midp.mobilephoto.alternative.video.handler;

import lancs.midp.mobilephoto.alternative.video.*;
import java.io.InputStream;
import java.util.HashMap;
import javax.microedition.rms.RecordStoreException;
import java.io.IOException;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Display;

import lancs.midp.mobilephoto.alternative.musicvideo.MultiMediaData;
import lancs.midp.mobilephoto.alternative.photomusicvideo.SelectMediaController;
import lancs.midp.mobilephoto.lib.exceptions.ImageNotFoundException;
import lancs.midp.mobilephoto.lib.exceptions.InvalidImageDataException;
import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;
import ubc.midp.mobilephoto.core.ui.MainUIMidlet;
import ubc.midp.mobilephoto.core.ui.controller.AbstractController;
import ubc.midp.mobilephoto.core.ui.controller.AlbumController;
import ubc.midp.mobilephoto.core.ui.controller.BaseController;
import ubc.midp.mobilephoto.core.ui.controller.MediaController;
import ubc.midp.mobilephoto.core.ui.controller.MediaListController;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import lancs.midp.mobilephoto.alternative.musicvideo.MediaData;
import ubc.midp.mobilephoto.core.ui.screens.AlbumListScreen;
import ubc.midp.mobilephoto.core.ui.screens.MediaListScreen;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event.*;
import lancs.midp.mobilephoto.optional.sms.event.*;
import lancs.midp.mobilephoto.alternative.music.event.*;

public class VideoAspectHandler {
	public VideoAspectHandler() { register(this); }

	public static BaseController videoRootController;

	public static AlbumData videoModel;

	public static HashMap<SelectMediaController, BaseController> videoController = new  HashMap<SelectMediaController, BaseController>();
	public static HashMap<SelectMediaController, AlbumData> videoAlbumData = new  HashMap<SelectMediaController, AlbumData>();

	public static BaseController getVideoController(SelectMediaController controller) {
		return videoController.get(controller);
	}

	public static void setVideoController(SelectMediaController controller, BaseController musicController) {
		videoController.put(controller, musicController);
	}

	public static AlbumData getVideoAlbumData(SelectMediaController controller) {
		return videoAlbumData.get(controller);
	}

	public static void setVideoAlbumData(SelectMediaController controller, AlbumData data) {
		videoAlbumData.put(controller, data);
	}
	
	public void handler(StartApplicationEvent next) throws Throwable {
		System.out.println("entrou before Video ..");
		videoModel = new VideoAlbumData();
		
		AlbumListScreen albumVideo = new AlbumListScreen();
		videoRootController = new BaseController(next.middlet(), videoModel, albumVideo);
		
		MediaListController videoListController = new MediaListController(next.middlet(), videoModel, albumVideo);
		videoListController.setNextController(videoRootController);
		
		AlbumController albumVideoController = new AlbumController(next.middlet(), videoModel, albumVideo);
		albumVideoController.setNextController(videoListController);
		albumVideo.setCommandListener(albumVideoController);
		System.out.println("saiu before Video ..");
		
		next.invoke();
	}
	when StartApplicationEvent do handler;
	
	// ********  AlbumData  ********* //
	public void addVideoData(AlbumData ad, String videoname, String albumname, byte[] video) throws IOException, RecordStoreException {
		if (ad.mediaAccessor instanceof VideoMediaAccessor)
			((VideoMediaAccessor)ad.mediaAccessor).addVideoData(videoname, albumname, video);
	}
	
// ********  MediaController  ********* //
	
	public void handler(MediaControllerCommandActionEvent next) throws Throwable {
		// [NC] Added in the scenario 07
		if (next.c() == playCommand) {
			String selectedMediaName = next.controller().getSelectedMediaName();
			if (playVideoMedia(next.controller(), selectedMediaName))
				return;
		}
		next.invoke();
	}
	when MediaControllerCommandActionEvent do handler;
	
	private boolean playVideoMedia(MediaController mc, String selectedMediaName) throws IOException, RecordStoreException {
		InputStream storedMusic = null;
		try {
			MediaData mymedia = mc.getAlbumData().getMediaInfo(selectedMediaName);
			
			if (mymedia instanceof MultiMediaData)
			{
				storedMusic = ((VideoAlbumData) mc.getAlbumData()).getVideoFromRecordStore(mc.getCurrentStoreName(), selectedMediaName);
				PlayVideoScreen playscree = new PlayVideoScreen(mc.midlet, storedMusic, ((MultiMediaData)mymedia).getTypeMedia(), mc);
				playscree.setVisibleVideo();
				PlayVideoController controller = new PlayVideoController(mc.midlet, mc.getAlbumData(), (AlbumListScreen) mc.getAlbumListScreen(), playscree);
				mc.setNextController(controller);
			}
			return true;
		} catch (ImageNotFoundException e) {
			Alert alert = new Alert( "Error", "The selected item was not found in the mobile device", null, AlertType.ERROR);
			Display.getDisplay(mc.midlet).setCurrent(alert, Display.getDisplay(mc.midlet).getCurrent());
		    return false;
		} 
		catch (PersistenceMechanismException e) {
			Alert alert = new Alert( "Error", "The mobile database can open this item 1", null, AlertType.ERROR);
			Display.getDisplay(mc.midlet).setCurrent(alert, Display.getDisplay(mc.midlet).getCurrent());
			return false;
		}
	
	}
	
	// ********  MediaListScreen  ********* //
	
	// [NC] Added in the scenario 07: to support more than one screen purpose
	public static final int PLAYVIDEO = 3;
	
	// [NC] Added in the scenario 07
	public static final Command playCommand = new Command("Play Video", Command.ITEM, 1);
	
	public void handler(InitMenuEvent next) throws Throwable {
		next.invoke();
		
		if (next.screen().getTypeOfScreen() == PLAYVIDEO)
			next.screen().addCommand(playCommand);
	}
	when InitMenuEvent do handler;

	public MediaListScreen handler(MediaListScreenCreatedEvent next) throws Throwable {
		MediaListScreen listScreen = next.invoke();
		if (next.controller().getAlbumData() instanceof VideoAlbumData)
			listScreen.setTypeOfScreen(VideoAspectHandler.PLAYVIDEO);
		return listScreen;
	}
	when MediaListScreenCreatedEvent do handler;
}
