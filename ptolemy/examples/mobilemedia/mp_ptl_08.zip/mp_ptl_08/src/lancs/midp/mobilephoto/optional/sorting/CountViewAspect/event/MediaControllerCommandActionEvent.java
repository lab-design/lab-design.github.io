package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event;

import javax.microedition.lcdui.Command;
import ubc.midp.mobilephoto.core.ui.controller.MediaController;

public void evtype MediaControllerCommandActionEvent {
	MediaController controller;
	Command c;
}
