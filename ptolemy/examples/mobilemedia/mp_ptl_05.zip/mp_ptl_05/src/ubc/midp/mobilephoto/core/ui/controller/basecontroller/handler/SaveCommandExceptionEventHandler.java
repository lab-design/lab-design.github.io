package ubc.midp.mobilephoto.core.ui.controller.basecontroller.handler;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Display;
import javax.microedition.rms.RecordStoreFullException;

import lancs.midp.mobilephoto.lib.exceptions.InvalidPhotoAlbumNameException;
import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;
import ubc.midp.mobilephoto.core.ui.controller.basecontroller.event.*;

public class SaveCommandExceptionEventHandler {

	public void handler(SaveCommandExceptionEvent next)throws Throwable{
		try
		{
			next.invoke();
		}
		catch (PersistenceMechanismException e) {
			Alert alert = null;
			if (e.getCause() instanceof  RecordStoreFullException)
				alert = new Alert( "Error", "The mobile database is full", null, AlertType.ERROR);
			else
				alert = new Alert( "Error", "The mobile database can not add a new photo album", null, AlertType.ERROR);
			Display.getDisplay(next.midlet()).setCurrent(alert, Display.getDisplay(next.midlet()).getCurrent());
			return;
		} catch (InvalidPhotoAlbumNameException e) {
			Alert alert = new Alert( "Error", "You have provided an invalid Photo Album name", null, AlertType.ERROR);
			Display.getDisplay(next.midlet()).setCurrent(alert, Display.getDisplay(next.midlet()).getCurrent());
			return;
		}

	}
	
	when SaveCommandExceptionEvent do handler;
}
