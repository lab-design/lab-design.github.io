package ubc.midp.mobilephoto.core.ui.controller.basecontroller.handler;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Display;
import javax.microedition.rms.RecordStoreFullException;

import lancs.midp.mobilephoto.lib.exceptions.ImagePathNotValidException;
import lancs.midp.mobilephoto.lib.exceptions.InvalidImageDataException;
import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;
import ubc.midp.mobilephoto.core.ui.controller.basecontroller.event.*;

public class SaveAddPhotoCommandExceptionEventHandler {
	
	public void handler(SaveAddPhotoCommandExceptionEvent next)throws Throwable{
		try
		{
			next.invoke();
		} catch (InvalidImageDataException e) {
			Alert alert = null;
			if (e instanceof ImagePathNotValidException)
				alert = new Alert( "Error", "The path is not valid", null, AlertType.ERROR);
			else
				alert = new Alert( "Error", "The image file format is not valid", null, AlertType.ERROR);
			Display.getDisplay(next.midlet()).setCurrent(alert, Display.getDisplay(next.midlet()).getCurrent());
			return;
			//alert.setTimeout(5000);
		} catch (PersistenceMechanismException e) {
			Alert alert = null;
			if (e.getCause() instanceof  RecordStoreFullException)
				alert = new Alert( "Error", "The mobile database is full", null, AlertType.ERROR);
			else
				alert = new Alert( "Error", "The mobile database can not add a new photo", null, AlertType.ERROR);
			Display.getDisplay(next.midlet()).setCurrent(alert, Display.getDisplay(next.midlet()).getCurrent());
		}
	}
	
	when SaveAddPhotoCommandExceptionEvent do handler;

}
