package lancs.midp.mobilephoto.optional.copyPhoto.event;

import ubc.midp.mobilephoto.core.ui.controller.PhotoController;
import ubc.midp.mobilephoto.core.ui.screens.PhotoViewScreen;

public void evtype SetPhotoScreenEvent {
	PhotoController controller;
	String imageName;
	PhotoViewScreen canv;
}
