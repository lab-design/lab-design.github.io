package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event;

import ubc.midp.mobilephoto.core.ui.screens.PhotoListScreen;

public void evtype InitMenuEvent {
	PhotoListScreen screen;
}
