package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event;

import ubc.midp.mobilephoto.core.ui.controller.PhotoListController;
import ubc.midp.mobilephoto.core.ui.datamodel.ImageData;
import ubc.midp.mobilephoto.core.ui.screens.PhotoListScreen;

public void evtype AppendImagesEvent {
	
	PhotoListController controller;
	ImageData[] images;
	PhotoListScreen imageList;
}
