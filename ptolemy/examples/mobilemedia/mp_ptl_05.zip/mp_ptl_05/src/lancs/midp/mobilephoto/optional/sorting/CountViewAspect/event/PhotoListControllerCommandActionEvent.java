package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event;

import javax.microedition.lcdui.Command;
import ubc.midp.mobilephoto.core.ui.controller.PhotoListController;

public void evtype PhotoListControllerCommandActionEvent {
	PhotoListController controller;
	Command c;
}
