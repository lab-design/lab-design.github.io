package lancs.midp.ptolemy;

public class EventHandlerController {
	public static void init() {
		// ControllerAspectEH
		new lancs.midp.ptolemy.exceptionblocks.controllerAspectEH.handler.ControllerEventHandler();

		// DataModelAspectEH
		new lancs.midp.ptolemy.exceptionblocks.dataModelAspectEH.handler.DataModelEventHandler();

		// UtilAspectEH
		new lancs.midp.ptolemy.exceptionblocks.utilAspectEH.handler.utilEventHandler();

		//
		// declare precedence : CopyPhotoAspect, FavouritesAspect, CountViewsAspect, PersisteFavoritesAspect
		//

		// CopyPhotoAspect
		new lancs.midp.mobilephoto.optional.copyPhoto.handler.CopyPhotoHandler();

		// FavoritesAspect
		new lancs.midp.mobilephoto.optional.favourites.handler.FavoriteEventHandler();
		
		// CountViewsAspect
		new lancs.midp.mobilephoto.optional.sorting.CountViewAspect.handler.CountViewEventHandler();
		
		// PersisteFavoriteAspect
		new lancs.midp.mobilephoto.optional.favourites.handler.PersisteFavoritesEventHandler();
	}
}
