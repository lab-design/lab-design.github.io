package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event;

import ubc.midp.mobilephoto.core.ui.datamodel.ImageData;

public void evtype ImageDataCreatedEvent {
	ImageData instance;
}
