package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event;

import ubc.midp.mobilephoto.core.ui.datamodel.ImageData;

public String evtype GetBytesFromImageInfoEvent {
	ImageData ii;
}
