package lancs.midp.ptolemy.exceptionblocks.utilAspectEH.event;

import java.util.*;
import ubc.midp.mobilephoto.core.ui.datamodel.ImageData;

public ImageData evtype GetImageInfoFromBytesEvent {

}
