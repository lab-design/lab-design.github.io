package lancs.midp.mobilephoto.optional.favourites.handler;

import ubc.midp.mobilephoto.core.ui.datamodel.ImageData;
import ubc.midp.mobilephoto.core.util.ImageUtil;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event.*;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event.*;

public class PersisteFavoritesEventHandler{
	
	public PersisteFavoritesEventHandler() { register(this); }

	public String handler(GetBytesFromImageInfoEvent next) throws Throwable{
			
			String byteString = next.invoke();
			
			// [EF] Added in scenario 03
			byteString = byteString.concat(ImageUtil.DELIMITER);
			if (FavoriteEventHandler.isFavorite(next.ii())) byteString = byteString.concat("true");
			else byteString = byteString.concat("false");
			
	//		System.out.println("<* FavouritesAspect.around getBytesFromImageInfo *> ...ends");
			
			return byteString;
	}
	when GetBytesFromImageInfoEvent do handler;
}
