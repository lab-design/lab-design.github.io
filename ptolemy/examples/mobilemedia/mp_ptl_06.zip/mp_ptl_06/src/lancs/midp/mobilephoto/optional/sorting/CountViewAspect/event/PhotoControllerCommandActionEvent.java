package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event;

import javax.microedition.lcdui.Command;
import ubc.midp.mobilephoto.core.ui.controller.PhotoController;

public void evtype PhotoControllerCommandActionEvent {
	PhotoController controller;
	Command c;
}
