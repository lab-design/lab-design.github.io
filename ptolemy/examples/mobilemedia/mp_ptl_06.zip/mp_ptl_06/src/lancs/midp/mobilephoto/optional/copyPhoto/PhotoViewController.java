/*
 * Lancaster University
 * Computing Department
 * 
 * Created by Eduardo Figueiredo
 * Date: 22 Jul 2007
 * 
 */
package lancs.midp.mobilephoto.optional.copyPhoto;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Display;
import javax.microedition.rms.RecordStoreException;
import javax.microedition.rms.RecordStoreFullException;

import lancs.midp.mobilephoto.lib.exceptions.ImageNotFoundException;
import lancs.midp.mobilephoto.lib.exceptions.ImagePathNotValidException;
import lancs.midp.mobilephoto.lib.exceptions.InvalidImageDataException;
import lancs.midp.mobilephoto.lib.exceptions.NullAlbumDataReference;
import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;
import lancs.midp.mobilephoto.optional.copyPhoto.handler.CopyPhotoHandler;
import ubc.midp.mobilephoto.core.ui.MainUIMidlet;
import ubc.midp.mobilephoto.core.ui.controller.AbstractController;
import ubc.midp.mobilephoto.core.ui.controller.PhotoController;
import ubc.midp.mobilephoto.core.ui.controller.ScreenSingleton;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import ubc.midp.mobilephoto.core.ui.datamodel.ImageAccessor;
import ubc.midp.mobilephoto.core.ui.datamodel.ImageData;
import ubc.midp.mobilephoto.core.ui.screens.AddPhotoToAlbum;
import ubc.midp.mobilephoto.core.ui.screens.AlbumListScreen;
import ubc.midp.mobilephoto.core.util.Constants;
import lancs.midp.ptolemy.command.events.*;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event.*;
import lancs.midp.mobilephoto.optional.sms.event.*;

/**
 * @author Eduardo Figueiredo
 * [EF] Added in Scenario 05
 */
public class PhotoViewController extends AbstractController {

	String imageName = "";
	
	/**
	 * @param midlet
	 * @param nextController
	 * @param albumData
	 * @param albumListScreen
	 * @param currentScreenName
	 */
	public PhotoViewController(MainUIMidlet midlet, AlbumData albumData, AlbumListScreen albumListScreen, String imageName) {
		super(midlet, albumData, albumListScreen);
		this.imageName = imageName;
	}

	/* (non-Javadoc)
	 * @see ubc.midp.mobilephoto.core.ui.controller.ControllerInterface#handleCommand(javax.microedition.lcdui.Command, javax.microedition.lcdui.Displayable)
	 */
	public boolean handleCommand(Command c) {
		return false;
	}

	/** Case: Copy photo to a different album */
	public void handler(PhotoControllerCommandActionEvent next) throws Throwable {
		next.invoke();
		if (next.c() == CopyPhotoHandler.copyCommand) {
			PhotoViewController photoViewController = this;
			AddPhotoToAlbum copyPhotoToAlbum = new AddPhotoToAlbum("Copy Photo to Album");
			event ProcessCopyEvent {
				copyPhotoToAlbum.setPhotoName(imageName);
				copyPhotoToAlbum.setLabelPhotoPath("Copy to Album:");
			}
	        Display.getDisplay(midlet).setCurrent(copyPhotoToAlbum);
		}
	}
	when PhotoControllerCommandActionEvent do handler;

	/** Case: Save a copy in a new album */
	public void handler(SaveAddPhotoCommandEvent next) throws Throwable {
		next.invoke();
		try {
			ImageData imageData = null;
			try {
				imageData = getAlbumData().getImageAccessor().getImageInfo(imageName);
			} catch (ImageNotFoundException e) {
				e.printStackTrace();
			} catch (NullAlbumDataReference e) {
				e.printStackTrace();
			}
			String photoname = next.label();
			String albumname = next.path();
			ImageAccessor imageAccessor = getAlbumData().getImageAccessor();
			CopyPhotoHandler.addImageData(imageAccessor, photoname, imageData, albumname);
		} catch (InvalidImageDataException e) {
			Alert alert = null;
			if (e instanceof ImagePathNotValidException)
				alert = new Alert("Error", "The path is not valid", null, AlertType.ERROR);
			else
				alert = new Alert("Error", "The image file format is not valid", null, AlertType.ERROR);
			Display.getDisplay(midlet).setCurrent(alert, Display.getDisplay(midlet).getCurrent());
			// alert.setTimeout(5000);
		} catch (PersistenceMechanismException e) {
			Alert alert = null;
			if (e.getCause() instanceof RecordStoreFullException)
				alert = new Alert("Error", "The mobile database is full", null, AlertType.ERROR);
			else
				alert = new Alert("Error", "The mobile database can not add a new photo", null, AlertType.ERROR);
			Display.getDisplay(midlet).setCurrent(alert, Display.getDisplay(midlet).getCurrent());
		}
		try {
			((PhotoController)this.getNextController()).showImageList(ScreenSingleton.getInstance().getCurrentStoreName());
		} catch (RecordStoreException e) {
			e.printStackTrace();
		}
	    ScreenSingleton.getInstance().setCurrentScreenName(Constants.IMAGELIST_SCREEN);
	}
	when SaveAddPhotoCommandEvent do handler;
}
