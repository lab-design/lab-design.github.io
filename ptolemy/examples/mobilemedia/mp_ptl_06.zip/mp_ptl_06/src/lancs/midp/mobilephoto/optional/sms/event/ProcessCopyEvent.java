package lancs.midp.mobilephoto.optional.sms.event;

import lancs.midp.mobilephoto.optional.copyPhoto.PhotoViewController;
import ubc.midp.mobilephoto.core.ui.screens.AddPhotoToAlbum;

public void evtype ProcessCopyEvent {
	PhotoViewController photoViewController;
	AddPhotoToAlbum copyPhotoToAlbum;
}
