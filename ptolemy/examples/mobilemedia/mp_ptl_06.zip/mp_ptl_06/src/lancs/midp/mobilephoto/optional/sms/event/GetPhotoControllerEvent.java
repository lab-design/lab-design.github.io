package lancs.midp.mobilephoto.optional.sms.event;

import ubc.midp.mobilephoto.core.ui.controller.PhotoController;

public void evtype GetPhotoControllerEvent {
	
	PhotoController controller;
	String imageName;
}
