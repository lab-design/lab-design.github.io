package lancs.midp.mobilephoto.optional.copyPhoto.handler;

import javax.microedition.lcdui.Command;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;
import javax.microedition.rms.RecordStoreNotOpenException;

import ubc.midp.mobilephoto.core.ui.controller.PhotoController;
import ubc.midp.mobilephoto.core.ui.datamodel.ImageAccessor;
import ubc.midp.mobilephoto.core.ui.datamodel.ImageData;
import ubc.midp.mobilephoto.core.ui.screens.PhotoViewScreen;
import ubc.midp.mobilephoto.core.util.ImageUtil;
import lancs.midp.mobilephoto.lib.exceptions.InvalidImageDataException;
import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;
import lancs.midp.mobilephoto.optional.copyPhoto.PhotoViewController;
import lancs.midp.mobilephoto.optional.copyPhoto.event.*;

public class CopyPhotoHandler {

	public CopyPhotoHandler() { register(this); }

	/* [EF] Added in scenario 05 */
	public static final Command copyCommand = new Command("Copy", Command.ITEM, 1);
	
	public static void addImageData(ImageAccessor imageAccessor, String photoname, ImageData imageData, String albumname) throws InvalidImageDataException, PersistenceMechanismException {
		try {
			imageAccessor.imageRS = RecordStore.openRecordStore(imageAccessor.ALBUM_LABEL + albumname, true);
			imageAccessor.imageInfoRS = RecordStore.openRecordStore(imageAccessor.INFO_LABEL + albumname, true);
			int rid2; // new record ID for ImageData (metadata)
			ImageUtil converter = new ImageUtil();
			rid2 = imageAccessor.imageInfoRS.getNextRecordID();
			imageData.setRecordId(rid2);
			byte[] data1 = converter.getBytesFromImageInfo(imageData).getBytes();
			imageAccessor.imageInfoRS.addRecord(data1, 0, data1.length);
		} catch (RecordStoreException e) {
			throw new PersistenceMechanismException();
		}finally{
			try {
				imageAccessor.imageRS.closeRecordStore();
				imageAccessor.imageInfoRS.closeRecordStore();
			} catch (RecordStoreNotOpenException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (RecordStoreException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void handler(SetPhotoScreenEvent next)throws Throwable {
		PhotoViewController control = new PhotoViewController(next.controller().midlet, next.controller().getAlbumData(), next.controller().getAlbumListScreen(), next.imageName());
		control.setNextController(next.controller());
	
		next.invoke();
	}
	when SetPhotoScreenEvent do handler;

	public void handler(PhotoViewScreenCreatedEvent next) throws Throwable{
		next.invoke();
		
		next.f().addCommand(CopyPhotoHandler.copyCommand);
	}
	when PhotoViewScreenCreatedEvent do handler;
}
