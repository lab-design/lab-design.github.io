package lancs.midp.ptolemy.exceptionblocks.controllerAspectEH.event;

import java.util.*;

import ubc.midp.mobilephoto.core.ui.controller.PhotoListController;

public void evtype ShowImageListEvent {
	PhotoListController controler;
}
