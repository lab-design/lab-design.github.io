package ubc.midp.mobilephoto.core.ui.screens;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.TextField;
import javax.microedition.lcdui.CommandListener;
import lancs.midp.ptolemy.command.events.*;

public class AddPhotoToAlbum extends Form implements CommandListener {
	
	TextField labeltxt = new TextField("Photo label", "", 15, TextField.ANY);
	TextField photopathtxt = new TextField("Path", "", 20, TextField.ANY);
	
	Command ok;
	Command cancel;

	public AddPhotoToAlbum(String title) {
		super(title);
		this.append(labeltxt);
		this.append(photopathtxt);
		ok = new Command("Save Add Photo", Command.SCREEN, 0);
		cancel = new Command("Cancel", Command.EXIT, 1);
		this.addCommand(ok);
		this.addCommand(cancel);
		setCommandListener(this);
	}

	public void commandAction(Command c, Displayable d) {
		if (c==cancel) {
			CommandType type = CommandType.CANCEL;
			event CommandEvent {}
		}
		else if (c==ok) {
			String label = labeltxt.getString();
			String path = photopathtxt.getString();
			event SaveAddPhotoCommandEvent {}
		}
	}
}
