/**
 * 
 */
package ubc.midp.mobilephoto.core.ui.controller;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.rms.RecordStoreException;

import ubc.midp.mobilephoto.core.ui.datamodel.ImageData;
import ubc.midp.mobilephoto.core.ui.screens.NewLabelScreen;
import ubc.midp.mobilephoto.core.util.Constants;
import lancs.midp.ptolemy.command.events.*;

/**
 * @author E Figueiredo
 * Add in the Scenario 02
 */
public class PhotoController {

	private BaseController nextController;
	private ImageData image;

	public PhotoController (ImageData image, BaseController nextController) {
		this.image = image;
		this.nextController = nextController;
	}

    public void handler(SaveLabelCommandEvent next) throws Throwable {
    	next.invoke();
      	System.out.println( "<* PhotoController.handleCommand() *> Save Photo Label = "+next.name());
		getImage().setImageLabel(next.name());
		nextController.updateImage(image);
		goToPreviousScreen();
    }
    when SaveLabelCommandEvent do handler;

   /**
     * Go to the previous screen
 * @throws RecordStoreException 
	 */
    private void goToPreviousScreen() throws RecordStoreException {
	    System.out.println("<* PhotoController.goToPreviousScreen() *>");
	    this.nextController.showImageList(null);
	    this.nextController.setCurrentScreenName(Constants.IMAGELIST_SCREEN);
    } 

	/**
	 * @param image the image to set
	 */
	public void setImage(ImageData image) {
		this.image = image;
	}

	/**
	 * @return the image
	 */
	public ImageData getImage() {
		return image;
	}

}
