package lancs.midp.ptolemy;


public class EventHandlerController {
	public static void init() {
		// Controller Aspect
		new lancs.midp.ptolemy.exceptionblocks.controllerAspectEH.handler.ControllerEventHandler();

		// DataModel Aspect
		new lancs.midp.ptolemy.exceptionblocks.dataModelAspectEH.handler.DataModelEventHandler();

		// Util Aspect
		new lancs.midp.ptolemy.exceptionblocks.utilAspectEH.handler.utilEventHandler();

		// CountViews Aspect
		new lancs.midp.mobilephoto.optional.sorting.CountViewAspect.handler.CountViewEventHandler();
	}
}
