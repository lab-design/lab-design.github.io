package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event;

import ubc.midp.mobilephoto.core.util.ImageUtil;
import ubc.midp.mobilephoto.core.ui.datamodel.ImageData;

public ImageData evtype CreateImageDataEvent {
	ImageUtil imageUtil;
	String fidString;
	String albumLabel;
	String imageLabel; 
	int endIndex;
	String iiString;
}
