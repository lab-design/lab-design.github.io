package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.handler;

import java.util.Hashtable;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;

import ubc.midp.mobilephoto.core.ui.controller.BaseController;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import ubc.midp.mobilephoto.core.ui.datamodel.ImageData;
import ubc.midp.mobilephoto.core.ui.screens.PhotoListScreen;
import ubc.midp.mobilephoto.core.util.Constants;

import lancs.midp.mobilephoto.lib.exceptions.ImageNotFoundException;
import lancs.midp.mobilephoto.lib.exceptions.NullAlbumDataReference;
import ubc.midp.mobilephoto.core.util.ImageUtil;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event.*;
import lancs.midp.ptolemy.exceptionblocks.controllerAspectEH.event.*;

public class CountViewEventHandler {
	
	
	public static boolean sort = false;
	public static final Command sortCommand = new Command("Sort by Views", Command.ITEM, 1);
	
	public static Hashtable<ImageData,Integer> numberOfViews = new Hashtable<ImageData,Integer>();
	
	public CountViewEventHandler() {
		register(this); 
	}
	
	public void handler(ShowImageEvent next) throws Throwable {
		next.invoke();
		
			ImageData image = next.controler().getModel().getImageAccessor().getImageInfo(next.selectedImageName());
			CountViewEventHandler.numberOfViews.put(image, new Integer(CountViewEventHandler.numberOfViews.get(image)+1));
			next.controler().getModel().getImageAccessor().updateImageInfo(image, image);
			System.out.println("<* BaseController.handleCommand() *> Image = "+next.selectedImageName()+ "; # views = "
					+CountViewEventHandler.numberOfViews.get(image));
	}
	
	when ShowImageEvent do handler;

	public void handler(InitMenuEvent next)throws Throwable{
		next.invoke();
		next.screen().addCommand(CountViewEventHandler.sortCommand);
	}
	
	when InitMenuEvent do handler;	

	//public String getBytesFromImageInfoEventHandler(GetBytesFromImageInfoEvent next){
	public void handler(GetBytesFromImageInfoEvent next) throws Throwable{
		String byteString = "";
		next.invoke();
		
		// [EF] Added in scenatio 02
		byteString = byteString.concat(ImageUtil.DELIMITER);
		byteString = byteString.concat("" + CountViewEventHandler.numberOfViews.get(next.ii()));
		
		//return byteString;
		return;
		
	}
	
	when GetBytesFromImageInfoEvent do handler;


	public ImageData handler(CreateImageDataEvent next) throws Throwable {

		int endIndex = next.endIndex();
		int startIndex = endIndex + 1;
		endIndex = next.iiString().indexOf(ImageUtil.DELIMITER, startIndex);
		
		if (endIndex == -1)
			endIndex = next.iiString().length();
		
		// [EF] Added in the scenario 02 
		int numberOfViews = 0;
		try {
			numberOfViews = Integer.parseInt(next.iiString().substring(startIndex, endIndex));
		} catch (RuntimeException e) {
			numberOfViews = 0;
			e.printStackTrace();
		}
		
		ImageData imageData = next.invoke();
		
		CountViewEventHandler.numberOfViews.put(imageData, new Integer(numberOfViews));

		return imageData;
	}
	
	when CreateImageDataEvent do handler;

	public void handler(ControllerCommandActionEvent next)throws Throwable
	{ 
		next.invoke();
		if (next.c()==CountViewEventHandler.sortCommand) {
	    	CountViewEventHandler.sort = true;
			next.controller().showImageList(next.controller().getCurrentStoreName());
			next.controller().setCurrentStoreName(Constants.IMAGELIST_SCREEN);
		}
	}
	
	when ControllerCommandActionEvent do handler;

	//public void appendImagesEventHandler(BaseController controller, ImageData[] images, PhotoListScreen imageList){
	public void handler(AppendImagesEvent next) throws Throwable{
		
		if (CountViewEventHandler.sort) {
			bubbleSort(next.images());
		}
		CountViewEventHandler.sort = false;
		
		next.invoke();
	}


	private void bubbleSort(ImageData[] images) {
		System.out.print("Sorting by BubbleSort...");		
		for (int end = images.length; end > 1; end --) {
			for (int current = 0; current < end - 1; current ++) {
				if (CountViewEventHandler.numberOfViews.get(images[current]) > CountViewEventHandler.numberOfViews.get(images[current+1])) {
					exchange(images, current, current+1);
				}
			}
		}
		System.out.println("done.");
	}
	
	private void exchange(ImageData[] images, int pos1, int pos2) {
		ImageData tmp = images[pos1];
		images[pos1] = images[pos2];
		images[pos2] = tmp;
	}

	
	when AppendImagesEvent do handler;

	

	
}
