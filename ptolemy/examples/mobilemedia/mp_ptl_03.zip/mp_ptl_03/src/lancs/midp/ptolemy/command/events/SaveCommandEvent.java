package lancs.midp.ptolemy.command.events;

public void evtype SaveCommandEvent {
	String name;
}
