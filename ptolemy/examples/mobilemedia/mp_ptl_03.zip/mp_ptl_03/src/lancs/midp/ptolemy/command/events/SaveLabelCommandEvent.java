package lancs.midp.ptolemy.command.events;

public void evtype SaveLabelCommandEvent {
	String name;
}
