package lancs.midp.mobilephoto.alternative.photoMusic.handler;

import javax.microedition.lcdui.Display;

import lancs.midp.mobilephoto.alternative.music.handler.MusicAspectHandler;
import lancs.midp.mobilephoto.alternative.photo.handler.PhotoAspectHandler;
import lancs.midp.mobilephoto.alternative.photoMusic.SelectMediaController;
import lancs.midp.mobilephoto.alternative.photoMusic.SelectTypeOfMedia;
import ubc.midp.mobilephoto.core.ui.controller.BaseController;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import ubc.midp.mobilephoto.core.ui.screens.AlbumListScreen;
import lancs.midp.mobilephoto.optional.sms.event.*;
import ubc.midp.mobilephoto.core.ui.controller.ScreenSingleton;
import ubc.midp.mobilephoto.core.util.Constants;
import lancs.midp.mobilephoto.alternative.photoMusic.event.*;

public class PhotoAndMusicAspectHandler {
	private static SelectTypeOfMedia mainscreen;
	
	public PhotoAndMusicAspectHandler() { register(this); }

	public static SelectTypeOfMedia getMainMenu(){
		return mainscreen;
	}
	
	public static void setMainMenu(SelectTypeOfMedia screen){
		mainscreen = screen;
	}

	public boolean handler(GoToPreviousEvent next) throws Throwable {
		boolean returned = next.invoke();
		if (returned) 
			return true;
		
    	String currentScreenName = ScreenSingleton.getInstance().getCurrentScreenName();
		// [NC] Added in the scenario 07
		if ((currentScreenName == null) || (currentScreenName.equals(Constants.ALBUMLIST_SCREEN))) {	
			next.controller().setCurrentScreen( PhotoAndMusicAspectHandler.getMainMenu() );
			return true;
		}

		return false;
	}
	when GoToPreviousEvent do handler;

	public void handler(StartApplicationEvent next) throws Throwable {
		next.invoke();
		
		BaseController imageRootController = PhotoAspectHandler.imageRootController;
		AlbumData imageModel = PhotoAspectHandler.imageModel;

		BaseController musicRootController = MusicAspectHandler.musicRootController;
		AlbumData musicModel = MusicAspectHandler.musicModel;

		AlbumListScreen albumListScreen = (AlbumListScreen)imageRootController.getAlbumListScreen();
		
		// [NC] Added in the scenario 07
		SelectMediaController selectcontroller = new SelectMediaController(next.middlet(), imageModel, musicModel, albumListScreen, imageRootController, musicRootController);
		selectcontroller.setNextController(imageRootController);
		
		SelectTypeOfMedia mainscreen = new SelectTypeOfMedia();
		mainscreen.initMenu();
		Display.getDisplay(next.middlet()).setCurrent(mainscreen);
		PhotoAndMusicAspectHandler.setMainMenu(mainscreen);
	}
	when StartApplicationEvent do handler;
}
