package lancs.midp.mobilephoto.alternative.photoMusic.handler;

import javax.microedition.lcdui.Command;
import lancs.midp.mobilephoto.alternative.photoMusic.event.*;

public class PhotoOrMusicEventHandler {
	public static final Command exitCommand = new Command("Back", Command.STOP, 2);

	public PhotoOrMusicEventHandler() { register(this); }

	public void handler(InitMenuEvent next) throws Throwable {
		next.screen().addCommand(exitCommand);
		next.invoke();
	}
	when InitMenuEvent do handler;
}
