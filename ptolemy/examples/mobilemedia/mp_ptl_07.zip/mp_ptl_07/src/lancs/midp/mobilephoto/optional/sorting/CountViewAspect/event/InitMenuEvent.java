package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event;

import ubc.midp.mobilephoto.core.ui.screens.MediaListScreen;

public void evtype InitMenuEvent {
	MediaListScreen screen;
}
