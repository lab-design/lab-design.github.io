package lancs.midp.mobilephoto.optional.copyPhoto.handler;

import javax.microedition.lcdui.Command;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;
import javax.microedition.rms.RecordStoreNotOpenException;

import ubc.midp.mobilephoto.core.ui.controller.MediaController;
import ubc.midp.mobilephoto.core.ui.datamodel.MediaAccessor;
import ubc.midp.mobilephoto.core.ui.datamodel.MediaData;
import lancs.midp.mobilephoto.alternative.photo.PhotoViewScreen;
import ubc.midp.mobilephoto.core.util.MediaUtil;
import lancs.midp.mobilephoto.lib.exceptions.InvalidImageDataException;
import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;
import lancs.midp.mobilephoto.optional.copyPhoto.MediaViewController;
import lancs.midp.mobilephoto.optional.copyPhoto.event.*;

public class CopyPhotoHandler {
	/* [EF] Added in scenario 05 */
	public static final Command copyCommand = new Command("Copy", Command.ITEM, 1);
	
	public CopyPhotoHandler() { register(this); }

	public static void addMediaData(MediaAccessor imageAccessor, String photoname, MediaData imageData, String albumname) throws InvalidImageDataException, PersistenceMechanismException {
		try {
			imageAccessor.imageRS = RecordStore.openRecordStore(imageAccessor.album_label + albumname, true);
			imageAccessor.imageInfoRS = RecordStore.openRecordStore(imageAccessor.info_label + albumname, true);
			int rid2; // new record ID for ImageData (metadata)
			MediaUtil converter = new MediaUtil();
			rid2 = imageAccessor.imageInfoRS.getNextRecordID();
			imageData.setRecordId(rid2);
			byte[] data1 = converter.getBytesFromMediaInfo(imageData).getBytes();
			imageAccessor.imageInfoRS.addRecord(data1, 0, data1.length);
		} catch (RecordStoreException e) {
			throw new PersistenceMechanismException();
		}finally{
			try {
				imageAccessor.imageRS.closeRecordStore();
				imageAccessor.imageInfoRS.closeRecordStore();
			} catch (RecordStoreNotOpenException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (RecordStoreException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void handler(PhotoViewScreenCreatedEvent next) throws Throwable{
		next.invoke();
		
		next.f().addCommand(CopyPhotoHandler.copyCommand);
	}
	when PhotoViewScreenCreatedEvent do handler;

	public void handler(SetPhotoScreenEvent next)throws Throwable {
		MediaViewController control = new MediaViewController(next.controller().midlet, next.controller().getAlbumData(), next.controller().getAlbumListScreen(), next.imageName());
		control.setNextController(next.controller());
	
		next.invoke();
	}
	when SetPhotoScreenEvent do handler;
}
