/*
 * Lancaster University
 * Computing Department
 * 
 * Created by Eduardo Figueiredo
 * Date: 22 Jul 2007
 * 
 */
package lancs.midp.mobilephoto.optional.copyPhoto;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.List;
import javax.microedition.rms.RecordStoreException;
import javax.microedition.rms.RecordStoreFullException;

import lancs.midp.mobilephoto.lib.exceptions.ImageNotFoundException;
import lancs.midp.mobilephoto.lib.exceptions.ImagePathNotValidException;
import lancs.midp.mobilephoto.lib.exceptions.InvalidImageDataException;
import lancs.midp.mobilephoto.lib.exceptions.NullAlbumDataReference;
import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;
import lancs.midp.mobilephoto.optional.copyPhoto.handler.CopyPhotoHandler;
import ubc.midp.mobilephoto.core.ui.MainUIMidlet;
import ubc.midp.mobilephoto.core.ui.controller.AbstractController;
import ubc.midp.mobilephoto.core.ui.controller.MediaController;
import ubc.midp.mobilephoto.core.ui.controller.ScreenSingleton;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import ubc.midp.mobilephoto.core.ui.datamodel.MediaAccessor;
import ubc.midp.mobilephoto.core.ui.datamodel.MediaData;
import ubc.midp.mobilephoto.core.ui.screens.AddMediaToAlbum;
import ubc.midp.mobilephoto.core.ui.screens.AlbumListScreen;
import ubc.midp.mobilephoto.core.util.Constants;
import lancs.midp.ptolemy.command.events.*;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event.*;
import lancs.midp.mobilephoto.optional.sms.event.*;

/**
 * @author Eduardo Figueiredo
 * [EF] Added in Scenario 05
 */
public class MediaViewController extends AbstractController {

	String imageName = "";
	
	/**
	 * @param midlet
	 * @param nextController
	 * @param albumData
	 * @param albumListScreen
	 * @param currentScreenName
	 */
	public MediaViewController(MainUIMidlet midlet, AlbumData albumData, List albumListScreen, String imageName) {
		super(midlet, albumData, albumListScreen);
		this.imageName = imageName;
	}

	/* (non-Javadoc)
	 * @see ubc.midp.mobilephoto.core.ui.controller.ControllerInterface#handleCommand(javax.microedition.lcdui.Command, javax.microedition.lcdui.Displayable)
	 */
	public boolean handleCommand(Command c) {
		return false;
	}

	/** Case: Copy photo to a different album */
	public void handler(MediaControllerCommandActionEvent next) throws Throwable {
		next.invoke();
		if (next.c() == CopyPhotoHandler.copyCommand) {
			MediaViewController photoViewController = this;
			AddMediaToAlbum copyPhotoToAlbum = new AddMediaToAlbum("Copy Photo to Album");
			event ProcessCopyEvent {
				copyPhotoToAlbum.setPhotoName(imageName);
				copyPhotoToAlbum.setLabelPhotoPath("Copy to Album:");
			}
	        Display.getDisplay(midlet).setCurrent(copyPhotoToAlbum);
		}
	}
	when MediaControllerCommandActionEvent do handler;

	/** Case: Save a copy in a new album */
	public void handler(SaveAddPhotoCommandEvent next) throws Throwable {
		next.invoke();
		try {
			MediaData imageData = null;
			try {
				imageData = getAlbumData().mediaAccessor.getMediaInfo(imageName);
			} catch (ImageNotFoundException e) {
				e.printStackTrace();
			} catch (NullAlbumDataReference e) {
				e.printStackTrace();
			}
			String photoname = next.label();
			String albumname = next.path();
			MediaAccessor imageAccessor = getAlbumData().mediaAccessor;
			CopyPhotoHandler.addMediaData(imageAccessor, photoname, imageData, albumname);
		} catch (InvalidImageDataException e) {
			Alert alert = null;
			if (e instanceof ImagePathNotValidException)
				alert = new Alert("Error", "The path is not valid", null, AlertType.ERROR);
			else
				alert = new Alert("Error", "The image file format is not valid", null, AlertType.ERROR);
			Display.getDisplay(midlet).setCurrent(alert, Display.getDisplay(midlet).getCurrent());
			// alert.setTimeout(5000);
		} catch (PersistenceMechanismException e) {
			Alert alert = null;
			if (e.getCause() instanceof RecordStoreFullException)
				alert = new Alert("Error", "The mobile database is full", null, AlertType.ERROR);
			else
				alert = new Alert("Error", "The mobile database can not add a new photo", null, AlertType.ERROR);
			Display.getDisplay(midlet).setCurrent(alert, Display.getDisplay(midlet).getCurrent());
		}
		try {
			((MediaController)this.getNextController()).showMediaList(ScreenSingleton.getInstance().getCurrentStoreName());
		} catch (RecordStoreException e) {
			e.printStackTrace();
		}
	    ScreenSingleton.getInstance().setCurrentScreenName(Constants.IMAGELIST_SCREEN);
	}
	when SaveAddPhotoCommandEvent do handler;
}
