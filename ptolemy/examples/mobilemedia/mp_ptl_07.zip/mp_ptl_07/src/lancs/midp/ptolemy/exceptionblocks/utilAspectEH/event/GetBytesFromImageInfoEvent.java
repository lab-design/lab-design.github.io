package lancs.midp.ptolemy.exceptionblocks.utilAspectEH.event;

import java.util.*;

public String evtype GetBytesFromImageInfoEvent {

}
