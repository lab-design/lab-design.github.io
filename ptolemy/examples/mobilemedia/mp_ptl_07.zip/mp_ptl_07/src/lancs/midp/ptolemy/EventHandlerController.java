package lancs.midp.ptolemy;

public class EventHandlerController {
	public static void init() {
		// ControllerAspectEH
		new lancs.midp.ptolemy.exceptionblocks.controllerAspectEH.handler.ControllerEventHandler();

		// DataModelAspectEH
		new lancs.midp.ptolemy.exceptionblocks.dataModelAspectEH.handler.DataModelEventHandler();

		// UtilAspectEH
		new lancs.midp.ptolemy.exceptionblocks.utilAspectEH.handler.utilEventHandler();

		//
		// declare precedence : SMSAspect, CopyPhotoAspect, FavouritesAspect, CountViewsAspect, PersisteFavoritesAspect
		//

		// CopyPhotoAspect
		new lancs.midp.mobilephoto.optional.copyPhoto.handler.CopyPhotoHandler();

		// FavoritesAspect
		new lancs.midp.mobilephoto.optional.favourites.handler.FavoriteEventHandler();
		
		// CountViewsAspect
		new lancs.midp.mobilephoto.optional.sorting.CountViewAspect.handler.CountViewEventHandler();
		
		// PersisteFavoriteAspect
		new lancs.midp.mobilephoto.optional.favourites.handler.PersisteFavoritesEventHandler();

		// SMSAspect
		new lancs.midp.mobilephoto.optional.sms.handler.SMSAspectHandler();

		// PhotoAspect
		new lancs.midp.mobilephoto.alternative.photo.handler.PhotoAspectHandler();
		
		// MusicAspect
		new lancs.midp.mobilephoto.alternative.music.handler.MusicAspectHandler();
		
		// PhotoOrMusicAspect
		new lancs.midp.mobilephoto.alternative.photoMusic.handler.PhotoOrMusicEventHandler();

		// PhotoAndMusicAspect
		new lancs.midp.mobilephoto.alternative.photoMusic.handler.PhotoAndMusicAspectHandler();
	}
}
