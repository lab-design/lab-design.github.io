package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.handler;

import java.util.Hashtable;
import javax.microedition.lcdui.Command;
import ubc.midp.mobilephoto.core.ui.datamodel.MediaData;
import ubc.midp.mobilephoto.core.util.*;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event.*;
import lancs.midp.mobilephoto.alternative.photo.*;
import lancs.midp.ptolemy.exceptionblocks.controllerAspectEH.event.*;

public class CountViewEventHandler {
	public static boolean sort = false;
	public static final Command sortCommand = new Command("Sort by Views", Command.ITEM, 1);
	
	public static Hashtable<MediaData,Integer> numberOfViews = new Hashtable<MediaData,Integer>();

	public void handler(ShowImageEvent next) throws Throwable {
		next.invoke();
		
		MediaData image = next.controler().getAlbumData().mediaAccessor.getMediaInfo(next.selectedImageName());
			CountViewEventHandler.numberOfViews.put(image, new Integer(CountViewEventHandler.numberOfViews.get(image)+1));
			next.controler().getAlbumData().mediaAccessor.updateMediaInfo(image, image);
			System.out.println("<* BaseController.handleCommand() *> Image = "+next.selectedImageName()+ "; # views = "
					+CountViewEventHandler.numberOfViews.get(image));
	}
	when ShowImageEvent do handler;

	public void handler(InitMenuEvent next)throws Throwable{
		next.invoke();
		next.screen().addCommand(CountViewEventHandler.sortCommand);
	}
	when InitMenuEvent do handler;	

	public String handler(GetBytesFromImageInfoEvent next) throws Throwable{
		String byteString = next.invoke();
		
		// [EF] Added in scenatio 02
		byteString = byteString.concat(MediaUtil.DELIMITER);
		byteString = byteString.concat("" + CountViewEventHandler.numberOfViews.get(next.ii()));
		
		return byteString;
	}
	when GetBytesFromImageInfoEvent do handler;
	
	public MediaData handler(CreateImageDataEvent next) throws Throwable {

		int endIndex = next.endIndex();
		int startIndex = endIndex + 1;
		endIndex = next.iiString().indexOf(MediaUtil.DELIMITER, startIndex);
		
		if (endIndex == -1)
			endIndex = next.iiString().length();
		
		// [EF] Added in the scenario 02 
		int numberOfViews = 0;
		try {
			numberOfViews = Integer.parseInt(next.iiString().substring(startIndex, endIndex));
		} catch (RuntimeException e) {
			numberOfViews = 0;
			e.printStackTrace();
		}
		
		MediaData imageData = next.invoke();
		
		CountViewEventHandler.numberOfViews.put(imageData, new Integer(numberOfViews));

		return imageData;
	}
	
	when CreateImageDataEvent do handler;
	
	public void handler(MediaListControllerCommandActionEvent next)throws Throwable
	{ 
		next.invoke();
		if (next.c()==CountViewEventHandler.sortCommand) {
	    	CountViewEventHandler.sort = true;
			next.controller().showMediaList(next.controller().getCurrentStoreName());
			next.controller().setCurrentStoreName(Constants.IMAGELIST_SCREEN);
		}
	}
	
	when MediaListControllerCommandActionEvent do handler;
	
	public void handler(AppendImagesEvent next) throws Throwable{
		if (CountViewEventHandler.sort) {
			bubbleSort(next.images());
		}
		CountViewEventHandler.sort = false;
		
		next.invoke();
	}
	when AppendImagesEvent do handler;

	private void bubbleSort(MediaData[] images) {
		System.out.print("Sorting by BubbleSort...");		
		for (int end = images.length; end > 1; end --) {
			for (int current = 0; current < end - 1; current ++) {
				if (CountViewEventHandler.numberOfViews.get(images[current]) > CountViewEventHandler.numberOfViews.get(images[current+1])) {
					exchange(images, current, current+1);
				}
			}
		}
		System.out.println("done.");
	}
	
	private void exchange(MediaData[] images, int pos1, int pos2) {
		MediaData tmp = images[pos1];
		images[pos1] = images[pos2];
		images[pos2] = tmp;
	}
}
