package lancs.midp.mobilephoto.optional.sms.event;

import ubc.midp.mobilephoto.core.ui.MainUIMidlet;

public void evtype StartApplicationEvent {
	MainUIMidlet middlet;
}
