package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event;

import ubc.midp.mobilephoto.core.ui.datamodel.MediaData;

public void evtype MediaDataCreatedEvent {
	MediaData instance;
}
