package ubc.midp.mobilephoto.core.ui.controller.basecontroller.event;

import ubc.midp.mobilephoto.core.ui.MainUIMidlet;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;

public void evtype EditLabelCommandExceptionEvent {
	MainUIMidlet midlet;
	AlbumData model;

}
