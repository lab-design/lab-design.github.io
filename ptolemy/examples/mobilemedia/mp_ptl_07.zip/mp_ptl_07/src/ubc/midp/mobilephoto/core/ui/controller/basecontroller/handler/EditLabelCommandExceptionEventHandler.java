package ubc.midp.mobilephoto.core.ui.controller.basecontroller.handler;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Display;

import lancs.midp.mobilephoto.lib.exceptions.ImageNotFoundException;
import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;
import ubc.midp.mobilephoto.core.ui.controller.basecontroller.event.*;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import lancs.midp.mobilephoto.lib.exceptions.NullAlbumDataReference;

public class EditLabelCommandExceptionEventHandler {
	
	public void handler(EditLabelCommandExceptionEvent next) throws Throwable{
		try{
			next.invoke();
		} catch (ImageNotFoundException e) {
			Alert alert = new Alert( "Error", "The selected photo was not found in the mobile device", null, AlertType.ERROR);
			Display.getDisplay(next.midlet()).setCurrent(alert, Display.getDisplay(next.midlet()).getCurrent());
		} catch (NullAlbumDataReference e) {
//			next.model() = new AlbumData();
			Alert alert = new Alert( "Error", "The operation is not available. Try again later !", null, AlertType.ERROR);
			Display.getDisplay(next.midlet()).setCurrent(alert, Display.getDisplay(next.midlet()).getCurrent());
		}
	}
	
	when EditLabelCommandExceptionEvent do handler;

}
