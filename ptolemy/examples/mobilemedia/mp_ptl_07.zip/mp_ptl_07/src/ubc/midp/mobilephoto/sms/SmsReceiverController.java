package ubc.midp.mobilephoto.sms;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Image;

import lancs.midp.mobilephoto.optional.copyPhoto.MediaViewController;
import ubc.midp.mobilephoto.core.ui.MainUIMidlet;
import ubc.midp.mobilephoto.core.ui.controller.AbstractController;
import ubc.midp.mobilephoto.core.ui.controller.ScreenSingleton;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import ubc.midp.mobilephoto.core.ui.screens.AlbumListScreen;
import lancs.midp.mobilephoto.alternative.photo.PhotoViewScreen;
import ubc.midp.mobilephoto.core.util.Constants;
import lancs.midp.mobilephoto.optional.sms.handler.*;
import javax.microedition.rms.RecordStoreException;
import java.io.IOException;
import lancs.midp.ptolemy.command.events.*;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event.*;

public class SmsReceiverController extends AbstractController {
	byte[] incomingImageData;
	
	public SmsReceiverController(MainUIMidlet midlet, AlbumData albumData, AlbumListScreen albumListScreen) {
		super(midlet, albumData, albumListScreen);
		register(this);
	}

 	/**
	 * Handle SMS specific events.
	 * If we are given a standard command that is handled by the BaseController, pass 
	 * the handling off to our super class with the else clause
	 */

	public boolean handleCommand(Command c) throws IOException, RecordStoreException {
		String label = c.getLabel();
      	System.out.println("SmsReceiverController::handleCommand: " + label);
	    
      	if (label.equals("Ok"))
	    {
      		((AlbumListScreen)getAlbumListScreen()).repaintListAlbum(getAlbumData().getAlbumNames());
			setCurrentScreen( getAlbumListScreen() );
			ScreenSingleton.getInstance().setCurrentScreenName(Constants.ALBUMLIST_SCREEN);
			return true;
	    }

	    return false;
	}

	public void handler(CommandActionEvent next) throws Throwable {
      	if (next.c() == SmsReceiverThread.acceptPhotoCommand) {	
		      	Image image = Image.createImage(incomingImageData, 0, incomingImageData.length);
		       	Image copy = Image.createImage(image.getWidth(), image.getHeight()); 
		     	PhotoViewScreen canv = new PhotoViewScreen(copy);
		     	SMSAspectHandler.setFromSMS(canv, true);
				new MediaViewController(this.midlet, getAlbumData(), getAlbumListScreen(), "NoName");
				this.setCurrentScreen(canv);
	      } else if (next.c() == SmsReceiverThread.rejectPhotoCommand) {
		      	//TODO: Go back to whatever screen they were previously on?
		      	System.out.println("Reject Photo command");
		      	((AlbumListScreen)getAlbumListScreen()).repaintListAlbum(getAlbumData().getAlbumNames());
				setCurrentScreen( getAlbumListScreen() );
				ScreenSingleton.getInstance().setCurrentScreenName(Constants.ALBUMLIST_SCREEN);
	      }
	}
	when CommandActionEvent do handler;

	public void setIncommingData(byte[] incomingImageData){
		this.incomingImageData = incomingImageData;
	}
}