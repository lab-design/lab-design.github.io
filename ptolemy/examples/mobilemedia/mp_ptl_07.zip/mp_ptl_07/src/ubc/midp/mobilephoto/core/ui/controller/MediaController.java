/*
 * Lancaster University
 * Computing Department
 * 
 * Created by Eduardo Figueiredo
 * Date: 17 Jun 2007
 * 
 */
package ubc.midp.mobilephoto.core.ui.controller;

import java.io.IOException;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.List;
import javax.microedition.rms.RecordStoreException;
import javax.microedition.rms.RecordStoreFullException;

import lancs.midp.mobilephoto.lib.exceptions.ImageNotFoundException;
import lancs.midp.mobilephoto.lib.exceptions.ImagePathNotValidException;
import lancs.midp.mobilephoto.lib.exceptions.InvalidImageDataException;
import lancs.midp.mobilephoto.lib.exceptions.NullAlbumDataReference;
import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;
import ubc.midp.mobilephoto.core.ui.MainUIMidlet;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import ubc.midp.mobilephoto.core.ui.datamodel.MediaData;
import ubc.midp.mobilephoto.core.ui.screens.AddMediaToAlbum;
import ubc.midp.mobilephoto.core.ui.screens.AlbumListScreen;
import ubc.midp.mobilephoto.core.ui.screens.NewLabelScreen;
import lancs.midp.mobilephoto.alternative.photo.PhotoViewScreen;
import ubc.midp.mobilephoto.core.util.Constants;

import lancs.midp.ptolemy.exceptionblocks.controllerAspectEH.event.*;
import lancs.midp.mobilephoto.optional.copyPhoto.event.*;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event.*;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.handler.*;
import lancs.midp.ptolemy.command.events.*;
import ubc.midp.mobilephoto.core.ui.controller.basecontroller.event.*;

/**
 * @author Eduardo Figueiredo
 * Added in the Scenario 02
 */
public class MediaController extends MediaListController {

	private MediaData image;

	public MediaController (MainUIMidlet midlet, AlbumData albumData, AlbumListScreen albumListScreen) {
		super(midlet, albumData, albumListScreen);
		register(this);
	}

	public boolean handleCommand(Command command) throws RecordStoreException {
		return false;
	}

    public void handler(CommandEvent next) throws Throwable {
    	switch (next.type()) {
    	case BACK:
    	case CANCEL:
    	    /** Case: Go to the Previous or Fallback screen **/
    	    /** Case: Cancel the current screen and go back one**/
    		if (goToPreviousScreen())
    			return;
    		else
    			break;

    	case ADD:
    	    /** Case: Add photo  **/
    		ScreenSingleton.getInstance().setCurrentScreenName(Constants.ADDPHOTOTOALBUM_SCREEN);
    		AddMediaToAlbum form = new AddMediaToAlbum("Add new Media to Album");
    		form.setCommandListener(this);
    		setCurrentScreen(form);
    		return;

    	case DELETE:
    	{
    		/** Case: Delete selected Photo from recordstore **/
        	String selectedImageName = getSelectedMediaName();
          	event DeleteCommandExceptionEvent
          	{
        		getAlbumData().deleteMedia(getCurrentStoreName(), selectedImageName);
         	}
    		showMediaList(getCurrentStoreName());
    		ScreenSingleton.getInstance().setCurrentScreenName(Constants.IMAGELIST_SCREEN);
    	}
    		return;

    	case EDITLABEL:
    	{
    	    /** Case: Edit photo label 
    		 * [EF] Added in the scenario 02 **/
    			String selectedImageName = getSelectedMediaName();
    			AlbumData model = getAlbumData();
    			MediaController controller = this;
    			event EditLabelCommandExceptionEvent {
    				image = getAlbumData().mediaAccessor.getMediaInfo(
    						selectedImageName);
    				// PhotoController photoController = new PhotoController(image,
    				// this);
    				NewLabelScreen formScreen = new NewLabelScreen(
    						"Edit Label", NewLabelScreen.LABEL_PHOTO);
    				formScreen.setCommandListener(controller);
    				setCurrentScreen(formScreen);
    				formScreen = null;
    			}
    	}
    		return;

    	default:
    			break;
    	}
    	next.invoke();
	}
    when CommandEvent do handler;

    /** Case: Save Add photo  **/
	public void handler(SaveAddPhotoCommandEvent next) throws Throwable {
		next.invoke();
		event SaveAddPhotoCommandExceptionEvent{
			getAlbumData().addNewMediaToAlbum(next.label(), 
					next.path(), getCurrentStoreName());
		}
		goToPreviousScreen();
	}
	when SaveAddPhotoCommandEvent do handler;

	// [EF] Scenario 02: Increase visibility (package to public) in order to give access to aspect CountViewsAspect
	public void updateMedia(MediaData image) throws IOException, RecordStoreException {
		getAlbumData().updateMediaInfo(image, image);
	}
	
    /**
     * Get the last selected image from the Photo List screen.
	 * TODO: This really only gets the selected List item. 
	 * So it is only an image name if you are on the PhotoList screen...
	 * Need to fix this
	 */
	public String getSelectedMediaName() {
		List selected = (List) Display.getDisplay(midlet).getCurrent();
		if (selected == null)
		    System.out.println("Current List from display is NULL!");
		String name = selected.getString(selected.getSelectedIndex());
		return name;
	}

   /**
    * TODO [EF] update this method or merge with method of super class.
     * Go to the previous screen
	 */
    private boolean goToPreviousScreen() throws RecordStoreException {
	    System.out.println("<* PhotoController.goToPreviousScreen() *>");
		String currentScreenName = ScreenSingleton.getInstance().getCurrentScreenName();
	    if (currentScreenName.equals(Constants.ALBUMLIST_SCREEN)) {
		    System.out.println("Can't go back here...Should never reach this spot");
		} else if (currentScreenName.equals(Constants.IMAGE_SCREEN)) {		    
		    //Go to the image list here, not the main screen...
		    showMediaList(getCurrentStoreName());
		    ScreenSingleton.getInstance().setCurrentScreenName(Constants.IMAGELIST_SCREEN);
		    return true;
		}
    	else if (currentScreenName.equals(Constants.ADDPHOTOTOALBUM_SCREEN)) {
    		showMediaList(getCurrentStoreName());
		    ScreenSingleton.getInstance().setCurrentScreenName(Constants.IMAGELIST_SCREEN);
		    return true;
    	}
	    return false;
    } 

	/**
	 * @param image the image to set
	 */
	public void setImage(MediaData image) {
		this.image = image;
	}

	/**
	 * @return the image
	 */
	public MediaData getImage() {
		return image;
	}

}
