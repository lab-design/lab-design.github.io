package lancs.midp.ptolemy;

public class EventHandlerController {
	public static void init() {
		// ControllerAspectEH
		new lancs.midp.ptolemy.exceptionblocks.controllerAspectEH.handler.ControllerEventHandler();

		// DataModelAspectEH
		new lancs.midp.ptolemy.exceptionblocks.dataModelAspectEH.handler.DataModelEventHandler();

		// UtilAspectEH
		new lancs.midp.ptolemy.exceptionblocks.utilAspectEH.handler.utilEventHandler();

		//
		// declare precedence : FavouritesAspect, CountViewsAspect, PersisteFavoritesAspect
		//

		// FavoritesAspect
		new lancs.midp.mobilephoto.optional.favourites.handler.FavoriteEventHandler();
		
		// CountViewsAspect
		new lancs.midp.mobilephoto.optional.sorting.CountViewAspect.handler.CountViewEventHandler();
		
		// PersisteFavoriteAspect
		new lancs.midp.mobilephoto.optional.favourites.handler.PersisteFavoritesEventHandler();
	}
}
