package lancs.midp.ptolemy.exceptionblocks.controllerAspectEH.event;

import java.util.*;

import ubc.midp.mobilephoto.core.ui.controller.BaseController;

public void evtype ShowImageEvent {
	BaseController controler;
	String selectedImageName;
	
}
