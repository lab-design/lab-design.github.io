/*
 * Created on Sep 13, 2004
 *
 */
package ubc.midp.mobilephoto.core.ui.screens;

import javax.microedition.lcdui.Choice;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.List;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import lancs.midp.ptolemy.command.events.*;
import lancs.midp.mobilephoto.alternative.photoMusic.event.*;

/**
 * @author trevor
 *
 * This screen displays a list of photo albums available to select.
 * A user can also create a new album on this screen.
 * TODO: Add delete photo album option
 * 
 */
public class AlbumListScreen extends List implements CommandListener {

	public static final Command selectCommand = new Command("Select", Command.ITEM, 1);
	public static final Command createAlbumCommand = new Command("New Album", Command.ITEM, 1);
	public static final Command deleteAlbumCommand = new Command("Delete Album", Command.ITEM, 1);
	public static final Command resetCommand = new Command("Reset", Command.ITEM, 1);
	

	/**
	 * Constructor
	 */
	public AlbumListScreen() {
		super("Select Album", Choice.IMPLICIT);
		setCommandListener(this);
	}
	
	
	/**
	 * Initialize the menu items for this screen
	 * 
	 */
	public void initMenu() {
		AlbumListScreen screen = this;
		event InitMenuEvent {
			screen.addCommand(selectCommand);
			screen.addCommand(createAlbumCommand);
			screen.addCommand(deleteAlbumCommand);
			screen.addCommand(resetCommand);
		}
	}

	public void deleteAll(){
		for (int i = 0; i < this.size(); i++) {
			this.delete(i);
		} 
	}
	
	public void repaintListAlbum(String[] names){
		String[] albumNames = names;
	    this.deleteAll();
		for (int i = 0; i < albumNames.length; i++) {
			if (albumNames[i] != null) {
				//Add album name to menu list
				this.append(albumNames[i], null);
			}
		}
	}


	
	public void commandAction(Command c, Displayable d) {
		if (c== selectCommand) {
			CommandType type = CommandType.SELECT;
			event CommandEvent {}
		}
		else if (c== createAlbumCommand) {
			CommandType type = CommandType.NEWPHOTOALBUM;
			event CommandEvent {}
		}
		else if (c==deleteAlbumCommand) {
			CommandType type = CommandType.DELETE;
			event CommandEvent {}
		}
		else if (c==resetCommand) {
			CommandType type = CommandType.RESET;
			event CommandEvent {}
		}
	}
}
