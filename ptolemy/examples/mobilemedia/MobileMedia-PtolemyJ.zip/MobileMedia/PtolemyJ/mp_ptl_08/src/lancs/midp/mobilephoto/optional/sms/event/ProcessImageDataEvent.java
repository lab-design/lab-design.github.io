package lancs.midp.mobilephoto.optional.sms.event;

import lancs.midp.mobilephoto.optional.copyPhoto.PhotoViewController;
import ubc.midp.mobilephoto.core.ui.datamodel.MediaAccessor;

public void evtype ProcessImageDataEvent {
	PhotoViewController photoViewController;
	MediaAccessor mediaAccessor;
	String photoName;
	String albumname;
}
