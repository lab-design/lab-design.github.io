package lancs.midp.mobilephoto.lib.exceptions;

public class InvalidPhotoAlbumNameException extends RuntimeException {

	public InvalidPhotoAlbumNameException() {
	}

	public InvalidPhotoAlbumNameException(String s) {
		super(s);
	}
}
