package lancs.midp.mobilephoto.alternative.photoMusic.handler;

import javax.microedition.lcdui.Command;
import lancs.midp.mobilephoto.alternative.photoMusic.event.*;

public class PhotoOrMusicOrVideoEventHandler {
	public static final Command exitCommand = new Command("Back", Command.STOP, 2);

	public PhotoOrMusicOrVideoEventHandler() { register(this); }

	public void handler(InitMenuEvent next) throws Throwable {
		next.screen().addCommand(exitCommand);
		next.invoke();
	}
	when InitMenuEvent do handler;
}
