package lancs.midp.mobilephoto.optional.sms.event;

import ubc.midp.mobilephoto.core.ui.controller.MediaController;

public void evtype GetPhotoControllerEvent {
	
	MediaController controller;
	String imageName;
}
