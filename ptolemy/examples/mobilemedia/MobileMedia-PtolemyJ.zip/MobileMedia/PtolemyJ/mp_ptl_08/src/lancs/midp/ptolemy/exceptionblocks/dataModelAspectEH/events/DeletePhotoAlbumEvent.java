package lancs.midp.ptolemy.exceptionblocks.dataModelAspectEH.events;

import java.util.*;

public void evtype DeletePhotoAlbumEvent {

}
