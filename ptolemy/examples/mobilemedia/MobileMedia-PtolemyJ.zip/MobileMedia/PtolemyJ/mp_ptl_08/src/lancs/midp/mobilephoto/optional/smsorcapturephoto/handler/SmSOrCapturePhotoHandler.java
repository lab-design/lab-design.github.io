package lancs.midp.mobilephoto.optional.smsorcapturephoto.handler;

import javax.microedition.rms.RecordStoreException;
import java.io.IOException;
import lancs.midp.mobilephoto.lib.exceptions.InvalidImageDataException;
import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import lancs.midp.mobilephoto.alternative.photo.ImageMediaAccessor;

public class SmSOrCapturePhotoHandler {
	public static void addImageData(AlbumData ad, String photoname, byte[] imgdata, String albumname) throws IOException, RecordStoreException {
		if (ad.mediaAccessor instanceof ImageMediaAccessor)
			addImageData((ImageMediaAccessor)ad.mediaAccessor, photoname, imgdata, albumname);
	}
	
	public static void addImageData(ImageMediaAccessor ima, String photoname, byte[] imgdata, String albumname) throws IOException, RecordStoreException {
			ima.addMediaArrayOfBytes(photoname, albumname, imgdata);
	}
}
