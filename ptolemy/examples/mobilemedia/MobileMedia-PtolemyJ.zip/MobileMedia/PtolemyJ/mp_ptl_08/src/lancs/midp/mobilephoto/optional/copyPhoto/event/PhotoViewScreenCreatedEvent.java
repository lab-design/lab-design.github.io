package lancs.midp.mobilephoto.optional.copyPhoto.event;

import lancs.midp.mobilephoto.alternative.photo.PhotoViewScreen;

public void evtype PhotoViewScreenCreatedEvent {
	PhotoViewScreen f;
}
