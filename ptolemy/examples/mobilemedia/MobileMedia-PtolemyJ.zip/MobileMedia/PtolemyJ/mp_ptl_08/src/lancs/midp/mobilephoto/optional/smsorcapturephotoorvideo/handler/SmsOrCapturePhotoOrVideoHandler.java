package lancs.midp.mobilephoto.optional.smsorcapturephotoorvideo.handler;

import java.util.Hashtable;
import lancs.midp.mobilephoto.alternative.musicvideo.MediaData;
import ubc.midp.mobilephoto.core.ui.screens.AddMediaToAlbum;
import lancs.midp.mobilephoto.alternative.photo.PhotoViewScreen;
import lancs.midp.mobilephoto.lib.exceptions.InvalidImageDataException;
import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;
import lancs.midp.mobilephoto.optional.copyPhoto.PhotoViewController;
import lancs.midp.mobilephoto.optional.sms.event.*;
import lancs.midp.mobilephoto.optional.sms.handler.*;
import lancs.midp.mobilephoto.optional.smsorcapturephoto.handler.*;

public class SmsOrCapturePhotoOrVideoHandler {
	 private static Hashtable<AddMediaToAlbum, byte[]> CapturedMedia = new Hashtable<AddMediaToAlbum, byte[]>();
	 
	 private static Hashtable<PhotoViewScreen, byte[]> byteImage = new Hashtable<PhotoViewScreen, byte[]>();
	 
	 public static byte[] getCapturedMedia(AddMediaToAlbum alb) {
			return CapturedMedia.get(alb);
		}

	public static void setCapturedMedia(AddMediaToAlbum alb, byte[] capturedMedia) {
			CapturedMedia.put(alb, capturedMedia);
	}
	
	public static  byte[] getImage(PhotoViewScreen ps){
		return byteImage.get(ps);
	}
	
	public static void setImage(PhotoViewScreen ps, byte[] img){
		byteImage.put(ps, img);
	}
	
	public void SmsOrCapturePhotoOrVideoHandler() { register(this); }

	public void handler(ProcessCopyEvent next) throws Throwable {
		next.invoke();
		if (SMSAspectHandler.isFromSMS((PhotoViewScreen)next.photoViewController().getCurrentScreen())){
			setCapturedMedia(next.copyPhotoToAlbum(), getImage((PhotoViewScreen)next.photoViewController().getCurrentScreen()));
		}
	}
	when ProcessCopyEvent do handler;

	public void handler(ProcessImageDataEvent next) throws Throwable {
		byte[] imgByte= getCapturedMedia((AddMediaToAlbum)next.photoViewController().getCurrentScreen());
		if (imgByte == null){
		   next.invoke();
		}else{
			SmSOrCapturePhotoHandler.addImageData(next.photoViewController().getAlbumData(), next.photoName(), imgByte, next.albumname());
		}		
		return;
	}
	when ProcessImageDataEvent do handler;
}
