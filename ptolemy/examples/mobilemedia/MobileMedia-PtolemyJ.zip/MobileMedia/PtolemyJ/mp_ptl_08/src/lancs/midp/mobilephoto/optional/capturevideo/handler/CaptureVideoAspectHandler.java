package lancs.midp.mobilephoto.optional.capturevideo.handler;

import java.io.ByteArrayOutputStream;

import javax.microedition.lcdui.Command;
import javax.microedition.media.control.RecordControl;

import ubc.midp.mobilephoto.core.ui.controller.MediaController;
import ubc.midp.mobilephoto.core.ui.screens.AlbumListScreen;
import ubc.midp.mobilephoto.core.ui.screens.MediaListScreen;
import lancs.midp.mobilephoto.optional.capturephotoandvideo.CaptureVideoScreen;
import lancs.midp.mobilephoto.optional.capturevideo.event.*;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event.*;
import lancs.midp.mobilephoto.optional.capturevideo.*;
import lancs.midp.mobilephoto.alternative.video.handler.*;

public class CaptureVideoAspectHandler {
	public static Command start = new Command("Start", Command.EXIT, 1);
	public static Command stop = new Command("Stop", Command.ITEM, 1);
	
	void CaptureVideoAspectHandler() { register(this); }

	public void handler(CaptureVideoScreenCreatedEvent next) throws Throwable {
		// [NC] Added in the scenario 08
		if (next.listScreen().typescreen == CAPTUREVIDEO){
			next.listScreen().addCommand(start);
			next.listScreen().addCommand(stop);
		}
	}
	when CaptureVideoScreenCreatedEvent do handler;
	
	public static void startCapture(CaptureVideoScreen cvs) {
		try {
			if (!cvs.recording) {
				cvs.rControl = (RecordControl) cvs.capturePlayer
						.getControl("RecordControl");
				if (cvs.rControl == null)
					throw new Exception("No RecordControl found!");
				cvs.byteOfArray = new ByteArrayOutputStream();
				cvs.rControl.setRecordStream(cvs.byteOfArray);
				cvs.rControl.startRecord();
				cvs.recording = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void pauseCapture(CaptureVideoScreen cvs) {
		try {
			if (cvs.recording) {
				cvs.rControl.stopRecord();
				cvs.rControl.commit();
				cvs.recording = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static byte[] getByteArrays(CaptureVideoScreen cvs) {
		return cvs.byteOfArray.toByteArray();
	}
	
	// ********  MediaListScreen  ********* //
	
	// [NC] Added in the scenario 08 
	public static Command captureVideoCommand = new Command("Capture Video", Command.ITEM, 1);
	
	public void handler(InitMenuEvent next) throws Throwable {
		// [NC] Added in the scenario 08 
		if (next.screen().typeOfScreen == VideoAspectHandler.PLAYVIDEO)
		{		next.screen().addCommand(captureVideoCommand);
		}
	}
	when InitMenuEvent do handler;
	
	// ********  MediaController  ********* //
	
	public void handler(MediaControllerCommandActionEvent next) throws Throwable {
		if (next.c() == captureVideoCommand) {
			
			CaptureVideoScreen playscree = new CaptureVideoScreen(next.controller().midlet, CAPTUREVIDEO);
			playscree.setVisibleVideo();
			VideoCaptureController newcontroller = new VideoCaptureController(next.controller().midlet, next.controller().getAlbumData(), (AlbumListScreen) next.controller().getAlbumListScreen(), playscree);
			next.controller().setNextController(newcontroller);
			playscree.setCommandListener(next.controller());
			return;		
		}
		next.invoke();
	}
	when MediaControllerCommandActionEvent do handler;
	
	// ********  CaptureVideoScreen  ********* //
	
	public final static int CAPTUREVIDEO = 2;
	
}
