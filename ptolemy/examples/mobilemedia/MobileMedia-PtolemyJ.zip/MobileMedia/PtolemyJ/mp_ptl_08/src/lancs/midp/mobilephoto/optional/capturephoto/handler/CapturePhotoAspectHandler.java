package lancs.midp.mobilephoto.optional.capturephoto;

import javax.microedition.lcdui.Command;

import lancs.midp.mobilephoto.optional.smsorcapturephotoorvideo.handler.*;
import lancs.midp.mobilephoto.optional.capturephotoandvideo.CaptureVideoScreen;
import lancs.midp.mobilephoto.optional.copyPhoto.PhotoViewController;

import ubc.midp.mobilephoto.core.ui.controller.MediaController;
import ubc.midp.mobilephoto.core.ui.screens.AddMediaToAlbum;
import ubc.midp.mobilephoto.core.ui.screens.AlbumListScreen;
import ubc.midp.mobilephoto.core.ui.screens.MediaListScreen;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import java.util.Hashtable;

import javax.microedition.lcdui.Display;
import lancs.midp.mobilephoto.alternative.photo.handler.*;
import lancs.midp.mobilephoto.optional.capturevideo.event.*;
import lancs.midp.mobilephoto.optional.capturevideo.event.*;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event.*;

public class CapturePhotoAspectHandler {

	void CapturePhotoAspectHandler() { register(this); }

	// ********  MediaController  ********* //
	public void handler(MediaControllerCommandActionEvent next) throws Throwable {
		if (next.c() == capturePhotoCommand) {
			CaptureVideoScreen playscree = new CaptureVideoScreen(next.controller().midlet, CAPTUREPHOTO);
			playscree.setVisibleVideo();
			PhotoViewController newcontroller = new PhotoViewController(next.controller().midlet, next.controller().getAlbumData(), (AlbumListScreen) next.controller().getAlbumListScreen(), "New photo");
			setCpVideoScreen(newcontroller, playscree);
			next.controller().setNextController(newcontroller);
			playscree.setCommandListener(next.controller());
			return;		
		}
		next.invoke();
	}
	when MediaControllerCommandActionEvent do handler;

	// ********  MediaController  ********* //
	private static Hashtable<PhotoViewController,CaptureVideoScreen> cpVideoScreen = new Hashtable<PhotoViewController,CaptureVideoScreen>();
	
	public static CaptureVideoScreen getCpVideoScreen(PhotoViewController pvc) {
		return cpVideoScreen.get(pvc);
	}

	public static void setCpVideoScreen(PhotoViewController pvc, CaptureVideoScreen cpVideoScreen) {
		CapturePhotoAspectHandler.cpVideoScreen.put(pvc, cpVideoScreen);
	}
	
	public void handler(PhotoViewControllerCommandActionEvent next) throws Throwable {
		if (next.c() == takephoto){
			System.out.println("Olha para a captura"+getCpVideoScreen(next.controller()));
			byte[] newfoto = takePicture(getCpVideoScreen(next.controller()));
			System.out.println("Obteve a imagem");
			AddMediaToAlbum copyPhotoToAlbum = new AddMediaToAlbum("Copy Photo to Album");
			System.out.println("Crio a screen");
			copyPhotoToAlbum.setItemName("New picture");
			copyPhotoToAlbum.setLabelPath("Copy to Album:");
			copyPhotoToAlbum.setCommandListener(next.controller());
			
			SmsOrCapturePhotoOrVideoHandler.setCapturedMedia(copyPhotoToAlbum, newfoto);
			System.out.println("Definiu a imagem");
	        Display.getDisplay(next.controller().midlet).setCurrent(copyPhotoToAlbum);
			
			return;
		}
		next.invoke();
	}
	when PhotoViewControllerCommandActionEvent do handler;
	// ********  CaptureVideoScreen  ********* //
	
	public static Command takephoto = new Command("Take photo", Command.EXIT, 1);

	public final static int CAPTUREPHOTO = 1;

	public void handler(CaptureVideoScreenCreatedEvent next) throws Throwable {
		// [NC] Added in the scenario 08
		if (next.listScreen().typescreen == CAPTUREPHOTO){
			next.listScreen().addCommand(takephoto);
		}
	}
	when CaptureVideoScreenCreatedEvent do handler;

	public byte[] takePicture(CaptureVideoScreen cvs) {
		try {
				Alert alert = new Alert("Error", "The mobile database is full", null, AlertType.INFO);
				alert.setTimeout(5000);
				cvs.display.setCurrent(alert);
				byte[] imageArray = cvs.videoControl.getSnapshot(null);

				return imageArray;

			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}
	
	// ********  MediaListScreen  ********* //
	
	// [NC] Added in the scenario 08 
	public static Command capturePhotoCommand = new Command("Capture Photo", Command.ITEM, 1);
	
	public void handler(InitMenuEvent next) throws Throwable {
		// [NC] Added in the scenario 08 
		if (next.screen().typeOfScreen == PhotoAspectHandler.SHOWPHOTO)
		{		next.screen().addCommand(capturePhotoCommand);
		}
	}
	when InitMenuEvent do handler;
}
