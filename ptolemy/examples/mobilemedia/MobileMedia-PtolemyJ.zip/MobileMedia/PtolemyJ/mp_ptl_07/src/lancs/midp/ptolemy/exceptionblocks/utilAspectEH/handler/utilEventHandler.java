package lancs.midp.ptolemy.exceptionblocks.utilAspectEH.handler;

import java.io.IOException;

import lancs.midp.mobilephoto.lib.exceptions.InvalidImageDataException;
import lancs.midp.mobilephoto.lib.exceptions.ImagePathNotValidException;
import lancs.midp.mobilephoto.lib.exceptions.InvalidImageFormatException;
import lancs.midp.ptolemy.exceptionblocks.utilAspectEH.event.*;
import ubc.midp.mobilephoto.core.ui.datamodel.MediaData;
import lancs.midp.mobilephoto.lib.exceptions.InvalidArrayFormatException;

public class utilEventHandler {
	public utilEventHandler() { register(this); }
	
	public void handler(ReadInternalImageAsByteArrayEvent next) throws Throwable {
		try {
			next.invoke();
		} catch (IOException e) {
			throw new InvalidImageFormatException("The file " + next.imageFile() + " does not have PNG format");
		} catch (NullPointerException e) {
			throw new ImagePathNotValidException("Path not valid for this image:" + next.imageFile());
		}		
	}
	
	when ReadInternalImageAsByteArrayEvent do handler;
	
	public void handler(ReadImageAsByteArrayEvent next) throws Throwable {
		try {
			next.invoke();
		} catch (Exception e) {
			throw new ImagePathNotValidException("Path not valid for this image:" + next.imageFile());
		}
	}
	
	when ReadImageAsByteArrayEvent do handler;
	
	public MediaData handler(GetImageInfoFromBytesEvent next) throws Throwable {
		try {
			return next.invoke();
		} catch (Exception e) {
			throw new InvalidArrayFormatException();
		}
	}
	
	when GetImageInfoFromBytesEvent do handler;
	
	public String handler(GetBytesFromImageInfoEvent next) throws Throwable {
		try {
			return next.invoke();
		} catch (Exception e) {
			throw new InvalidImageDataException("The provided data are not valid");
		}
	}
	
	when GetBytesFromImageInfoEvent do handler;
}