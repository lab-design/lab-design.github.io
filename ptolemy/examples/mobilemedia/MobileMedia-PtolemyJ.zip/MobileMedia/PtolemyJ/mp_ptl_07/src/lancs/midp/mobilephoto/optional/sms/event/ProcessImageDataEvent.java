package lancs.midp.mobilephoto.optional.sms.event;

import lancs.midp.mobilephoto.optional.copyPhoto.MediaViewController;
import ubc.midp.mobilephoto.core.ui.datamodel.MediaAccessor;

public void evtype ProcessImageDataEvent {
	MediaViewController photoViewController;
	MediaAccessor mediaAccessor;
	String photoName;
	String albumname;
}
