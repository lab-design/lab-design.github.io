/*
 * Created on Sep 28, 2004
 */
package ubc.midp.mobilephoto.core.ui.datamodel;

import java.io.IOException;
import java.util.Hashtable;

import javax.microedition.lcdui.Image;
import javax.microedition.rms.RecordStoreException;

import lancs.midp.mobilephoto.lib.exceptions.*;
import lancs.midp.ptolemy.exceptionblocks.dataModelAspectEH.events.*;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event.*;

/**
 * @author tyoung
 * 
 * This class represents the data model for Photo Albums. A Photo Album object
 * is essentially a list of photos or images, stored in a Hashtable. Due to
 * constraints of the J2ME RecordStore implementation, the class stores a table
 * of the images, indexed by an identifier, and a second table of image metadata
 * (ie. labels, album name etc.)
 * 
 * This uses the ImageAccessor class to retrieve the image data from the
 * recordstore (and eventually file system etc.)
 */
public abstract class AlbumData {

	// [EF] Scenario 02 changed modifier public to private and generate get and set methods.
	// [EF] As a result, aspect DataModelAspectEH has to be changed.
	public MediaAccessor mediaAccessor;

	/**
	 *  Load any photo albums that are currently defined in the record store
	 *  
	 * @throws IOException 
	 * @throws RecordStoreException 
	 */
	public String[] getAlbumNames() throws RecordStoreException, IOException {

		//Shouldn't load all the albums each time
		//Add a check somewhere in ImageAccessor to see if they've been
		//loaded into memory already, and avoid the extra work...
		String albums[] = null;
		event GetAlbumNamesEvent
		{
			mediaAccessor.loadAlbums();
			albums = mediaAccessor.getAlbumNames();
		}
		return albums;
	}

	/**
	 *  Get the names of all images for a given Photo Album that exist in the Record Store.
	 *  
	 * @throws RecordStoreException 
	 */
	public MediaData[] getMedias(String recordName) throws RecordStoreException {
		MediaData[] result = null;
		event GetImageNamesEvent
		{
			result = mediaAccessor.loadMediaDataFromRMS(recordName);
		}
		return result;

	}

	/**
	 *  Define a new user photo album. This results in the creation of a new
	 *  RMS Record store.
	 *  
	 * @throws RecordStoreException 
	 */
	public void createNewAlbum(String albumName) throws RecordStoreException {
		mediaAccessor.createNewAlbum(albumName);
	}
	
	public void deleteAlbum(String albumName) throws RecordStoreException {
		mediaAccessor.deleteAlbum(albumName);
	}

	public void addNewMediaToAlbum(String label, String path, String album) throws RecordStoreException, IOException{
		mediaAccessor.addMediaData(label, path, album);
	}

	/**
	 *  Delete a photo from the photo album. This permanently deletes the image from the record store
	 *  
	 * @throws RecordStoreException 
	 */
	public void deleteMedia(String mediaName, String storeName) throws RecordStoreException {
		AlbumData album = this;

		event DeletePhotoAlbumEvent
		{
			mediaAccessor.deleteSingleMediaFromRMS(mediaName, storeName);
		}
	}
	
	/**
	 *  Reset the image data for the application. This is a wrapper to the ImageAccessor.resetImageRecordStore
	 *  method. It is mainly used for testing purposes, to reset device data to the default album and photos.
	 *  
	 * @throws IOException 
	 * @throws RecordStoreException 
	 */
	public void resetMediaData() throws RecordStoreException, IOException {
		event ResetImageDataEvent
		{
			mediaAccessor.resetMediaRecordStore();
		}
	}

	/**
	 * Get the hashtable that stores the image metadata in memory.
	 * @return Returns the imageInfoTable.
	 */
	public MediaData getMediaInfo(String mediaName) throws ImageNotFoundException {
		return mediaAccessor.getMediaInfo(mediaName);
	}

	/**
	 * Update the hashtable that stores the image metadata in memory
	 * @param imageInfoTable
	 *            The imageInfoTable to set.
	 */
	public MediaData[] loadMediaDataFromRMS(String recordName) throws RecordStoreException, IOException {
		return mediaAccessor.loadMediaDataFromRMS(recordName);
	}

	public boolean updateMediaInfo(MediaData oldData, MediaData newData) throws RecordStoreException, IOException {
		return mediaAccessor.updateMediaInfo(oldData, newData);
	}

	public byte[] loadMediaBytesFromRMS(String recordName, int recordId) throws RecordStoreException, IOException {
		return mediaAccessor.loadMediaBytesFromRMS(recordName, recordId);
	}
}
