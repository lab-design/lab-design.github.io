package lancs.midp.mobilephoto.optional.sms.event;

import lancs.midp.mobilephoto.optional.copyPhoto.MediaViewController;
import ubc.midp.mobilephoto.core.ui.screens.AddMediaToAlbum;

public void evtype ProcessCopyEvent {
	MediaViewController photoViewController;
	AddMediaToAlbum copyPhotoToAlbum;
}
