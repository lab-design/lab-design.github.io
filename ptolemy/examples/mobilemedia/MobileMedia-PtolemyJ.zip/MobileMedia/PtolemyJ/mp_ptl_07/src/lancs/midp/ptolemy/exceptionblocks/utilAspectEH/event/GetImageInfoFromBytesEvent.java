package lancs.midp.ptolemy.exceptionblocks.utilAspectEH.event;

import java.util.*;
import ubc.midp.mobilephoto.core.ui.datamodel.MediaData;

public MediaData evtype GetImageInfoFromBytesEvent {

}
