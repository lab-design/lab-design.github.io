package lancs.midp.mobilephoto.alternative.photo.handler;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Image;

import lancs.midp.mobilephoto.alternative.photo.ImageAlbumData;
import lancs.midp.mobilephoto.alternative.photo.PhotoViewScreen;
import ubc.midp.mobilephoto.core.ui.controller.*;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import javax.microedition.rms.RecordStoreException;
import java.io.IOException;
import ubc.midp.mobilephoto.core.ui.screens.*;
import lancs.midp.mobilephoto.optional.sms.event.*;
import ubc.midp.mobilephoto.core.ui.controller.ScreenSingleton;
import ubc.midp.mobilephoto.core.util.Constants;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event.*;
import lancs.midp.mobilephoto.alternative.music.event.*;

public class PhotoAspectHandler {
	public static BaseController imageRootController;

	public static AlbumData imageModel;

	public PhotoAspectHandler() { register(this); }

	public static void showImage(MediaController mediaController, String name) throws IOException, RecordStoreException {
		//[EF] Instead of replicating this code, I change to use the method "getSelectedImageName()". 		
		Image storedImage = null;
		storedImage = ((ImageAlbumData)mediaController.getAlbumData()).getImageFromRecordStore(mediaController.getCurrentStoreName(), name);
		//We can pass in the image directly here, or just the name/model pair and have it loaded
		PhotoViewScreen canv = new PhotoViewScreen(storedImage);
		mediaController.setCurrentScreen(canv);
	}
			
	public static final int SHOWPHOTO = 1;
	
	// [NC] Added in the scenario 07
	public static final Command viewCommand = new Command("View", Command.ITEM, 1);

	public void handler(StartApplicationEvent next) throws Throwable {
		PhotoAspectHandler.imageModel = new ImageAlbumData();
		
		// [NC] Added in the scenario 07
		AlbumListScreen album = new AlbumListScreen();
		PhotoAspectHandler.imageRootController = new BaseController(next.middlet(), PhotoAspectHandler.imageModel, album);
		
		// [EF] Add in scenario 04: initialize sub-controllers
		MediaListController photoListController = new MediaListController(next.middlet(), PhotoAspectHandler.imageModel, album);
		photoListController.setNextController(PhotoAspectHandler.imageRootController);
		
		AlbumController albumController = new AlbumController(next.middlet(), PhotoAspectHandler.imageModel, album);
		albumController.setNextController(photoListController);
		album.setCommandListener(albumController);
		
		next.invoke();
		PhotoAspectHandler.imageRootController.init(PhotoAspectHandler.imageModel);
	}
	when StartApplicationEvent do handler;

	public void handler(MediaControllerCommandActionEvent next) throws Throwable {
		// [NC] Added in the scenario 07
		if (next.c() == PhotoAspectHandler.viewCommand) {
			String selectedImageName = next.controller().getSelectedMediaName();
			PhotoAspectHandler.showImage(next.controller(), selectedImageName);
			ScreenSingleton.getInstance().setCurrentScreenName(Constants.IMAGE_SCREEN);
		}
	}
	when MediaControllerCommandActionEvent do handler;

	public void handler(InitMenuEvent next) throws Throwable {
		next.invoke();
		
		if (next.screen().getTypeOfScreen() == PhotoAspectHandler.SHOWPHOTO)
			next.screen().addCommand(PhotoAspectHandler.viewCommand);
	}
	when InitMenuEvent do handler;

	public MediaListScreen handler(MediaListScreenCreatedEvent next) throws Throwable {
		MediaListScreen listScreen = next.invoke();
		if (next.controller().getAlbumData() instanceof ImageAlbumData)
			listScreen.setTypeOfScreen(PhotoAspectHandler.SHOWPHOTO);
		return listScreen;
	}
	when MediaListScreenCreatedEvent do handler;
}
