package lancs.midp.ptolemy.command.events;

public enum CommandType {
	ADD,
	BACK,
	CANCEL,
	DELETEALBUM,
	DELETE,
	EXIT,
	NEWPHOTOALBUM,
	RESET,
	SELECT,
	VIEW
}
