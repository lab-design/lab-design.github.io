/*
 * Lancaster University
 * Computing Department
 * 
 * Created by Eduardo Figueiredo
 * Date: 17 Jun 2007
 * 
 */
package ubc.midp.mobilephoto.core.ui.controller;

import java.io.IOException;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.List;
import javax.microedition.rms.RecordStoreException;
import javax.microedition.rms.RecordStoreFullException;

import lancs.midp.mobilephoto.lib.exceptions.ImageNotFoundException;
import lancs.midp.mobilephoto.lib.exceptions.ImagePathNotValidException;
import lancs.midp.mobilephoto.lib.exceptions.InvalidImageDataException;
import lancs.midp.mobilephoto.lib.exceptions.NullAlbumDataReference;
import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;
import ubc.midp.mobilephoto.core.ui.MainUIMidlet;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import ubc.midp.mobilephoto.core.ui.datamodel.ImageData;
import ubc.midp.mobilephoto.core.ui.screens.AddPhotoToAlbum;
import ubc.midp.mobilephoto.core.ui.screens.AlbumListScreen;
import ubc.midp.mobilephoto.core.ui.screens.NewLabelScreen;
import ubc.midp.mobilephoto.core.ui.screens.PhotoViewScreen;
import ubc.midp.mobilephoto.core.util.Constants;

import lancs.midp.ptolemy.exceptionblocks.controllerAspectEH.event.*;
import lancs.midp.mobilephoto.optional.copyPhoto.event.*;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event.*;
import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.handler.*;
import lancs.midp.ptolemy.command.events.*;
import ubc.midp.mobilephoto.core.ui.controller.basecontroller.event.*;

/**
 * @author Eduardo Figueiredo
 * Added in the Scenario 02
 */
public class PhotoController extends PhotoListController {

	private ImageData image;

	public PhotoController (MainUIMidlet midlet, AlbumData albumData, AlbumListScreen albumListScreen) {
		super(midlet, albumData, albumListScreen);
		register(this);
	}

	public boolean handleCommand(Command command) throws RecordStoreException {
		return false;
	}

    public void handler(CommandEvent next) throws Throwable {
    	switch (next.type()) {
    	case BACK:
    	case CANCEL:
    	    /** Case: Go to the Previous or Fallback screen **/
    	    /** Case: Cancel the current screen and go back one**/
    		if (goToPreviousScreen())
    			return;
    		else
    			break;

    	case ADD:
    	    /** Case: Add photo  **/
    		ScreenSingleton.getInstance().setCurrentScreenName(Constants.ADDPHOTOTOALBUM_SCREEN);
    		AddPhotoToAlbum form = new AddPhotoToAlbum("Add new Photo to Album");
    		form.setCommandListener(this);
    		setCurrentScreen(form);
    		return;

    	case DELETE:
    	{
    		/** Case: Delete selected Photo from recordstore **/
        	String selectedImageName = getSelectedImageName();
          	event DeleteCommandExceptionEvent
          	{
        		getAlbumData().deleteImage(getCurrentStoreName(), selectedImageName);
         	}
    		showImageList(getCurrentStoreName());
    		ScreenSingleton.getInstance().setCurrentScreenName(Constants.IMAGELIST_SCREEN);
    	}
    		return;

    	case EDITLABEL:
    	{
    	    /** Case: Edit photo label 
    		 * [EF] Added in the scenario 02 **/
    			String selectedImageName = getSelectedImageName();
    			AlbumData model = getAlbumData();
    			PhotoController controller = this;
    			event EditLabelCommandExceptionEvent {
    				image = getAlbumData().getImageAccessor().getImageInfo(
    						selectedImageName);
    				// PhotoController photoController = new PhotoController(image,
    				// this);
    				NewLabelScreen formScreen = new NewLabelScreen(
    						"Edit Label Photo", NewLabelScreen.LABEL_PHOTO);
    				formScreen.setCommandListener(controller);
    				setCurrentScreen(formScreen);
    				formScreen = null;
    			}
    	}
    		return;

    	case SELECT:
    	{
    		/** Case: Select PhotoAlbum to view **/
    		String selectedImageName = getSelectedImageName();
    		showImage(selectedImageName);
    		ScreenSingleton.getInstance().setCurrentScreenName(Constants.IMAGE_SCREEN);
    	}
    		return;

    	default:
    			break;
    	}
    	next.invoke();
	}
    when CommandEvent do handler;

    /** Case: Save new Photo Label */
	public void handler(SaveLabelCommandEvent next) throws Throwable {
		String selectedImageName = getSelectedImageName();
		showImage(selectedImageName);
			
		ScreenSingleton.getInstance().setCurrentScreenName(Constants.IMAGE_SCREEN);
	}
	when SaveLabelCommandEvent do handler;

	/** Case: Save Add photo  **/
	public void handler(SaveAddPhotoCommandEvent next) throws Throwable {
		next.invoke();
		event SaveAddPhotoCommandExceptionEvent{
			getAlbumData().addNewPhotoToAlbum(next.label(), 
					next.path(), getCurrentStoreName());
		}
		goToPreviousScreen();
	}
	when SaveAddPhotoCommandEvent do handler;

	// [EF] Scenario 02: Increase visibility (package to public) in order to give access to aspect CountViewsAspect
	public void updateImage(ImageData image) {
		try {
			getAlbumData().getImageAccessor().updateImageInfo(image, image);
		} catch (InvalidImageDataException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (PersistenceMechanismException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RecordStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
    /**
     * Get the last selected image from the Photo List screen.
	 * TODO: This really only gets the selected List item. 
	 * So it is only an image name if you are on the PhotoList screen...
	 * Need to fix this
	 */
	public String getSelectedImageName() {
		List selected = (List) Display.getDisplay(midlet).getCurrent();
		if (selected == null)
		    System.out.println("Current List from display is NULL!");
		String name = selected.getString(selected.getSelectedIndex());
		return name;
	}
	
    /**
     * Show the current image that is selected
     * @throws RecordStoreException 
	 */
	public void showImage(String name) throws RecordStoreException {
// [EF] Instead of replicating this code, I change to use the method "getSelectedImageName()". 		
		PhotoController controler = this;
		PhotoController controller = this;
		String selectedImageName = name;
		String imageName = name;
		
		event ShowImageEvent
		{
			Image storedImage = null;
			storedImage = getAlbumData().getImageFromRecordStore(getCurrentStoreName(), name);
			
			//We can pass in the image directly here, or just the name/model pair and have it loaded
			PhotoViewScreen canv = new PhotoViewScreen(storedImage);
			
			event SetPhotoScreenEvent
			{
				setCurrentScreen(canv);
			}
		}
	}

   /**
    * TODO [EF] update this method or merge with method of super class.
     * Go to the previous screen
	 */
    private boolean goToPreviousScreen() throws RecordStoreException {
	    System.out.println("<* PhotoController.goToPreviousScreen() *>");
		String currentScreenName = ScreenSingleton.getInstance().getCurrentScreenName();
	    if (currentScreenName.equals(Constants.ALBUMLIST_SCREEN)) {
		    System.out.println("Can't go back here...Should never reach this spot");
		} else if (currentScreenName.equals(Constants.IMAGE_SCREEN)) {		    
		    //Go to the image list here, not the main screen...
		    showImageList(getCurrentStoreName());
		    ScreenSingleton.getInstance().setCurrentScreenName(Constants.IMAGELIST_SCREEN);
		    return true;
		}
    	else if (currentScreenName.equals(Constants.ADDPHOTOTOALBUM_SCREEN)) {
    		showImageList(getCurrentStoreName());
		    ScreenSingleton.getInstance().setCurrentScreenName(Constants.IMAGELIST_SCREEN);
		    return true;
    	}
	    return false;
    } 

	/**
	 * @param image the image to set
	 */
	public void setImage(ImageData image) {
		this.image = image;
	}

	/**
	 * @return the image
	 */
	public ImageData getImage() {
		return image;
	}

}
