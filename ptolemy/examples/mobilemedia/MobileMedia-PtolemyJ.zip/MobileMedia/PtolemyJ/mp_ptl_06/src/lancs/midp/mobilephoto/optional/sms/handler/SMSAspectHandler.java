package lancs.midp.mobilephoto.optional.sms.handler;

import java.util.HashMap;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Image;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;

import ubc.midp.mobilephoto.core.ui.datamodel.ImageAccessor;
import ubc.midp.mobilephoto.core.ui.datamodel.ImageData;
import ubc.midp.mobilephoto.core.ui.screens.AddPhotoToAlbum;
import ubc.midp.mobilephoto.core.ui.screens.PhotoViewScreen;
import ubc.midp.mobilephoto.core.util.ImageUtil;

import lancs.midp.mobilephoto.lib.exceptions.InvalidImageDataException;
import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;
import lancs.midp.ptolemy.exceptionblocks.dataModelAspectEH.events.*;
import lancs.midp.mobilephoto.optional.copyPhoto.event.*;

import lancs.midp.mobilephoto.optional.sms.event.*;
import ubc.midp.mobilephoto.sms.*;

public class SMSAspectHandler {
	public static final Command smscopyCommand = new Command("Send Photo by SMS", Command.ITEM, 1);
	//private boolean PhotoViewScreen.fromSMS = false;
	public static Image img = null;
	
	public static HashMap<PhotoViewScreen, Boolean> fromSMSHashMap = new HashMap<PhotoViewScreen, Boolean>();
	public static HashMap<AddPhotoToAlbum, Image> AddPhotoAlbumImageHashMap = new HashMap<AddPhotoToAlbum, Image>();

	public SMSAspectHandler() { register(this); }

	public static boolean getFromSMS(PhotoViewScreen photoViewScreen){
		Boolean fromSMS = new Boolean(false);
		if(fromSMSHashMap.containsKey(photoViewScreen))
			fromSMS = fromSMSHashMap.get(photoViewScreen);
		return fromSMS.booleanValue();
			
	}
	
	public static void setFromSMS(PhotoViewScreen photoViewScreen, boolean fromSMS){
		Boolean fromSMSValue = null;
		if(fromSMSHashMap.containsKey(photoViewScreen))
			fromSMSValue = fromSMSHashMap.get(photoViewScreen);
			
		fromSMSValue = new Boolean(fromSMS);
	}
	
	public static Image getImage(AddPhotoToAlbum addPhotoToAlbum) {
		if(AddPhotoAlbumImageHashMap.containsKey(addPhotoToAlbum))
			return AddPhotoAlbumImageHashMap.get(addPhotoToAlbum);
		else 
			return null;
	}

	public static void setImage(AddPhotoToAlbum addPhotoToAlbum, Image image) {
		Image imageValue = null;
		if(AddPhotoAlbumImageHashMap.containsKey(addPhotoToAlbum)){
			 imageValue = AddPhotoAlbumImageHashMap.get(addPhotoToAlbum);
			 imageValue = image;
		}
	}
	
	
	
	public static byte[] getByteFromImage(Image img){
		int w = img.getWidth();
		int h = img.getHeight();
		int data_int[] = new int[ w * h ];
		img.getRGB( data_int, 0, w, 0, 0, w, h );
		byte[] data_byte = new byte[ w * h * 3 ];
		for ( int i = 0; i < w * h; ++i )
		{
		int color = data_int[ i ];
		int offset = i * 3;
		data_byte[ offset ] = ( byte ) ( ( color & 0xff0000 ) >> 16 );
		data_byte[ offset +
		1 ] = ( byte ) ( ( color & 0xff00 ) >> 8 );
		data_byte[ offset + 2 ] = ( byte ) ( ( color & 0xff ) );
		}
		return data_byte;
	}
	
	public static void addImageData(ImageAccessor imageAccessor, String photoname, Image imgdata, String albumname)
				throws InvalidImageDataException, PersistenceMechanismException {
		try {
			
			imageAccessor.imageRS = RecordStore.openRecordStore(imageAccessor.ALBUM_LABEL + albumname, true);
			imageAccessor.imageInfoRS = RecordStore.openRecordStore(imageAccessor.INFO_LABEL + albumname, true);
			int rid; // new record ID for Image (bytes)
			int rid2; // new record ID for ImageData (metadata)
				
			ImageUtil converter = new ImageUtil();
			
			byte[] data1 = getByteFromImage(imgdata);
			rid = imageAccessor.imageRS.addRecord(data1, 0, data1.length);
			ImageData ii = new ImageData(rid, ImageAccessor.ALBUM_LABEL	+ albumname, photoname);
			rid2 = imageAccessor.imageInfoRS.getNextRecordID();				
			ii.setRecordId(rid2);
			String data1String = converter.getBytesFromImageInfo(ii); 
			data1 = data1String.getBytes();
			imageAccessor.imageInfoRS.addRecord(data1, 0, data1.length);
			
			imageAccessor.imageRS.closeRecordStore();
			
			imageAccessor.imageInfoRS.closeRecordStore();
		} catch (RecordStoreException e) {
			throw new PersistenceMechanismException();
		}
	}

	public void handler(StartApplicationEvent next)throws Throwable{
		next.invoke();
		SmsReceiverController controller = new SmsReceiverController(next.middlet(), next.middlet().model, next.middlet().album);
		controller.setNextController(next.middlet().albumController);
		SmsReceiverThread smsR = new SmsReceiverThread(next.middlet(), next.middlet().model, next.middlet().album, controller);
		System.out.println("SmsController::Starting SMSReceiver Thread");
		new Thread(smsR).start();
	}
	when StartApplicationEvent do handler;

	public void handler(ProcessImageDataEvent next)throws Throwable{
		ImageData imageData = null;
		SMSAspectHandler.img = null;
		
		SMSAspectHandler.img = SMSAspectHandler.getImage((AddPhotoToAlbum)next.photoViewController().getCurrentScreen());
		if (SMSAspectHandler.img == null){
		   //imageData = next.invoke();
			next.invoke();
			imageData = null;
		}
		if (SMSAspectHandler.img != null){
			SMSAspectHandler.addImageData(next.imageAccessor(), next.photoName(), SMSAspectHandler.img, next.albumname());
		}		

		//return imageData;
		return;
	}
	when ProcessImageDataEvent do handler;

	public void handler(ProcessCopyEvent next)throws Throwable{
		next.invoke();
		
		if (SMSAspectHandler.getFromSMS((PhotoViewScreen)next.photoViewController().getCurrentScreen())){
			SMSAspectHandler.setImage(next.copyPhotoToAlbum(), ((PhotoViewScreen)next.photoViewController().getCurrentScreen()).getImage());
		}
	}
	when ProcessCopyEvent do handler;

	public void handler(PhotoViewScreenCreatedEvent next)throws Throwable{
		next.invoke();
		next.f().addCommand(SMSAspectHandler.smscopyCommand);
	}
	when PhotoViewScreenCreatedEvent do handler;

	public void handler(LoadImageEvent next)throws Throwable{
		if (SMSAspectHandler.getFromSMS(next.screen())){
			   return;
		}
		else 
		{
			   next.invoke();
		}

	}
	when LoadImageEvent do handler;

	public void handler(GetPhotoControllerEvent next)throws Throwable{
		next.invoke();
		SmsSenderController smscontroller = new SmsSenderController(next.controller().midlet, next.controller().getAlbumData(), 
					next.controller().getAlbumListScreen(), next.imageName());
		smscontroller.setNextController(next.controller());
		return;
	}
	when GetPhotoControllerEvent do handler;

	public void handler(AddImageDataEvent next)throws Throwable{
		if (SMSAspectHandler.img == null){
			next.invoke();
		}
	}
	when AddImageDataEvent do handler;
}
