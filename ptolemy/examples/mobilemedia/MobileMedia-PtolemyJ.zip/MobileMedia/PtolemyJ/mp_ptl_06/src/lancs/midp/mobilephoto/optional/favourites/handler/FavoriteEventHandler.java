package lancs.midp.mobilephoto.optional.favourites.handler;

import java.util.HashMap;

import javax.microedition.lcdui.*;

import lancs.midp.mobilephoto.lib.exceptions.ImageNotFoundException;
import lancs.midp.mobilephoto.lib.exceptions.NullAlbumDataReference;

import ubc.midp.mobilephoto.core.ui.controller.*;
import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import ubc.midp.mobilephoto.core.ui.datamodel.ImageData;
import ubc.midp.mobilephoto.core.ui.screens.PhotoListScreen;
import ubc.midp.mobilephoto.core.util.Constants;
import ubc.midp.mobilephoto.core.util.ImageUtil;

import lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event.*;

public class FavoriteEventHandler {

	public FavoriteEventHandler() { register(this); }

	public static boolean favorite = false;
	public static final Command favoriteCommand = new Command("Set Favorite", Command.ITEM, 1);
	public static final Command viewFavoritesCommand = new Command("View Favorites", Command.ITEM, 1);
	
	public static HashMap<ImageData, Boolean>  favoriteHashMap = new HashMap<ImageData, Boolean>(); 
	
	public static void toggleFavorite(ImageData imageData) {
		
		Boolean favoriteValue = null;
		
		if (favoriteHashMap.containsKey(imageData)){
			favoriteValue = favoriteHashMap.get(imageData);
			favoriteValue = new Boolean(!favoriteValue.booleanValue());
		}
	}
	
	/**
	 * [EF] Added in the scenario 03
	 * @param favorite
	 */
	public static void setFavorite(ImageData imageData, boolean favorite){
		Boolean favoriteValue = null;
		if (favoriteHashMap.containsKey(imageData)){
			favoriteValue = favoriteHashMap.get(imageData);
			favoriteValue = new Boolean(favorite);
		}
		else
		{
			favoriteHashMap.put(imageData, new Boolean(favorite));
		}
			
	}

	/**
	 * [EF] Added in the scenario 03
	 * @return the favorite
	 */
	public static boolean isFavorite(ImageData imageData){
		boolean favoriteValue = false;
		if (favoriteHashMap.containsKey(imageData)){
			favoriteValue = (favoriteHashMap.get(imageData)).booleanValue();
		}
		return favoriteValue;
		
	}

	public void handler(InitMenuEvent next) throws Throwable{
		next.invoke();
		next.screen().addCommand(FavoriteEventHandler.favoriteCommand);
		next.screen().addCommand(FavoriteEventHandler.viewFavoritesCommand);
	}
	when InitMenuEvent do handler;

	public ImageData handler(CreateImageDataEvent next) throws Throwable{
		
		boolean favorite = false;
		int endIndex = next.endIndex();
		int startIndex = endIndex + 1;
		endIndex = next.iiString().indexOf(ImageUtil.DELIMITER, startIndex);
		
		if (endIndex == -1)
			endIndex = next.iiString().length();

		favorite = (next.iiString().substring(startIndex, endIndex)).equalsIgnoreCase("true");
		
		ImageData imageData = next.invoke();
		
		//imageData.setFavorite(favorite);
		FavoriteEventHandler.setFavorite(imageData, favorite);

//		System.out.println("<* FavouritesAspect.around createImageData *> ...ends");
		
		return imageData;

	}
	when CreateImageDataEvent do handler;

	public void handler(PhotoControllerCommandActionEvent next) throws Throwable {
		next.invoke();
		
		System.out.println("<* FavouritesAspect.around handleCommandAction *> ::handleCommand: " + next.c().getLabel());
		
		/** Case: Set photo as favorite 
		 * [EF] Added in the scenario 03 **/
		if (next.c() == FavoriteEventHandler.favoriteCommand) {
		   	String selectedImageName = next.controller().getSelectedImageName();
			try {
				ImageData image = next.controller().getAlbumData().getImageAccessor().getImageInfo(selectedImageName);
				//image.toggleFavorite();
				FavoriteEventHandler.toggleFavorite(image);
				next.controller().updateImage(image);
				//System.out.println("<* FavouritesAspect.handleCommand() *> Image = "+selectedImageName+ "; Favorite = "+image.isFavorite());
				System.out.println("<* FavouritesAspect.handleCommand() *> Image = "
						+selectedImageName+ "; Favorite = "+FavoriteEventHandler.isFavorite(image));
			} catch (ImageNotFoundException e) {
				Alert alert = new Alert( "Error", "The selected photo was not found in the mobile device", null, AlertType.ERROR);
				Display.getDisplay(next.controller().midlet).setCurrent(alert, Display.getDisplay(next.controller().midlet).getCurrent());
			} catch (NullAlbumDataReference e) {
				next.controller().setAlbumData( new AlbumData() );
				Alert alert = new Alert( "Error", "The operation is not available. Try again later !", null, AlertType.ERROR);
				Display.getDisplay(next.controller().midlet).setCurrent(alert, Display.getDisplay(next.controller().midlet).getCurrent());
			}
				
		/** Case: View favorite photos 
		 * [EF] Added in the scenario 03 **/
		} else if (next.c() == FavoriteEventHandler.viewFavoritesCommand) {
			FavoriteEventHandler.favorite = true;
			next.controller().showImageList(next.controller().getCurrentStoreName());
    		ScreenSingleton.getInstance().setCurrentScreenName( Constants.IMAGELIST_SCREEN );
		}
	}
	when PhotoControllerCommandActionEvent do handler;

	//public int handler(AppendImagesEventHandler next){
	public void handler(AppendImagesEvent next) throws Throwable{
		boolean flag = true;
		// [EF] Check if favorite is true (Add in the Scenario 03)
		if (FavoriteEventHandler.favorite) {
			for (int i = 0; i < next.images().length; i++)
				if ( !(FavoriteEventHandler.isFavorite(next.images()[i])) ) 
					flag = false;
		}
		if (flag){ 
			//return invoke();
			next.invoke();
		}
		FavoriteEventHandler.favorite = false;
		//return 0;
		return;
	}
	when AppendImagesEvent do handler;
}
