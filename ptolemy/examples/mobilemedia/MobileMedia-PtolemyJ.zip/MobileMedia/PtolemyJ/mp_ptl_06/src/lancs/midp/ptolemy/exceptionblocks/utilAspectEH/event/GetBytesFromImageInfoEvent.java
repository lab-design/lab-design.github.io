package lancs.midp.ptolemy.exceptionblocks.utilAspectEH.event;

import ubc.midp.mobilephoto.core.ui.datamodel.ImageData;

public String evtype GetBytesFromImageInfoEvent {

	ImageData ii;
}
