package lancs.midp.mobilephoto.optional.sms.event;

import ubc.midp.mobilephoto.core.ui.screens.PhotoViewScreen;

public void evtype LoadImageEvent {
	
	PhotoViewScreen screen; 

}
