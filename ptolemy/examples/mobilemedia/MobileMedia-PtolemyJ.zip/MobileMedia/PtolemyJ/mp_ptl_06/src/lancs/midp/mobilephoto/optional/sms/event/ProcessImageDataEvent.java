package lancs.midp.mobilephoto.optional.sms.event;

import lancs.midp.mobilephoto.optional.copyPhoto.PhotoViewController;
import ubc.midp.mobilephoto.core.ui.datamodel.ImageAccessor;

public void evtype ProcessImageDataEvent {
	PhotoViewController photoViewController;
	ImageAccessor imageAccessor;
	String photoName;
	String albumname;
}
