/*
 */

package ubc.midp.mobilephoto.core.ui.screens;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.rms.RecordStoreException;

import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import ubc.midp.mobilephoto.core.util.Constants;
import javax.microedition.lcdui.CommandListener;
import lancs.midp.ptolemy.command.events.*;

/**
 * This screen displays a selected image.
  */
public class PhotoViewScreen extends Canvas implements CommandListener {

	String imageName = "";
	Image image;
	AlbumData model = null;
    
	public static final Command backCommand = new Command("Back", Command.BACK, 0);

	/**
	 * Constructor
	 * @param img
	 */
	public PhotoViewScreen(Image img) {

		//Instead of loading it from a list, pass the image in directly
		image = img;
		this.addCommand(backCommand);
		setCommandListener(this);
	}
	
	/**
	 * Constructor
	 * @param mod
	 * @param name
	 * @throws RecordStoreException 
	 */
	public PhotoViewScreen(AlbumData mod, String name) throws RecordStoreException {
		imageName = name;
		model = mod;
		loadImage();
		this.addCommand(backCommand);
		setCommandListener(this);
	}

	/**
	 * Get the current image from the hashtable stored in the parent midlet.
	 * 
	 * @throws RecordStoreException 
	 */
	public void loadImage() throws RecordStoreException {
		image = model.getImageFromRecordStore(null, imageName);
	}

	/*
	 *  (non-Javadoc)
	 * @see javax.microedition.lcdui.Canvas#paint(javax.microedition.lcdui.Graphics)
	 */
	protected void paint(Graphics g) {
		
	    g.setGrayScale (255);

	    //Draw the image - for now start drawing in top left corner of screen
	    g.fillRect (0, 0, Constants.SCREEN_WIDTH, Constants.SCREEN_HEIGHT);
	    System.out.println("Screen size:"+Constants.SCREEN_WIDTH+":"+ Constants.SCREEN_HEIGHT);

	    if (image == null) 
	    	System.out.println("PhotoViewScreen::paint(): Image object was null.");
	    	
	    g.drawImage (image, 0, 0, Graphics.TOP | Graphics.LEFT);
	    
	}

	public void commandAction(Command c, Displayable d) {
		if (c== backCommand) {
			CommandType type = CommandType.BACK;
			event CommandEvent {}
		}
	}
}
