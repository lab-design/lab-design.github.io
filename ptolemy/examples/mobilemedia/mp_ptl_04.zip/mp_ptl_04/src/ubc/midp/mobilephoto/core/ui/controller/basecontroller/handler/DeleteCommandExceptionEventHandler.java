package ubc.midp.mobilephoto.core.ui.controller.basecontroller.handler;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Display;

import lancs.midp.mobilephoto.lib.exceptions.ImageNotFoundException;
import lancs.midp.mobilephoto.lib.exceptions.PersistenceMechanismException;
import ubc.midp.mobilephoto.core.ui.controller.basecontroller.event.*;

public class DeleteCommandExceptionEventHandler {
	
	public void handler(DeleteCommandExceptionEvent next) throws Throwable{
		try{
			next.invoke();
		} catch (PersistenceMechanismException e) {
			Alert alert = new Alert( "Error", "The mobile database can not delete this photo", null, AlertType.ERROR);
			Display.getDisplay(next.midlet()).setCurrent(alert, Display.getDisplay(next.midlet()).getCurrent());
	        return;
		} catch (ImageNotFoundException e) {
			Alert alert = new Alert( "Error", "The selected photo was not found in the mobile device", null, AlertType.ERROR);
			Display.getDisplay(next.midlet()).setCurrent(alert, Display.getDisplay(next.midlet()).getCurrent());
			return;
		}
	}
	
	when DeleteCommandExceptionEvent do handler;

}
