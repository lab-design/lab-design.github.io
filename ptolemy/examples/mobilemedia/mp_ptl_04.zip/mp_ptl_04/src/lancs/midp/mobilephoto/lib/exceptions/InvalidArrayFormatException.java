package lancs.midp.mobilephoto.lib.exceptions;

public class InvalidArrayFormatException extends InvalidImageDataException {

	public InvalidArrayFormatException() {
		super();
	}

	public InvalidArrayFormatException(String arg0) {
		super(arg0);
	}
	
	public InvalidArrayFormatException(Throwable arg0) {
		super(arg0);
	}
}
