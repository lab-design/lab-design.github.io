package lancs.midp.ptolemy.command.events;

public enum CommandType {
	ADD,
	BACK,
	CANCEL,
	DELETEALBUM,
	DELETE,
	EDITLABEL,
	EXIT,
	NEWPHOTOALBUM,
	RESET,
	SELECT,
	VIEW
}
