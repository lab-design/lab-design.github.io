package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Displayable;

import ubc.midp.mobilephoto.core.ui.controller.BaseController;

public void evtype ControllerCommandActionEvent {
	BaseController controller;
	Command c;
}
