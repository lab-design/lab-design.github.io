package lancs.midp.ptolemy.exceptionblocks.dataModelAspectEH.events;

import java.util.*;

import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;

public void  evtype DeleteImageEvent {
	String imageName;
	String storeName;
	AlbumData album;
}
