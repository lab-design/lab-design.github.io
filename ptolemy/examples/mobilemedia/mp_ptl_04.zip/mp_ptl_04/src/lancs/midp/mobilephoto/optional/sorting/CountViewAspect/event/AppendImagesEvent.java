package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event;

import ubc.midp.mobilephoto.core.ui.controller.BaseController;
import ubc.midp.mobilephoto.core.ui.datamodel.ImageData;
import ubc.midp.mobilephoto.core.ui.screens.PhotoListScreen;

public void evtype AppendImagesEvent {
	
	BaseController controller;
	ImageData[] images;
	PhotoListScreen imageList;
}
