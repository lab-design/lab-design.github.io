package lancs.midp.mobilephoto.optional.sorting.CountViewAspect.event;

import javax.microedition.lcdui.Command;

public void evtype CommandActionEvent {
	Command c;
}
