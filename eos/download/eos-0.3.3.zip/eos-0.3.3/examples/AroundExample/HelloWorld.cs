public class HelloWorld
{
	public static void Main (string [] arguments)
	{
		HelloWorld hw = new HelloWorld();
		hw.SaySomething("Hello World");
	}

	public string SaySomething(string text)
	{
		System.Console.WriteLine(text);
		return text;
	}
}