using Eos.Runtime;
public class Lazy 
{
	VS_PS  vs_ps; ES_LS es_ls; G g; UI ui; bool lazy = false;
	public Lazy(VS_PS vs_ps, ES_LS es_ls, G g, UI ui)
	{
		this.vs_ps = vs_ps; this.es_ls = es_ls; 
		this.g = g; this.ui = ui;
		addObject(vs_ps); addObject(es_ls); addObject(g); addObject(ui);
	}

	public void RecordAddEnds(bool ret, E e, AroundADP p) 
	{
		if(!lazy) p.InnerInvoke();
		else {  /* Record invocation of G.AddEnds */ }
	}

	public void RecordRemIncident(bool ret, V v, AroundADP p)
	{ 
		if(!lazy) p.InnerInvoke();
		else { /* Record invocation of G.RemoveIncident */}
	}
	/* Similar methods to record method invocations of 
		VS_PS and ES_LS */

	void around execution(public void G.AddEnds(bool, E)) 
	    && args(ret) && args(e) && aroundptr(p):  
	    call RecordAddEnds (bool ret, E e, AroundADP p);

	void around execution(public void G.RemoveIncident(bool, v)) 
	    && args(ret) && args(v) && aroundptr(p):  
	    call RecordRemIncident (bool ret, V v, AroundADP p);
	/* Similar bindings for methods in VS_PS and ES_LS */

	public void SetLazy() { lazy = true; }

	after execution(public void UI.SetLazy()):call SetLazy();

	public void ResetLazy()
	{
		/* For each recorded invocation of AddEnds invoke
			  the method AddEnds on g. Similarly invoke other
			  appropriate methods for other recorded invocations*/
	}

	after execution(public void UI.ResetLazy()): call ResetLazy();

}

