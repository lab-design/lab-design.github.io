public class P
{
	int X, Y;
	public P( int X, int Y){ this.X = X; this.Y = Y; }
	public void SetX(int X){ this.X = X; }
	public void SetY(int Y){ this.Y = Y; }
	public int GetX(){ return X; }
	public int GetY(){ return Y;}
	public override bool Equals(object o)
	{
		if(o is P)
		{
			P p = (P) o;
			if(p.GetX() == this.GetX() && p.GetY() == this.GetY()) return true;
		}
		return false;
	}
}