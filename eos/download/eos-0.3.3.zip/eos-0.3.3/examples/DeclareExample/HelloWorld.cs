/* This example demonstrate how a declare  
   construct is used in Eos.  */

using System;	 

namespace HelloWorld
{
	public class Hello
	{
		public static void Main(string[] arguments)
		{
			System.Console.WriteLine("Hello");
		}
	}

        public class HelloExtension
        {
             declare parents: HelloWorld.Hello : System.ICloneable; 

             introduce in HelloWorld.Hello
             {
                public object Clone()
                {
                   Console.WriteLine("I am the cloning function. There is nothing to Clone in Hello, so I will return Null.");
                   return null;
                }
             }
            
             static after execution(public static void HelloWorld.Hello.Main(string[])): call CheckClone();

             public void CheckClone()
             {

                System.ICloneable o = new HelloWorld.Hello();
                o.Clone();
             }
        }

}


