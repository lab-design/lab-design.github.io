public class MyClass
{
	public static void Main (string [] arguments)
	{
		MyClass m = new MyClass();
		m.SaySomething("Something");
	}

	public string SaySomething(string text)
	{
		System.Console.WriteLine(text);
		return text; //to test Ijoinpoint.ReturnValue
	}
}