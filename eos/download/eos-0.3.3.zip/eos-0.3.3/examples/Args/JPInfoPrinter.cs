/// <summary>
/// Eos 0.3 is moving towards a new aspect language model. In this new aspect language model 
/// there are no special aspects, everything is a class. There are no special advice either
/// every code is written in a method body. The joinpoints are selected by a pointcut like 
/// before, and then you connect these join points to a method that contains the special code
/// you want to execute at that join point using a binding. This example below shows a program
/// in Eos to print information at the join point.
/// 
/// Three rules to program in new Eos language model:
/// 
/// Rule 1: Everything is a class. Even though JPInfoPrinter represents a crosscutting concern
/// it is represented as a class.
/// 
/// Rule 2: Every piece of code is written in a method body.
/// 
/// Rule 3: Crosscutting behavior written in method is associated with the join point using 
/// binding.
/// 
/// </summary>
/// 

/// <summary>
/// Following Rule 1
/// </summary>
public class JPInfoPrinter 
{
	/// <summary>
	/// Following Rule 2: PrintInfo will be executed at a join point.
	/// </summary>
	/// <param name="jp">The join point to print information about.</param>
	public void PrintInfo(Eos.Runtime.IJoinpoint jp)
	{
		try
		{
			System.Console.WriteLine("This: " + jp.This);
			System.Console.WriteLine("Target: " + jp.Target);
			System.Console.WriteLine("ReturnValue: " + jp.ReturnValue);
			System.Console.WriteLine("Kind: " + jp.Kind);
			System.Console.WriteLine("Signature: " + jp.Signature);
			// The following line throws an exception
			bool hasArgs = (jp.Args.Length != 0);
			if(hasArgs)
			{
				System.Console.WriteLine(" This joinpoint has arguments: ");
				foreach(object o in jp.Args)
					System.Console.WriteLine("  " + o.ToString());
			}
		}
		catch(System.Exception e)
		{
			System.Console.WriteLine("Exception: " + e.Message + "(source: " + e.Source + ")");
		}
	}
	
	/// <summary>
	/// Following Rule 3: Associate/Connect/Register (whatever you wanna call it) 
	/// PrintInfo to join point using a binding.
	/// 
	/// Note that this binding is static, if a binding is static it will attach statically 
	/// to each join point. If the binding is not static, you can attach it to an object at
	/// runtime by calling addObject as shown in bit-symmetric example.
	/// 
	/// </summary>
	static after execution(public string MyClass.SaySomething(string)) && joinpoint(jp): 
			call PrintInfo(Eos.Runtime.IJoinpoint jp);
}

///
/// And here is the equivalent aspect for the curious.
///
//public aspect MyAspect
//{
//       after(): execution(public string MyClass.SaySomething(string))
//       {
//               try
//               {
//                       System.Console.WriteLine("This: " + thisJoinPoint.This);
//                       System.Console.WriteLine("Target: " + thisJoinPoint.Target);
//                       System.Console.WriteLine("ReturnValue: " + thisJoinPoint.ReturnValue);
//                       System.Console.WriteLine("Kind: " + thisJoinPoint.Kind);
//                       System.Console.WriteLine("Signature: " + thisJoinPoint.Signature);
//                       // The following line throws an exception
//                       bool hasArgs = (thisJoinPoint.Args.Length != 0);
//					   if(hasArgs)
//						{
//							System.Console.WriteLine(" This joinpoint has arguments: ");
//							foreach(object o in thisJoinPoint.Args)
//								System.Console.WriteLine("  " + o.ToString());
//						}
//               }
//               catch(System.Exception e)
//               {
//                       System.Console.WriteLine("Exception: " + e.Message + "(source: " + e.Source + ")");
//               }
//       }
//}
