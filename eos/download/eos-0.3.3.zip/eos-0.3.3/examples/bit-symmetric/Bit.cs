namespace BITSYS
{
	public class Bit 
	{   
		int index= 0;
		bool value;
		public Bit(int index) { this.index = index; value = false; }
		public void Set() { System.Console.WriteLine("Set execution " + index); value = true; } 
		public bool Get (){ return value; } 
		public void Clear() { System.Console.WriteLine("Clear execution " + index); value= false; }
	}
}
