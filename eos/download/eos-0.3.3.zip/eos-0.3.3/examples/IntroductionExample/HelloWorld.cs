/* This example demonstrate how a simple method 
   call tracing can be done using Eos.  */

using System;	 

namespace HelloWorld
{
	public class Hello
	{
		public static void Main(string[] arguments)
		{
			System.Console.WriteLine("Hello");
		}
	}

        public class HelloExtension
        {

             introduce in HelloWorld.Hello
             {
                public static void Salutation()
                {
                   Console.WriteLine("Jee");
                }
             }
            
             static after execution(public static void HelloWorld.Hello.Main(string[])): call AddSalutation();

             public void AddSalutation()
             {

                HelloWorld.Hello.Salutation();
             }
        }

}


