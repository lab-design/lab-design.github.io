using System;
using NUnit.Framework;

namespace BITSYS
{
	public instancelevel aspect Consistency 
	{   
		Bit bit1, bit2;
		bool busy;
		public Consistency(Bit bit1, Bit bit2)
		{
			addObject(bit1);
			addObject(bit2);
			this.bit1 = bit1;
			this.bit2 = bit2;
			busy = false;
		}
		after():execution(public void Bit.Set ())
		{
		if(!busy)
			{
			busy = true;
			Bit bit = (Bit) thisJoinPoint.Target;
			if(bit == bit1)bit2.Set();
	        else bit1.Set();
	        busy = false;
			}
		}
		after():execution(public void Bit.Clear ())
		{
		if(!busy)
			{
	        	busy = true;
			Bit bit = (Bit) thisJoinPoint.Target;
	        	if(bit == bit1)bit2.Clear();
	        	else bit1.Clear();
			busy = false;
			}
		}
	}

    public aspect CoverageAspect 
    {
		action CodeCov(): conditional(if)|| conditional(switch)||iteration(any);
		action CodeCov(): execution(public void BITSYS.Bit.any());
	}

	[TestFixture]
	public class ConsistencyTest
	{
		[Test]
		public void SetLeftTest()
		{
			Bit b1 = new Bit();
			Bit b2 = new Bit();
			Consistency c = new Consistency(b1,b2);
			b1.Set();
			Assertion.Assert("Right Bit was not set", b2.Get()== true);
		}
		[Test]
		public void SetRightTest()
		{
			Bit b1 = new Bit();
			Bit b2 = new Bit();
			Consistency c = new Consistency(b1,b2);
			b2.Set();
			Assertion.Assert("Left Bit was not set", b1.Get()== true);
		}
		[Test]
		public void ClearLeftTest()
		{
			Bit b1 = new Bit();
			Bit b2 = new Bit();
			Consistency c = new Consistency(b1,b2);
			b1.Clear();
			Assertion.Assert("Right Bit was not cleared", b2.Get()== false);
		}
		[Test]
		public void ClearRightTest()
		{
			Bit b1 = new Bit();
			Bit b2 = new Bit();
			Consistency c = new Consistency(b1,b2);
			b2.Clear();
			Assertion.Assert("Left Bit was not cleared", b1.Get()== false);
		}
	}
}
