using NUnit.Framework;
namespace BITSYS
{
	public class Bit 
	{   
		bool value;
		public Bit() { value = false; }
		public void Set() { value = true; } 
		public bool Get (){ return value; } 
		public void Clear() {value= false; }
	}

	[TestFixture]
	public class BitTest
	{
		[Test]
		public void SetTest()
		{
			Bit b = new Bit();
			b.Set();
			Assertion.Assert("Bit was not set", b.Get()== true);
		}
		[Test]
		public void GetTest()
		{
			Bit b = new Bit();
			b.Set();
			Assertion.Assert("Get should have returned true", b.Get()== true);
		}
		[Test]
		public void ClearTest()
		{
			Bit b = new Bit();
			b.Clear();
			Assertion.Assert("Bit was not cleared", b.Get()== false);
		}
	}
}
