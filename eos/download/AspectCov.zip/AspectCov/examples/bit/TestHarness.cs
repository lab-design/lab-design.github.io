using System;
using NUnit.Framework;

namespace BITSYS 
{
	public class TestHarness 
	{
		public static void Main (string[] argument)
		{ 
			Bit bit1 = new Bit();
			Bit bit2 = new Bit();
			Bit bit3 = new Bit();
			Consistency c = new Consistency(bit1, bit2);
			bit1.Set();
			bit2.Clear();
			bit3.Set();
			if(!bit1.Get()&&!bit2.Get()){
			  if(bit3.Get()){
				Console.WriteLine("Test Passed");
                                }
		        if(!bit3.Get()){
				Console.WriteLine("Test failed");
                                }
			if(!bit3.Get()){
				Console.WriteLine("Test failed");
                                }
                        }
		}
	};   // END class TestHarness 

	[TestFixture]
	public class MainTest
	{
		[Test]
		public void Test()
		{
			string[] strarr = {};
			TestHarness.Main(strarr);
			Assertion.Assert("Main failed", true);
		}
	}

}
