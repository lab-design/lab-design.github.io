using System;
namespace SET{
public instancelevel aspect OrderedPair 
{   
public System.String Name;
bool busy;
Element A;
Element B;



public void Order(Element A, Element B)
	{
	 addObject(A); addObject(B);
	 this.A = A; this.B = B;
	}

public void RemoveOrder()
	{
	 removeObject(A); removeObject(B);
	}

public bool isPair(Element A, Element B)
	{
	 if(A.Name == this.A.Name)
		if(B.Name == this.B.Name) return true;
	 return false;
	}

after():fset(System.String Element.Name)
	{
	if(!busy) 
	   {
	    busy = true;
	    Element elm = (Element) thisJoinPoint.getTarget();
	    if(elm == this.A) { 
		   Console.WriteLine(" Name of an element in A changed -> changing the name of the corresponding element in B.");
		   B.Name = elm.Name;
		 }
	    else {
		   Console.WriteLine("  Name of an element in B changed -> changing the name of the corresponding element in A.");
		   A.Name = elm.Name;
		 }			    
	    busy = false;
	   }
	}
}
}
