public aspect MyAspect {

	pointcut SaySomethingExecution(): execution(public void MyClass.SaySomething(string s));
	
	after(): SaySomethingExecution() {
                string p = (string)(thisJoinPoint.getArgs()[0]);
		System.Console.WriteLine("Parameter: " + p);
	}
}
