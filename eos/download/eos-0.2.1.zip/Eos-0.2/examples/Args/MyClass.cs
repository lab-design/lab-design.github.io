
public class MyClass {

	public static void Main(string[] args) {
		MyClass m = new MyClass();
		m.SaySomething("foo");
	}
	
	public void SaySomething(string something) {
		System.Console.WriteLine(something);
	}
	
}