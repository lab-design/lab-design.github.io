
public class MyClass {

	public static void Main(string[] args) {
                MyClass m = new MyClass();
		m.SayHello();
		m.SaySomething("foo");
	}
	
	public void SayHello() {
		System.Console.WriteLine("Hello World!");
	}
	
	public void SaySomething(string something) {
		System.Console.WriteLine(something);
	}
	
}