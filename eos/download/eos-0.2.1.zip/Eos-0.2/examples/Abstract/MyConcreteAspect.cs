public aspect MySubAspect : MyAbstractAspect {
	override pointcut AbstractPointcut() : execution (public void MyClass.any());
}