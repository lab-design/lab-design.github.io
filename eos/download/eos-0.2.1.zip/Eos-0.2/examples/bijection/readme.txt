example/bijection/readme.txt

Bijection Example:

This example demonstrates the use of instance level aspects to 
implement bijection between two sets. 

Description:

Class Set (Set.cs) provides methods Insert, Remove and Retrieve. 
To maintain a bijection, we need to insure that whenever an element
is inserted in a Set (say A) a corresponding element is inserted in 
the other Set (say B). To implement that insetance level aspect 
Bijection (Bijection.cs) needs to attach advices to the methods Insert
and Remove of class Set. Relate method relates the desired instances of 
Set (here A and B) using implicit methods addObject provided by the 
instance level aspect. 

Key Ideas: 

Implicit Methods - An instance level aspect provides implicit methods
addObject and removeObject. These methods can be called with object as 
arguments to weave and unweave advices from these objects. In the bijection
example in the Relate method of aspect Bijection, addObject is called with
A and B as argument to weave advices into A and B. 

**********************************************************************
An instance level advice is not weaved into an instance untill it is 
explicitly weaved using addObject method.
********************************************************************** 