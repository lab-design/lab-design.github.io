public class MyClass {

	public static void Main(string[] args) {
		MyClass h = new MyClass();
		h.SayHello();
		h.SaySomething("foo");
	}
	
	public void SayHello() {
		System.Console.WriteLine("Hello World!!");
	}
	
	public void SaySomething(string something) {
		System.Console.WriteLine(something);
	}
	
}