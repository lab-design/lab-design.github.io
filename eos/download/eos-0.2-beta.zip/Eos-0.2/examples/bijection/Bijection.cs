using System;
namespace SET{
public instancelevel aspect Bijection 
{   
bool busy;
Set A;
Set B;

/* Method Relate uses the implicit method addObject provided by instancelevel aspect to add Set A and Set B into 
 * Bijection relationship.
 */

public void Relate(Set A, Set B)
	{
	 addObject(A); addObject(B);
	 this.A = A; this.B = B;
	}

after():execution(public bool Set.Insert())
	{
	bool retval = (bool) thisJoinPoint.getReturnValue();
	if(retval && !busy) 
	   {
	   busy = true;
	   Set set = (Set) thisJoinPoint.getTarget();
	   object[] arguments = thisJoinPoint.getArgs();
	   System.String name = ((Element) arguments[0]).Name;
	   if(set == this.A) { 
	   	Console.WriteLine(" Inserting an element in B corresponding to element " + name + " in A");
		Element b = new Element(name);
		B.Insert(b);
		}
	   else {
	   	Console.WriteLine(" Inserting an element in A corresponding to element " + name + " in B");
		Element a = new Element(name);
		A.Insert(a);
		}			    
	   busy = false;
	   }
	}

after():execution(public bool Set.Remove())
	{
	bool retval = (bool) thisJoinPoint.getReturnValue();
	if(retval&&!busy) 
	   {
	     busy = true;
	     Set set = (Set) thisJoinPoint.getTarget();
	     object[] arguments = thisJoinPoint.getArgs();
	     System.String name = ((Element) arguments[0]).Name;
	     if(set == this.A) { 
		  Console.WriteLine(" Removing the element from B corresponding to element " + name + " in A");
		  Element b = new Element(name);
		  B.Remove(b);
		}
	     else {
		  Console.WriteLine(" Removing the element in A corresponding to element " + name + " in B");
		  Element a = new Element(name);
		  A.Remove(a);
		}			    
	     busy = false;
	   }
	}
}
}
