using System;
namespace BIT{
public class Bit 
{   
bool value;
public Bit() { /* Initializing value to false */ value = false; }
public void Set() { value = true;} 
public bool Get (){ return value;} 
public void Clear() {value= false;}
public void Random(int n) { if(n>10) value = true; if(n<5) value = false; }
}
}
