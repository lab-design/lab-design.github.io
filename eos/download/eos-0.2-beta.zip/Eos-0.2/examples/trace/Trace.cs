using System;
namespace BIT{
public aspect Trace 
{   
public void Select(Bit bit)
	{
	  addObject(bit);
	}
after():execution(public any any.any())
	{
	  Console.WriteLine("In any method");
	}

instancelevel after():execution(public bool Bit.Get())
	{
	Console.WriteLine(" This is a selective advice");
	}
}
}
