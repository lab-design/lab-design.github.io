using System;
using log4net;
using log4net.Config;

public aspect HelloAspect
{

     	private static readonly ILog log = LogManager.GetLogger("Logger" );
 
	HelloAspect()
	{
		BasicConfigurator.Configure();           
	}	      

 	pointcut traceMethods():execution(any any(..))
 		|| initialization( any(..))
 		&& !within(HelloAspect);
	                  

	before():traceMethods()
	{
		string paramBuffer ="\n\t[This: ";
		paramBuffer += thisJoinPoint.This;
		Object[] arguments = thisJoinPoint.Args;
		log.Debug("Number of args = " + arguments.GetUpperBound(0));
		paramBuffer += "]\n\t[Args: (";
		for ( int i = arguments.GetLowerBound(0); i <= arguments.GetUpperBound(0); i++ ) 
		{
		    Object argument = arguments[i];
		    paramBuffer += argument;
		    if (i != arguments.GetUpperBound(0)-1) {
			paramBuffer += ',';
		    }
		}
		paramBuffer += ")]";
		log.Debug( paramBuffer);
		log.Debug("Entering: " + thisJoinPoint); 
	}     

	after():traceMethods()
	{
		log.Debug("Exiting: " + thisJoinPoint); 
	}     
}

