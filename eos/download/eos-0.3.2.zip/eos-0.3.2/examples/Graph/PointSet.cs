public class PS: System.Collections.CollectionBase
{
	public PS()
	{
	}
	public bool Add(P p)
	{
		System.Console.WriteLine("Adding a P ({0},{1})", p.GetX(), p.GetY());
		if(!List.Contains(p))
		{
			List.Add(p);
			return true;
		}
		return false;
	}
	public bool Remove(P p)
	{
		System.Console.WriteLine("Removing a P ({0},{1})", p.GetX(), p.GetY());
		for(int i =0; i< Count -1; i++)
		{
			if(List[i].Equals(p))
			{
				Remove(i);
				return true;
			}
		}
		return false;
	}
	public void Remove(int index)
	{
		if (index <= Count - 1 && index >= 0)
		{
			List.RemoveAt(index); 		 
		}
	}  
}