public class V
{
	int X, Y;
	public V( int X, int Y){ this.X = X; this.Y = Y; }
	public void SetX(int X){ this.X = X; }
	public void SetY(int Y){ this.Y = Y; }
	public int GetX(){ return X; }
	public int GetY(){ return Y;}
	public override bool Equals(object o)
	{
		if(o is V)
		{
			V v = (V) o;
			if(v.GetX() == this.GetX() && v.GetY() == this.GetY()) return true;
		}
		return false;
	}
}

