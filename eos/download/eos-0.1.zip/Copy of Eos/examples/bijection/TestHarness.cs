using System;
namespace SET 
{
public class TestHarness 
	{
	public static void Main (string[] argument)
      		{ 
		Set A = new Set();
		Set B = new Set();
		Bijection bj = new Bijection();
		bj.Relate(A,B);
		Element A1 = new Element("A1");
		A.Insert(A1);
		Element B1 = new Element("B1");
		B.Insert(B1);
		A.Insert(A1);
		A.Remove(A1);
		Console.WriteLine("Done");
      		}
       
	};   // END class TestHarness 
}
