using System;
namespace SET{
public instancelevel aspect CrossProduct : System.Collections.CollectionBase
{   
bool busy;
Set A;
Set B;

public void Relate(Set A, Set B)
	{
	 addObject(A); addObject(B);
	 this.A = A; this.B = B;
	}

after():execution(public bool Set.Insert())
	{
	if(!busy && (bool) thisJoinPoint.getReturnValue()) 
		  {
		   busy = true;
		   Set set = (Set) thisJoinPoint.getTarget();
		   object[] arguments = thisJoinPoint.getArgs();
		   System.String name = ((Element) arguments[0]).Name;
		   OrderedPair op = new OrderedPair();
		   if(set == this.A) { 
		   	Console.WriteLine(" Inserting an element in B corresponding to element " + name + " in A");
			Element b = new Element(name);
			B.Insert(b);
			op.Order((Element) arguments[0], b);
			}
		   else {
		   	Console.WriteLine(" Inserting an element in A corresponding to element " + name + " in B");
			Element a = new Element(name);
			A.Insert(a);
			op.Order((Element) arguments[0], a);
			}			    
		   Add(op);
		   busy = false;
		   }
	}

after():execution(public bool Set.Remove())
	{
	if(!busy && (bool) thisJoinPoint.getReturnValue()) 
		  {
		   busy = true;
		   Set set = (Set) thisJoinPoint.getTarget();
		   object[] arguments = thisJoinPoint.getArgs();
		   System.String name = ((Element) arguments[0]).Name;
		   Remove((Element) arguments[0], (Element) arguments[0]);
		   if(set == this.A) { 
		   	Console.WriteLine(" Removing the element from B corresponding to element " + name + " in A");
			Element b = new Element(name);
			B.Remove(b);
			}
		   else {
		   	Console.WriteLine(" Removing the element in A corresponding to element " + name + " in B");
			Element a = new Element(name);
			A.Remove(a);
			}			    
		   busy = false;
		   }
	}

public void Add(OrderedPair op)
	{
	   List.Add(op); 
	}

public bool Remove(Element A, Element B)
	{
	 int index = 0;
	 // Check to see if the collection contains an ordered pair (A,B) 
	 System.Collections.IEnumerator OrderedPairEnumerator = this.GetEnumerator();
	 while ( OrderedPairEnumerator.MoveNext() )
	      {
		 if(((OrderedPair)(OrderedPairEnumerator.Current)).isPair(A,B))
			{ // This is the element we have to remove
   			     if (index <= Count - 1 && index >= 0)
      				{
				   ((OrderedPair)(OrderedPairEnumerator.Current)).RemoveOrder();
			 	   List.RemoveAt(index);
				   return true; 		 
      				}
			     else return false;
			}
		index ++;
	      }
	 return false;
	}  
}

}
