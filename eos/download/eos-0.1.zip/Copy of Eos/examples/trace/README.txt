README

This directory contains source code for the trace example.

The trace example demonstrates type level aspects (similar to languages like AspectJ and HyperJ implements) for ilaC# containing one instance level advice.