using System;
namespace BIT 
{
public class TestHarness 
	{
	public static void Main (string[] argument)
      		{ 
          	Bit bit1 = new Bit();
		    Bit bit2 = new Bit();
          	bit1.Set();
          	bit1.Clear();
		    bit1.Get();
		    Trace.AspectOf().Select(bit2);
		    bit2.Set();
		    bit2.Get();
		    bit2.Clear();
		    Console.WriteLine("Done");
      		}
       
	};   // END class TestHarness 
}
