using System;
namespace BITSYS
{
	public instancelevel aspect Consistency 
	{   
		Bit bit1, bit2;
		bool busy;
		public Consistency(Bit bit1, Bit bit2)
		{
			addObject(bit1);
			addObject(bit2);
			this.bit1 = bit1;
			this.bit2 = bit2;
			busy = false;
		}
		after():execution(public void Bit.Set ())
		{
		if(!busy)
			{
			busy = true;
			Bit bit = (Bit) thisJoinPoint.getTarget();
			if(bit == bit1)bit2.Set();
	        else bit1.Set();
	        busy = false;
			}
		}
		after():execution(public void Bit.Clear ())
		{
		if(!busy)
			{
	        	busy = true;
			Bit bit = (Bit) thisJoinPoint.getTarget();
	        	if(bit == bit1)bit2.Clear();
	        	else bit1.Clear();
			busy = false;
			}
		}
	}
}
