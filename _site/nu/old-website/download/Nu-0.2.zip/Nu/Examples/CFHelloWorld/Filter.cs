#region "Copyright(C)2006, Iowa State University"
/********************************************************************************
 *                                                                              *
 * This file is part of the Nu compiler source Code.                            *
 *                                                                              *
 * The contents of this file are subject to the Mozilla Public License          *
 * Version 1.1 (the "License"); you may not use this file except in             *
 * compliance with the License. You may obtain a copy of the License at         *
 * either http://www.mozilla.org/MPL/.                                          *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License     *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * Author: Robert Dyer                                                          *
 * Copyright (C) 2006 Iowa State University.                                    *
 * All Rights Reserved.                                                         *
 *                                                                              *
 ********************************************************************************/
# endregion

using System;

namespace CFHelloWorld
{
	using System.Collections;
	using Nu.Runtime;
	using Nu.Runtime.Pointcut;
	using Nu.Runtime.Delegate;
	using Nu.Runtime.Pattern;

	/// <summary>
	/// Abstract base class for all filters.  Provides the Enable() method to
	/// start filtering and the Match() method for checking filter elements
	/// to accept/reject a message.  Also provides tracking the filter's
	/// filter elements.
	/// </summary>
	abstract public class Filter : IFilter
	{
		/// <summary>
		/// The filter elements contained in this filter.
		/// </summary>
		protected ArrayList filterElements = new ArrayList();
		/// <summary>
		/// The next filter (if there is one).
		/// </summary>
		protected IFilter nextFilter;


		/// <summary>
		/// See IFilter for documentation.
		/// </summary>
		public abstract void Accept(Message m, FilterElement element);
		
		/// <summary>
		/// See IFilter for documentation.
		/// </summary>
		public abstract void Reject(Message m);


		/// <summary>
		/// See IFilter for documentation.
		/// </summary>
		public void AddFilterElement(FilterElement element)
		{
			filterElements.Add(element);
		}


		/// <summary>
		/// See IFilter for documentation.
		/// </summary>
		public void Enable()
		{
			Nu.Runtime.Dispatcher.Bind(
				new Execution(new MethodPattern(Modifiers.Any, "Send")),
				new JPDelegate(TrackMessage));

			Nu.Runtime.Dispatcher.Bind(
				new Return(new MethodPattern(Modifiers.Any, "Send")),
				new JPDelegate(ReturnMessage));
		}


		/// <summary>
		/// Delegate invoked on execution(Any Send) to indicate a message is being sent.
		/// </summary>
		/// <param name="thisJP">The current join point.</param>
		private void TrackMessage(IJoinpoint thisJP)
		{
			Test((Message)thisJP.This);
		}


		/// <summary>
		/// Delegate invoked on return(Any Send) to indicate a message was sent.
		/// </summary>
		/// <param name="thisJP">The current join point.</param>
		private void ReturnMessage(IJoinpoint thisJP)
		{
			Message m = (Message)thisJP.This;
			
//			thisJP.ReturnValue = m.returnValue;
		}
		

		/// <summary>
		/// See IFilter for documentation.
		/// </summary>
		public void Test(Message m)
		{
			// check the message with each filter element in this filter
			foreach (FilterElement element in filterElements)
				if (element.Accept(m))
				{
					Accept(m, element);
					return;
				}

			// all filter elements rejected the message
			Reject(m);
		}
	}
}
