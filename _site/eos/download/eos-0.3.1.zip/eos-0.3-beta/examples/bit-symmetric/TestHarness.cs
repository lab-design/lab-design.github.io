using System;
namespace BITSYS 
{
	public class TestHarness 
	{
		public static void Main (string[] argument)
		{ 
			Bit bit1 = new Bit(1);
			Bit bit2 = new Bit(2);
			Bit bit3 = new Bit(3);
                                                bit2.Set();
			System.Console.WriteLine();
			System.Console.WriteLine(" Bit 1 and Bit 2 should be consistent from now onwards");
			Consistency c = new Consistency(bit1, bit2);
			bit1.Set();
			System.Console.WriteLine();
			bit2.Clear();
			System.Console.WriteLine();
			bit3.Set();
		}
	};   // END class TestHarness 
}
