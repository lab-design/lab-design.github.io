public class LS: System.Collections.CollectionBase
{
	public LS()
	{
	}
	public bool Add(L l)
	{
		System.Console.WriteLine("Adding a L ({0},{1})-({2},{3})", l.GetStart().GetX(),l.GetStart().GetY(), l.GetEnd().GetX(), l.GetEnd().GetY());
		if(!List.Contains(l))
		{
			List.Add(l);
			return true;
		}
		return false;
	}
	public bool Remove(L l)
	{
		System.Console.WriteLine("Removing a L ({0},{1})-({2},{3})", l.GetStart().GetX(),l.GetStart().GetY(), l.GetEnd().GetX(), l.GetEnd().GetY());
		for(int i =0; i< Count -1; i++)
		{
			if(List[i].Equals(l))
			{
				Remove(i);
				return true;
			}
		}
		return false;
	}
	public void Remove(int index)
	{
		if (index <= Count - 1 && index >= 0)
		{
			List.RemoveAt(index); 		 
		}
	}  
}