public class HelloWorld
{
	public static void Main (string [] arguments)
	{
		HelloWorld hw = new HelloWorld();
		hw.Print("Hello World");
		try{
		  hw.Print(null);
		}catch(System.ArgumentNullException e){
			/* Ignore it */
		}
	}

	public string Print(string text)
	{
	       if(text == null) throw new System.ArgumentNullException();

		System.Console.WriteLine(text);

		return text;
	}
}
