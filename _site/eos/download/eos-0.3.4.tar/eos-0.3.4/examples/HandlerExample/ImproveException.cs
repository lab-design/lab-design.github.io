using System;
using Eos.Runtime;

///
/// This classpect implements an exception throwing policy.
/// The policy applies to all System.ArgumentNullExceptions
/// and it detects if the programmer is not inserting any
/// context specific message when throwing the exception.
///  
public class ImproveException 
{
        static before handler(System.ArgumentNullException)&&joinpoint(jp):
	  call Improve(Eos.Runtime.IJoinpoint jp);

	public void Improve(Eos.Runtime.IJoinpoint jp){
	  System.Exception e = (System.Exception)jp.Args[0];
	  System.ArgumentNullException eStandard = new System.ArgumentNullException();
	  if(e.Message == eStandard.Message) System.Console.WriteLine("No context specific message was added when this exception was thrown");
	  System.Console.WriteLine("System.ArgumentNullException was caught");
	}
}
