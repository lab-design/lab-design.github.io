/* This example demonstrate how a simple method 
   call tracing can be done using Eos.  */

using System;	 

namespace HelloWorld
{
	public class Hello
	{
		static void Main(string[] arguments)
		{
			Object1 obj = new Object1("Howard");
			Object2 obj2 = new Object2("Social", "Calendar");
			System.Console.WriteLine("Hello");
			String i = obj.getAString("bud");
			String j = obj2.getAString("random");
		}
	}

	public class Object1
	{
		public Object1(System.String fred)
		{
		}
		public string getAString(System.String dave)
		{
			return "Harv";
		}
	}

	public class Object2
	{
		public Object2(System.String fred, System.String jason)
		{
		}
		public string getAString(System.String dave)
		{
			return "Harv";
		}
	}

}


