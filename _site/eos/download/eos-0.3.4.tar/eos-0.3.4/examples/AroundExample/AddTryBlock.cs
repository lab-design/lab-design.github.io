using System;
using Eos.Runtime;

public class AddTryBlock 
{
	public object AddTry(Eos.Runtime.AroundADP adp)
	{
	      object result = null;
	      try{
	            Console.WriteLine("Around everything") ;
	            result = adp.InnerInvoke(); 
	         } catch (Exception ex){
	            Console.WriteLine(ex.Message) ;
	         }  	 
	      return result;
	}
	
	static object around execution(any any(..)) || initialization(any(..)) 
              && !within(AddTryBlock) && aroundptr(adp): 
              call AddTry(Eos.Runtime.AroundADP adp);

}