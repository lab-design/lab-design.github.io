public class VS: System.Collections.CollectionBase
{
	public VS()
	{
	}
	public bool Add(V v)
	{
		System.Console.WriteLine("Adding a V ({0},{1})", v.GetX(), v.GetY());
		if(!List.Contains(v))
		{
			List.Add(v);
			return true;
		}
		return false;
	}
	public bool Remove(V v)
	{
		System.Console.WriteLine("Adding a P ({0},{1})", v.GetX(), v.GetY());
		for(int i =0; i< Count -1; i++)
		{
			if(List[i].Equals(v))
			{
				Remove(i);
				return true;
			}
		}
		return false;
	}
	public void Remove(int index)
	{
		if (index <= Count - 1 && index >= 0)
		{
			List.RemoveAt(index); 		 
		}
	}  
}