using Eos.Runtime;
public class VS_PS
{
	PS ps;
	VS vs;
	public VS_PS(VS vs, PS ps)
	{
		this.vs = vs; this.ps = ps; 
		addObject(vs); addObject(ps);
	}

	public void AddPoint(bool ret, V v)
	{
		System.Console.WriteLine("VS_PS:after VS.Add");
		if(ret)
		{
			ps.Add( new P(v.GetX(), v.GetY()));
		}
	}
	public void RemovePoint(bool ret, V v)
	{
		System.Console.WriteLine("VS_PS:after VS.Remove");
		if(ret)
		{
			ps.Remove( new P(v.GetX(), v.GetY()));
		}
	}

	public void AddVertex(bool ret, P p)
	{
		System.Console.WriteLine("VS_PS:after PS.Add");
		if(ret)
		{
			vs.Add( new V(p.GetX(), p.GetY()));
		}
	}
	
	public void RemoveVertex(bool ret, P p)
	{
		System.Console.WriteLine("VS_PS:after PS.Remove");
		if(ret)
		{
			vs.Remove( new V(p.GetX(), p.GetY()));
		}
	}

	/* Join point Method Bindings */
	after execution(public bool VS.Add(V)) 
	    && return(ret)&& args(v): 
	    call AddPoint(bool ret, V v);

	after execution(public bool VS.Remove(V)) 
	    && return(ret)&& args(v): 
	    call RemovePoint(bool ret, V v);

	after execution(public bool PS.Add(P)) 
	    && return(ret)&& args(p): 
	    call AddVertex(bool ret, P p);

	after execution(public bool PS.Remove(P)) 
	    && return(ret)&& args(p): 
	    call RemoveVertex(bool ret, P p);

}
