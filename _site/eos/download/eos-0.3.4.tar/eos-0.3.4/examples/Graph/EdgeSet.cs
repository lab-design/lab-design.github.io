public class ES: System.Collections.CollectionBase
{
	public ES()
	{
	}
	public bool Add(E e)
	{
		System.Console.WriteLine("Adding an E ({0},{1})-({2},{3})", e.GetStart().GetX(),e.GetStart().GetY(), e.GetEnd().GetX(), e.GetEnd().GetY());
		if(!List.Contains(e))
		{
			List.Add(e);
			return true;
		}
		return false;
	}
	public bool Remove(E e)
	{
		System.Console.WriteLine("Removing an E ({0},{1})-({2},{3})", e.GetStart().GetX(),e.GetStart().GetY(), e.GetEnd().GetX(), e.GetEnd().GetY());
		for(int i =0; i< Count -1; i++)
		{
			if(List[i].Equals(e))
			{
				Remove(i);
				return true;
			}
		}
		return false;
	}
	public void Remove(int index)
	{
		if (index <= Count - 1 && index >= 0)
		{
			List.RemoveAt(index); 		 
		}
	}  
}