public class UI
{
	LS LS;
	PS PS;
	public UI(LS LS, PS PS)
	{
		this.LS = LS; 
		this.PS = PS; 
	}
	public void AddP( int X, int Y)
	{ 
		P p = new P(X,Y);
		PS.Add(p);
	}
	public void RemoveP( int X, int Y)
	{ 
		P p = new P(X,Y);
		PS.Add(p);
	}
	public void AddL( int X1, int Y1, int X2, int Y2)
	{
		P Start = new P(X1, Y1);
		P End = new P(X2, Y2);
		L l = new L(Start, End);
		LS.Add(l);
	}

	public void SetLazy(){}

	public void ResetLazy() { }
}