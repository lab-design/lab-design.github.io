public class G
{
	ES es;
	VS vs;
	public G(ES es, VS vs)
	{
		this.es = es; this.vs = vs; addObject(es); addObject(vs);
	}

	public void AddEnds(bool ret, E e)
	{
		System.Console.WriteLine("G:After ES.Add");
		if(ret)
		{
			vs.Add(e.GetStart());
			vs.Add(e.GetEnd());
		}
	}

	public void RemoveIncident(bool ret, V v)
	{
		if(ret)
		{
			//			vs.Add(e.GetStart());
			//			vs.Add(e.GetEnd());
		}
	}

	after execution(public bool ES.Add(E)) && return(ret)&& args(e): call AddEnds(bool ret, E e);

	after execution(public bool VS.Remove(V)) && return(ret)&& args(v): call RemoveIncident(bool ret, V v);

}
