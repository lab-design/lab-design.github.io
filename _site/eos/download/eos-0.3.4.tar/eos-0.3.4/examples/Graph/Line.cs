public class L 
{
	P Start,End;
	public L(P Start, P End){ this.Start = Start; this.End = End; }
	public void SetStart(P Start) { this.Start = Start; }
	public void SetEnd(P End) { this.End = End; }
	public P GetStart() { return Start;}
	public P GetEnd(){ return End; }
	public override bool Equals(object o)
	{
		if(o is L)
		{
			L l = (L)o;
			if( l.GetStart().Equals(this.GetStart()) 
				&& l.GetEnd().Equals(this.GetEnd())) 
				return true;
		}
		return false;
	}
}