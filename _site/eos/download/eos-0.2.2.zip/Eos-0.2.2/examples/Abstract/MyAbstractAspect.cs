public abstract aspect MyAbstractAspect {
	abstract pointcut AbstractPointcut();
        before(): AbstractPointcut() {
           System.Console.WriteLine("before join points matched by abstract pointcut ");
        }        
}