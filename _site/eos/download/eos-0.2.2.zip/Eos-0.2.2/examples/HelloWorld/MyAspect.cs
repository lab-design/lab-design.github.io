public aspect MySubAspect  {
	pointcut p1() : execution(public void MyClass.SayHello());
	
	before() : p1() {
		System.Console.WriteLine("---> EOS1!");
	}
	
	pointcut p2() : execution(public any any.any());
	
	before() : p2() {
		System.Console.WriteLine("---> EOS2!");
	}
	
}