using System;
namespace BIT{
	public instancelevel aspect AEquality 
	{   
	Bit headBit;
	Bit tailBit;
	bool busy;

	public AEquality(Bit headBit, Bit tailBit)
		{
		this.headBit = headBit; this.tailBit = tailBit;
		AddRoleHead(headBit); AddRoleTail(tailBit);
		}

	role Head {
		after():execution(public void Bit.Set())
			{
			if(!busy){
				busy = true;
				Console.WriteLine("Head Bit is Set, setting the tail bit");
				tailBit.Set();
				busy = false;
				}
			}
		after():execution(public void Bit.Clear())
			{
			if(!busy){
				busy = true;
				Console.WriteLine("Head Bit is Cleared, clearing the tail bit");
				tailBit.Clear();
				busy = false;
				}
			}
		}

	role Tail { 

		after():execution(public void Bit.Set())
			{
			if(!busy){
				busy = true;
				Console.WriteLine("Tail Bit is Set, setting the head bit");
				headBit.Set();
				busy = false;
				}
			}
		}
	}
}
