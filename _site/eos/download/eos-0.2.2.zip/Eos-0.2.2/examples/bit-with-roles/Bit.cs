using System;
namespace BIT{
public class Bit 
{   
bool value;
public Bit() { value = false; }
public void Set() { value = true; Console.WriteLine("In Bit.Set"); } 
public bool Get (){Console.WriteLine("In Bit.Get"); return value;} 
public void Clear() {value= false; Console.WriteLine("In Bit.Clear");}
}
}
