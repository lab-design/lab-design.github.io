using System;
namespace BIT 
{
public class TestHarness 
	{
	public static void Main (string[] argument)
      		{ 
          	Bit bit1 = new Bit();
		Bit bit2 = new Bit();
		AEquality aeq = new AEquality(bit1, bit2);// bit1 will be the head and bit2 will be the tail.
          	bit1.Set();
          	bit1.Clear();
		bit2.Set();
		bit2.Clear();      
		Console.WriteLine("Done");
      		}
       
	};   // END class TestHarness 
}
