namespace SET {

public class Set : System.Collections.CollectionBase {

	public bool Insert(Element element)
		{
		 // Check to see if the collection contains an Element of the same name
	         System.Collections.IEnumerator SetEnumerator = this.GetEnumerator();
		 while ( SetEnumerator.MoveNext() )
		        if(((Element)(SetEnumerator.Current)).Name == element.Name)
					return false; /// Can't put duplicate elements return False
		   List.Add(element); // Add the element
		   return true; /// Successful Insert
		}

	public bool Remove(Element element)
		{
		 int index = 0;
		 // Check to see if the collection contains an Element of the same name
	         System.Collections.IEnumerator SetAEnumerator = this.GetEnumerator();
		 while ( SetAEnumerator.MoveNext() )
			{
		        if(((Element)(SetAEnumerator.Current)).Name == element.Name)
					{ // This is the element we have to remove
   					if (index <= Count - 1 && index >= 0)
      						{
			 			List.RemoveAt(index);
						return true; 		 
      						}
					 else return false;
					}
			index ++;
			}
		return false;
		}  

	public Element Retrieve(string Name)
		{
		 // returns the element "Name". If the element is not contained in the collection return null
	         System.Collections.IEnumerator SetEnumerator = this.GetEnumerator();
		 while ( SetEnumerator.MoveNext() )
		        if(((Element)(SetEnumerator.Current)).Name == Name)return (Element)(SetEnumerator.Current);
		 return null;
		}

   }

public class Element {
	public System.String Name;
	public Element(System.String Name)
		{ this.Name = Name; }
	}

}