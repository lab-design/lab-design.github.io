namespace BITSYS
{
	public class Bit 
	{   
		bool value;
		public Bit() { value = false; }
		public void Set() { value = true; } 
		public bool Get (){ return value; } 
		public void Clear() {value= false; }
	}
}
