using System;
namespace BITSYS
{
	public instancelevel aspect Consistency 
	{   
		Bit bit1, bit2;
		bool busy;
		public Consistency(Bit bit1, Bit bit2)
		{
	        Console.WriteLine("Adding bit1 and bit2 to the relationship");
			addObject(bit1);
			addObject(bit2);
			this.bit1 = bit1;
			this.bit2 = bit2;
			busy = false;
		}
		after():execution(public void BITSYS.Bit.Set ())
		{
		if(!busy)
			{
			busy = true;
			Bit bit = (Bit) thisJoinPoint.getTarget();
	        	if(bit == bit1)
					{
					bit2.Set();
					Console.WriteLine("Bit1 was set so setting bit2.");
					}
	        	else 
					{
					bit1.Set();
					Console.WriteLine("Bit2 was set so setting bit1.");
	                }
	        busy = false;
			}
		}
		after():execution(public void BITSYS.Bit.Clear ())
		{
		if(!busy)
			{
			busy = true;
			Bit bit = (Bit) thisJoinPoint.getTarget();
	        	if(bit == bit1)
					{
					bit2.Clear();
					Console.WriteLine("Bit1 was cleared so clearing bit2.");
					}
	        	else 
					{
					bit1.Clear();
					Console.WriteLine("Bit2 was cleared so clearing bit1.");
	                }

			busy = false;
			}
		}
	}
}
