namespace SuperAspectSample {

        public aspect SuperAspect {
                pointcut SuperPointcut() : execution(public any any.any());
        }
	public aspect SubAspect: SuperAspect {
		// new pointcut SuperPointcut() : execution(public any any.any(string));	
	}
}
