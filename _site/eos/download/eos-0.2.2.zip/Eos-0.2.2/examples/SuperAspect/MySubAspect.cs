namespace SuperAspectSample {
	public aspect MySubAspect : SubAspect {
	
		before() : SuperPointcut() {
			System.Console.WriteLine("---> before a non static method!");
		}
		
	}
}