namespace HelloWorld {
	public aspect MyAspect {
                
                before(): execution(public any any.any()) {
		    addObject(thisJoinPoint.getTarget());                
                }

		instancelevel before(): execution (public any any.any()) {
			System.Console.WriteLine(">>> before a method!");
		}

                after(): execution(public any any.any()) {
		    removeObject(thisJoinPoint.getTarget());                
                }
	}
}