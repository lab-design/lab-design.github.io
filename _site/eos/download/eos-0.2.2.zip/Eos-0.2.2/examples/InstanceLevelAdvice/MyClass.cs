namespace HelloWorld {
	public class MyClass {
	
		public static void Main(string[] args) {
			MyClass m = new MyClass();
			m.SayHello();
		}
		
		public void SayHello() {
			System.Console.WriteLine("Hello World!");
		}
	}
}