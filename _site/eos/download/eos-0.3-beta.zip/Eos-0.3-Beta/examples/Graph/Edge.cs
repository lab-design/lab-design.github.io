public class E 
{
	V Start,End;
	public E(V Start, V End){ this.Start = Start; this.End = End; }
	public void SetStart(V Start) { this.Start = Start; }
	public void SetEnd(V End) { this.End = End; }
	public V GetStart() { return Start;}
	public V GetEnd(){ return End; }
	public override bool Equals(object o)
	{
		if(o is E)
		{
			E e = (E)o;
			if( e.GetStart().Equals(this.GetStart()) 
				&& e.GetEnd().Equals(this.GetEnd())) 
				return true;
		}
		return false;
	}
}