public class ES_LS
{
	ES es;
	LS ls;
	public ES_LS(ES es,  LS ls)
	{
		this.es = es; this.ls = ls; 
		addObject(es);  addObject(ls); 
	}

	public void AddLine(bool ret, E e)
	{
		System.Console.WriteLine("ES_LS:after ES.Add");
		if(ret)
		{
			V Start = e.GetStart();
			V End = e.GetEnd();
			P p1 = new P(Start.GetX(), Start.GetY());
			P p2 = new P(End.GetX(), End.GetY());
			ls.Add(new L(p1,p2));
		}
	}

	public void RemoveLine(bool ret, E e)
	{
		System.Console.WriteLine("ES_LS:after ES.Remove");
		if(ret)
		{
			V Start = e.GetStart();
			V End = e.GetEnd();
			P p1 = new P(Start.GetX(), Start.GetY());
			P p2 = new P(End.GetX(), End.GetY());
			ls.Remove(new L(p1,p2));
		}
	}

	public void AddEdge(bool ret, L l)
	{
		System.Console.WriteLine("ES_LS:after LS.Add");
		if(ret)
		{
			P Start = l.GetStart();
			P End = l.GetEnd();
			V v1 = new V(Start.GetX(), Start.GetY());
			V v2 = new V(End.GetX(), End.GetY());
			es.Add(new E(v1,v2));
		}
	}

	public void RemoveEdge(bool ret, L l)
	{
		System.Console.WriteLine("ES_LS:after LS.Remove");
		if(ret)
		{
			P Start = l.GetStart();
			P End = l.GetEnd();
			V v1 = new V(Start.GetX(), Start.GetY());
			V v2 = new V(End.GetX(), End.GetY());
			es.Remove(new E(v1,v2));
		}
	}

	after execution(public bool ES.Add(E)) && return(ret)&& args(e): call AddLine(bool ret, E e);
	after execution(public bool ES.Remove(E)) && return(ret)&& args(e): call RemoveLine(bool ret, E e);


	after execution(public bool LS.Add(L)) && return(ret)&& args(l): call AddEdge(bool ret, L l);
	after execution(public bool LS.Remove(L)) && return(ret)&& args(l): call RemoveEdge(bool ret, L l);

}
