public class AppEntry 
{
	public static void Main (string [] arguments)
	{
		System.Console.WriteLine(" Starting program ");
		LS ls = new LS();
		PS ps = new PS();
		ES es = new ES();
		VS vs = new VS();

		UI ui = new UI(ls, ps);
		
		ES_LS es_ls = new ES_LS(es,ls);

		VS_PS vs_ps = new VS_PS(vs, ps);

		G g = new G(es, vs);

		Lazy l = new Lazy(vs_ps, es_ls, g, ui);

		System.Console.WriteLine("\nAdding P 1 ");
		ui.AddP(1, 5);
		
		System.Console.WriteLine("\nAdding P 2 ");
		ui.AddP(2, 10);

		System.Console.WriteLine("\nAdding P 3 ");
		ui.AddP(3, 15);

		System.Console.WriteLine("\nConnecting P 1, 2 by a L");
		ui.AddL(1, 5, 2, 10);

		System.Console.WriteLine("\nGoing to lazy mode");
		ui.SetLazy();

		System.Console.WriteLine("\nConnecting P 2, 3 by a L");
		ui.AddL(2, 10, 3, 15);

		System.Console.WriteLine("\nConnecting P 3, 1 by a L");
		ui.AddL(3, 15, 1, 5);

		System.Console.WriteLine("\nTrying to add P 1 again");
		ui.AddP(1, 5);

		System.Console.WriteLine("\nTrying to add a L for which no Ps exist");
		ui.AddL(10, 15, 12, 10);

	
	}
}
