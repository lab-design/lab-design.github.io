using System;
namespace BITSYS
{
	public class Consistency 
	{   
		Bit bit1, bit2;
		bool busy;
		public Consistency(Bit bit1, Bit bit2)
		{
			addObject(bit1);
			addObject(bit2);
			this.bit1 = bit1;
			this.bit2 = bit2;
			busy = false;
		}

		public void Set_Other_Bit(Bit b, bool ret)
		{
			if(ret) 
			{
				System.Console.WriteLine("Abstract event Bit Set ");
				if(!busy)
				{
					busy = true;
					if(b == bit1) bit2.Set(); else if(b==bit2) bit1.Set();
					busy = false;
				}
			}
			else System.Console.WriteLine(" Just Set Execution");
		}

		public void Clear_Other_Bit(Bit b, bool ret)
		{
			if(ret ) 
			{
				System.Console.WriteLine("Abstract event clear");
				if(!busy)
				{
					busy = true;
					if(b == bit1)bit2.Clear();
					else if(b == bit2) bit1.Clear();
					busy = false;
				}
			}
			else System.Console.WriteLine(" Just Clear Execution");
		}

		pointcut Event_Set(Bit b, bool ret): 
			conditional(if) && withincode(public void Bit.Set ()) 
			&& this(b) && return(ret);

		after Event_Set(b, ret): call Set_Other_Bit(Bit b, bool ret);

		pointcut Event_Clear(Bit b, bool ret):
		     conditional(if) && withincode(public void Bit.Clear())
		     && this(b) && return(ret);
		
		after Event_Clear(b, ret): call Clear_Other_Bit(Bit b, bool ret);
	}
}
