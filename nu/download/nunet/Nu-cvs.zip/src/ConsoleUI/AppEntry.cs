#region "Copyright(C)2005, Hridesh Rajan"
/********************************************************************************
 *                                                                              *
 * This file is part of the Nu compiler source Code.                         *
 *                                                                              *
 * The contents of this file are subject to the Mozilla Public License          *
 * Version 1.1 (the "License"); you may not use this file except in             *
 * compliance with the License. You may obtain a copy of the License at         *
 * either http://www.mozilla.org/MPL/.                                          *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License     *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * Author: Hridesh Rajan                                                        *
 * Copyright (C) 2005 Hridesh Rajan.                                       *
 * All Rights Reserved.                                                         *
 *                                                                              *
 ********************************************************************************/
# endregion

using System;
using System.Collections;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

using PERWAPI;

namespace Nu.ConsoleUI {
	/// <summary>
	/// Summary description for AppEntry.
	/// </summary>
	public class AppEntry {
		/// <summary>
		/// Entry point for the compiler
		/// </summary>
		/// <param name="args">Arguments to the compiler</param>
		[STAThread]
		public static void Main ( string[] args ) {

			//Process command line arguments
			Nu.Utils.CommandLineProcessor clp = new Nu.Utils.CommandLineProcessor(new Nu.Utils.Arguments());
			if (clp.Process(args) < 0)
				System.Environment.Exit(-1);

			//string input_filename = "SensorMain.exe";
            string input_filename = clp.ParsedArgs.srcfile;

			try{
				// Read the assembly file
                PEFile asm = PEFile.ReadPEFile(input_filename);

				PERWAPI.AssemblyRef[] Assemblies = asm.GetImportedAssemblies();
                
				foreach(PERWAPI.AssemblyRef Ref in Assemblies) {
					if(Ref.Name() == "Nu.Runtime")
						runTimeReference = Ref;
				}
                
                /* Modified - Start : If no reference to Nu.Runtime is found, we add the reference to it explicitly */
                if (runTimeReference == null)
                {
                    string nuRunTimeDLL = "Nu.Runtime.dll";
                    PEFile NuRuntimeAsm = PEFile.ReadPEFile(nuRunTimeDLL);
                    runTimeReference = NuRuntimeAsm.GetThisAssembly().MakeRefOf();
                }
                /* Modified - End */

				Nu.Weaver.ILWeaver Weaver = new Nu.Weaver.ILWeaver();
				Weaver.Weave(asm);
                string generated_instrumented_filename;
				if (clp.ParsedArgs.outfile != null)
					generated_instrumented_filename = clp.ParsedArgs.outfile;
				else
					generated_instrumented_filename = input_filename.Substring(0, input_filename.IndexOf(".")) + "_Nu_Instrumented" + ".exe";
                
                //asm.SetFileName("SensorMain2.exe");
                asm.SetFileName(generated_instrumented_filename);
				
                asm.WritePEFile(true);

			}catch(System.IO.FileNotFoundException e) {
				throw new System.ArgumentException("Cannot visit assembly",
                    input_filename, e);
			}

			//Compile();
			//Read();
			//Weave();
			Environment.Exit(0);
		}

		static internal AssemblyRef runTimeReference = null;

		//		public static void Compile()
		//		{
		//		}
		//
		//		public static void Read()
		//		{
		//			PERWAPI.PEFile asm = PERWAPI.PEFile.ReadPEFile("SensorMain.exe");
		//			asm.SetFileName("SensorMain2.exe");
		//			
		//			PERWAPI.ClassDef[] ClassCollection = asm.GetClasses();
		//
		//
		//			Nu.JoinPoint.JoinPointCollector jpc = new Nu.JoinPoint.JoinPointCollector();
		//
		//			// Collect Method Execution Join Points
		//			foreach(PERWAPI.ClassDef Class in ClassCollection)
		//			{
		//#if DEBUG
		//				System.Console.WriteLine(Class.Name());
		//#endif 
		//				foreach(PERWAPI.MethodDef Method in Class.GetMethods())
		//				{
		//#if DEBUG
		//					System.Console.WriteLine(Method.Name());
		//#endif
		//					jpc.CollectMethodExecutionJoinPoints(Method);		
		//
		//					PERWAPI.CILInstructions body = Method.GetCodeBuffer();
		//					
		//					if(body != null) // If there are instructions in the method body
		//					{
		//						PERWAPI.CILInstruction instr = null;
		//						for(; (instr = body.GetNextInstruction())!=null;)
		//						{
		//#if DEBUG
		//							System.Console.WriteLine(instr.GetInstName());
		//#endif
		//							if(instr.GetInstName().Equals("call"));
		//
		//						}
		//					}
		//				}
		//			}
		//
		//			
		//			
		//			PERWAPI.MethodDef handlerDetect = null;
		//			PERWAPI.MethodDef handlerClick = null;
		//
		//
		//			
		//			// Collect Method reference to handler OnDetect
		//			foreach(PERWAPI.ClassDef Class in ClassCollection)
		//			{
		//				if(Class.Name().EndsWith("SenCamMediator"))
		//				{
		//					foreach(PERWAPI.MethodDef Method in Class.GetMethods())
		//					{
		//						if(Method.Name().EndsWith("OnDetect"))
		//						{
		//							handlerDetect = Method;
		//						}
		//						if(Method.Name().EndsWith("OnClick"))
		//						{
		//							handlerClick = Method;
		//						}
		//					}
		//				}
		//			}
		//
		//			foreach(PERWAPI.ClassDef Class in ClassCollection)
		//			{
		//				foreach(PERWAPI.MethodDef Method in Class.GetMethods())
		//				{
		//					if(Method.Name().Equals("Detect"))
		//					{
		//						PERWAPI.CILInstructions body = Method.GetCodeBuffer();
		//						body.StartInsert();
		//						body.MethInst(PERWAPI.MethodOp.call, handlerDetect);
		//						body.EndInsert();
		//					}
		//					if(Method.Name().Equals("Click"))
		//					{
		//						PERWAPI.CILInstructions body = Method.GetCodeBuffer();
		//						body.StartInsert();
		//						body.MethInst(PERWAPI.MethodOp.call, handlerClick);
		//						body.EndInsert();
		//					}
		//				}
		//			}
		//
		//			asm.WritePEFile(true);
		//		}
		//
		//		public static void Weave()
		//		{
		//		}
	}
}

