/********************************************************************************
 *                                                                              *
 * This file is part of the Eos compiler source Code.                         *
 *                                                                              *
 * The contents of this file are subject to the Mozilla Public License          *
 * Version 1.1 (the "License"); you may not use this file except in             *
 * compliance with the License. You may obtain a copy of the License at         *
 * either http://www.mozilla.org/MPL/.                                          *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License     *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * Author: Hridesh Rajan                                                        *
 * Copyright (C) 2004-2006 Hridesh Rajan.                                       *
 * All Rights Reserved.                                                         *
 *                                                                              *
 ********************************************************************************/
using System;
using System.IO;
using System.Collections;

namespace Nu.Utils
{
	public class CommandLineProcessor 
	{

		public CommandLineProcessor(Arguments parsedArgs)
		{
			this.parsedArgs = parsedArgs;
		}

		public virtual int Process ( string[] args )
		{
			// error encountered in arguments. Display usage message
			if (!(new CommandLineArgumentParser(typeof(Arguments), new ErrorReporter(Console.Error.WriteLine))).Parse(args, parsedArgs) || parsedArgs.help) 
			{
				System.Console.Error.Write((new CommandLineArgumentParser(typeof(Arguments), null)).Usage);
				return -1;
			}

			return 0;
		}

		private Nu.Utils.Arguments parsedArgs;
		public Nu.Utils.Arguments ParsedArgs
		{
			get
			{
				return parsedArgs;
			}
		}
	} 

	public class Arguments
	{

		[CommandLineArgument(CommandLineArgumentType.AtMostOnce, "?")]
		public bool help;

		[CommandLineArgument(CommandLineArgumentType.AtMostOnce, "o")]
		public string outfile;

		//Default
		[DefaultCommandLineArgument(CommandLineArgumentType.Required)]
		public string srcfile;

		public Arguments()
		{
		}
	}
}