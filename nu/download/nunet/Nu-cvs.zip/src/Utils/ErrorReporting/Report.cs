#region "Copyright(C)2005, Hridesh Rajan"
/********************************************************************************
 *                                                                              *
 * This file is part of the Nu compiler source Code.                         *
 *                                                                              *
 * The contents of this file are subject to the Mozilla Public License          *
 * Version 1.1 (the "License"); you may not use this file except in             *
 * compliance with the License. You may obtain a copy of the License at         *
 * either http://www.mozilla.org/MPL/.                                          *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License     *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * Author: Hridesh Rajan                                                        *
 * Copyright (C) 2005 Hridesh Rajan.                                       *
 * All Rights Reserved.                                                         *
 *                                                                              *
 ********************************************************************************/
# endregion

using System;
using System.Collections;
using System.Diagnostics;
using System.Text;

namespace Nu.Utils.ErrorReporting
{
	/// <summary>
	///   This class stores errors and warnings during
	///   the passes of the compiler and also provides 
	///   a platform independent way to the rest of the 
	///   program to report errors, warnings and debugging
	///   messages.
	/// </summary>
	/// 
	public class Report 
	{

		/// <summary>  
		///   Collection of errors encountered so far
		/// </summary>
		/// 
		private MessageCollection errors = new MessageCollection(); 
		public MessageCollection Errors 
		{
			get { return errors; }
		}

		/// <summary>  
		///   Collection of warnings encountered so far
		/// </summary>
		/// 
		private MessageCollection warnings = new MessageCollection(); 
		public MessageCollection Warnings 
		{
			get { return warnings; }
		}
		

		/// <summary>  
		///   Whether errors should be throw an exception
		/// </summary>
		public bool Fatal;
		
		/// <summary>  
		///   Whether warnings should be considered errors
		/// </summary>
		public bool WarningsAreErrors;

		/// <summary>  
		///   Whether to dump a stack trace on errors. 
		/// </summary>
		public bool Stacktrace;
		
		/// <summary>  
		///   Level of warning. 
		/// </summary>
		public int WarningLevel;

		//
		// If the 'expected' error code is reported then the
		// compilation succeeds.
		//
		// Used for the test suite to excercise the error codes
		//
		int expected_error = 0;
		//
		// Keeps track of the warnings that we are ignoring
		//
		Hashtable warning_ignore_table;

		void Check (int code)
		{
			if (code == expected_error)
			{
				if (Fatal)
					throw new Exception ();
				
				Environment.Exit (0);
			}
		}

		public void Clear()
		{
			Errors.Clear();
			Warnings.Clear();
		}

		public void Error(int code, string FileName, int LineNumber, string text)
		{
			Error e = new Error(code, FileName, LineNumber, text, Stacktrace, Fatal);
			Errors.Add(e);
		}

		public void Error(int code, string FileName, int LineNumber, int ColumnNumber, string text)
		{
			Error e = new Error(code, FileName, LineNumber, ColumnNumber, text, Stacktrace, Fatal);
			Errors.Add(e);
		}

		public void Error (int code, string text)
		{
			Error e = new Error(code, text);
			Errors.Add(e);
		}

		public void Warning(int code, string FileName, int LineNumber, string text)
		{
			Warning w = new Warning(code, FileName, LineNumber, text, Stacktrace, Fatal);
			Warnings.Add(w);
		}

		public void Warning(int code, string FileName, int LineNumber, int ColumnNumber, string text)
		{
			Warning w = new Warning(code, FileName, LineNumber, ColumnNumber, text, Stacktrace, Fatal);
			Warnings.Add(w);
		}

		public void PrintErrors(System.IO.TextWriter writer)
		{
			foreach(Error e in Errors)
			{
				writer.WriteLine(e.ToString());
			}
		}

		public void PrintWarnings(System.IO.TextWriter writer)
		{
			foreach(Warning w in Warnings)
			{
				writer.WriteLine(w.ToString());
			}
		}

		public void SetIgnoreWarning (int code)
		{
			if (warning_ignore_table == null)
				warning_ignore_table = new Hashtable ();

			warning_ignore_table [code] = true;
		}

		public int ExpectedError 
		{
			set 
			{
				expected_error = value;
			}
			get 
			{
				return expected_error;
			}
		}
	}
}
