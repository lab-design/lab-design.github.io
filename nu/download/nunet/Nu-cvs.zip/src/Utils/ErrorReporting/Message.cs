#region "Copyright(C)2005, Hridesh Rajan"
/********************************************************************************
 *                                                                              *
 * This file is part of the Nu compiler source Code.                         *
 *                                                                              *
 * The contents of this file are subject to the Mozilla Public License          *
 * Version 1.1 (the "License"); you may not use this file except in             *
 * compliance with the License. You may obtain a copy of the License at         *
 * either http://www.mozilla.org/MPL/.                                          *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License     *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * Author: Hridesh Rajan                                                        *
 * Copyright (C) 2005 Hridesh Rajan.                                       *
 * All Rights Reserved.                                                         *
 *                                                                              *
 ********************************************************************************/
# endregion


using System;
using System.Diagnostics;

namespace Nu.Utils.ErrorReporting
{
	/// <summary>
	/// Summary description for Message.
	/// </summary>
	public abstract class Message
	{
		public int Code;
		public string Text;
		public bool Fatal;
		public string Stacktrace;
		public string FileName;
		public int LineNumber;
		public int ColumnNumber;

		public static string UnknownFile = "UnknownFile";
		public static int UnknownLineNumber = - 2600056; 
		public static int UnknownColumnNumber = - 2600057; 

		public virtual string MessageKind()
		{
			return "Message";
		}
		public Message ()
		{
			this.Code = 0;
			this.Text = "";
			this.Stacktrace = "";
			this.Fatal = false;
			this.FileName = Message.UnknownFile;
			this.LineNumber = Message.UnknownLineNumber;
			this.ColumnNumber = Message.UnknownColumnNumber;
		}
		public Message (int code, string text)
		{
			this.Code = code;
			this.Text = text;
			this.Stacktrace = "";
			this.Fatal = false;
			this.FileName = Error.UnknownFile;
			this.LineNumber = Message.UnknownLineNumber;
			this.ColumnNumber = Message.UnknownColumnNumber;
		}
		public Message (int code, string text, bool Stacktrace, bool Fatal)
		{
			this.Code = code;
			this.Text = text;
			this.FileName = Error.UnknownFile;
			this.LineNumber = Message.UnknownLineNumber;
			this.ColumnNumber = Message.UnknownColumnNumber;
			if (Stacktrace)this.Stacktrace = (new StackTrace()).ToString ();
			else this.Stacktrace = "";
			this.Fatal = Fatal;
		}
		public override string ToString()
		{
			string msg = "";
			if(FileName != Message.UnknownFile)
				msg += FileName;

			if(LineNumber != Message.UnknownLineNumber)
				msg += "(" + LineNumber;

			if(ColumnNumber != Message.UnknownColumnNumber)
				msg += "," + ColumnNumber;

			msg += "):";

			if(Fatal) msg += " Fatal ";

			msg+= MessageKind() + " Nu" + String.Format("{0:0000}: {1}", Code, Text) + System.Environment.NewLine;

			msg += Stacktrace;
			
			return msg;
		}
	}
}
