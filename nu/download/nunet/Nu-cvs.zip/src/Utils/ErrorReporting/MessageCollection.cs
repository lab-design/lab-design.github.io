#region "Copyright(C)2005, Hridesh Rajan"
/********************************************************************************
 *                                                                              *
 * This file is part of the Nu compiler source Code.                         *
 *                                                                              *
 * The contents of this file are subject to the Mozilla Public License          *
 * Version 1.1 (the "License"); you may not use this file except in             *
 * compliance with the License. You may obtain a copy of the License at         *
 * either http://www.mozilla.org/MPL/.                                          *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License     *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * Author: Hridesh Rajan                                                        *
 * Copyright (C) 2005 Hridesh Rajan.                                       *
 * All Rights Reserved.                                                         *
 *                                                                              *
 ********************************************************************************/
# endregion

using System;
using System.Collections;
using System.Runtime.InteropServices;

namespace Nu.Utils.ErrorReporting
{
	/// <summary>
	/// Summary description for MessageCollection.
	/// </summary>
	[Serializable]
	[ClassInterface(ClassInterfaceType.AutoDispatch)]
	[ComVisible(true)]
	public class MessageCollection
		: CollectionBase
	{
		//
		// Constructors
		//
		public MessageCollection()
		{
		}

		public MessageCollection( Message[] value )
		{
			AddRange( value );
		}

		public MessageCollection( MessageCollection value )
		{
			AddRange( value );
		}
		
		//
		// Properties
		//
		public Message this[int index]
		{
			get 
			{
				return (Message)List[index];
			}
			set 
			{
				List[index] = value;
			}
		}

		//
		// Methods
		//
		public int Add (Message value)
		{
			return List.Add( value ); 
		}

		public void AddRange (Message [] value )
		{
			foreach ( Message elem in value )
				Add( elem );
		}
		
		public void AddRange (MessageCollection value)
		{
			foreach ( Message elem in value )
				Add( elem );
		}

		public bool Contains( Message value )
		{
			return List.Contains( value );
		}
		
		public void CopyTo( Message[] array, int index )
		{
			List.CopyTo( array, index );
		}

		public int IndexOf( Message value )
		{
			return List.IndexOf( value );
		}

		public void Insert( int index, Message value )
		{
			List.Insert( index, value );
		}

		public void Remove( Message value )
		{
			int index = IndexOf( value );
			if ( index < 0 )
				throw( new ArgumentException( "The specified object is not in the collection" ) );
			RemoveAt( index );
		}
	}
}
