using System;
using PERWAPI;

namespace Nu.Weaver.JoinPoint {
	/// <summary>
	/// 
	/// </summary>
	public abstract class JoinPoint: IJoinPoint {
		/// <summary>
		/// 
		/// </summary>
		/// <param name="location"></param>
		public JoinPoint(MetaDataElement location) {
			this.location = location;
		}

		#region IJoinPoint Members

		/// <summary>
		/// Returns the name of this joinpoint.
		/// </summary>
		public virtual string Name {
			get {
				return location.NameString();
			}
		}

		/// <summary>
		/// Stores the location of this joinpoint.
		/// </summary>
		protected MetaDataElement location;

		/// <summary>
		/// Gets the location.
		/// </summary>
		public PERWAPI.MetaDataElement Location {
			get {
				return location;
			}
		}

		public abstract void Weave();

		#endregion

		/// <summary>
		/// Counter to create unique StaticPart names.
		/// </summary>
		protected static int count = 0;

		/// <summary>
		/// Add a field of type Nu.Runtime.IStaticPart to the 
		/// parent class.
		/// </summary>
		/// <param name="parent">the parent class</param>
		/// <returns>reference to the added field</returns>
		protected FieldDef CreateStaticPart(ClassDef parent) 
		{

			// Create a field to represent the static part of the join point.
			PERWAPI.FieldDef thisJPSP = new FieldDef("thisJPSP" + count.ToString(), 
				TypeOfJPSP, parent);
			
			// make the field private, static, initonly
			thisJPSP.AddFieldAttr(FieldAttr.Private);
			thisJPSP.AddFieldAttr(FieldAttr.Static);
			thisJPSP.AddFieldAttr(FieldAttr.Initonly);

			// make sure to increment the counter for unique names
			count++;
			
			// Add the field to the parent.
			parent.AddToFieldList(thisJPSP);

			return thisJPSP;
		}
		
		/// <summary>
		/// Add initialization instructions to the class constructor
		/// for the field of type Nu.Runtime.IStaticPart in the
		/// parent class.
		/// </summary>
		/// <param name="parent">the parent class</param>
		/// <param name="thisJPSP">the field to be initialized</param>
		protected void InitStaticPart(ClassDef parent, FieldDef thisJPSP)
		{
			// Retrieve the type constructor of the parent
			MethodDef cctor = RetrieveTypeConstructor(parent);

			// Change the max stack depth of the type constructor 
			// to accomodate everything that we will put on it. 
			if (cctor.GetMaxStack() < 10)
				cctor.SetMaxStack(10);

			// Add the instructions to intialize the static part 
			// field to the type constructor

			// Retrieve the body of the type constructor
			PERWAPI.CILInstructions ctor_body = cctor.GetCodeBuffer();
			
			// We are now at the first instruction
			ctor_body.ResetInstCounter();

			// Reset the set of instructions so that we always start 
			// at the beginning of the type constructor
			if (ctor_body.InInsertMode())
				ctor_body.EndInsert();
			ctor_body.StartInsert();
			
			// Add the instructions to construct join point
			// signature.
			int SigIndex = AddSignature(cctor, ctor_body);
			
			// Load the string representation of the parent scope
			ctor_body.ldstr((parent.GetScope()).Name());

			// Load the fully qualified name of the parent
			ctor_body.ldstr(parent.NameSpace() + "." + parent.Name());
		
			ctor_body.MethInst(PERWAPI.MethodOp.call, getType);

			// Load the local variable in which signature is stored
			ctor_body.LoadLocal(SigIndex);

			// Insert the call instruction 
			ctor_body.MethInst(PERWAPI.MethodOp.call, callMakeSP);

			// Insert the store instruction to assign the return value
			// of the Nu.Runtime.Factory.MakeSP to the field
			// used to store the static part of the reflective information.
			ctor_body.FieldInst(FieldOp.stsfld, thisJPSP);
			
			ctor_body.EndInsert();
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="cctor"></param>
		/// <param name="cctor_body"></param>
		/// <returns></returns>
		protected abstract int AddSignature(MethodDef cctor, CILInstructions cctor_body);

		/// <summary>
		/// Searches the parent to find out if there is 
		/// any type constructor present. If not 
		/// constructs a new type constructors and returns 
		/// it.
		/// </summary>
		/// <param name="parent"></param>
		/// <returns></returns>
		protected MethodDef RetrieveTypeConstructor(ClassDef parent) {

			// Find if this class has any static constructors
			PERWAPI.MethodDef[] ClassConstructors = parent.GetMethods(".cctor");

			if (ClassConstructors.Length == 0) {
#if DEBUG
				System.Console.WriteLine("No Class Constructors in " + parent.Name());
#endif
				MethodDef cctor = new MethodDef(".cctor", PERWAPI.PrimitiveType.Void, new PERWAPI.Param[]{}, parent);
				
				cctor.AddMethAttribute(MethAttr.Private);
				cctor.AddMethAttribute(MethAttr.HideBySig);
				cctor.AddMethAttribute(MethAttr.SpecialName);
				cctor.AddMethAttribute(MethAttr.SpecialRTSpecialName);
				cctor.AddMethAttribute(MethAttr.Static);
				cctor.CreateCodeBuffer();
				// Retrieve the body of the type constructor
				PERWAPI.CILInstructions ctor_body = cctor.GetCodeBuffer();
				ctor_body.Inst(Op.ret);
				parent.AddMethod(cctor);
				return cctor;
			}
			else {
#if DEBUG
				System.Console.WriteLine(ClassConstructors.Length + " Class Constructors in " + parent.Name());
#endif
				return ClassConstructors[0];
			}
		}


		#region Class and Method References

		/// <summary>
		/// Returns a class reference
		/// </summary>
		/// <param name="assembly"></param>
		/// <param name="nameSpace"></param>
		/// <param name="className"></param>
		/// <returns></returns>
		protected static PERWAPI.ClassRef GetClassRef(PERWAPI.AssemblyRef assembly, String nameSpace, String className)
		{
			// attempt to get the class reference
			PERWAPI.ClassRef classRef = assembly.GetClass(nameSpace, className);
			
			// but sometimes the class doesnt exist, so then its ok to use new ClassRef
			if (classRef == null)
				classRef = new ClassRef(assembly, nameSpace, className);

			return classRef;
		}

		/// <summary>
		/// Returns a method reference
		/// </summary>
		/// <param name="classRef"></param>
		/// <param name="method"></param>
		/// <param name="returnType"></param>
		/// <param name="args"></param>
		/// <returns></returns>
		protected static PERWAPI.MethodRef GetMethodRef(PERWAPI.ClassRef classRef, String method, PERWAPI.Type returnType, PERWAPI.Type [] args)
		{
			// attempt to get the method reference
			PERWAPI.MethodRef methodRef = classRef.GetMethod(method, args);
			
			// but sometimes the method doesnt exist, so then its ok to use new MethodRef
			if (methodRef == null)
				methodRef = new MethodRef(classRef, method, returnType, args);

			return methodRef;
		}


		/// <summary>
		/// A reference to the type 'Nu.Runtime.Signature.ISignature'.
		/// Created statically to avoid duplicate TypeRef entries in the MD table.
		/// </summary>
		protected static PERWAPI.ClassRef TypeOfSig = GetClassRef(Nu.ConsoleUI.AppEntry.runTimeReference,
			"Nu.Runtime.Signature", "ISignature");

		/// <summary>
		/// A reference to the type 'Nu.Runtime.IStaticPart'.
		/// Created statically to avoid duplicate TypeRef entries in the MD table.
		/// </summary>
		protected static PERWAPI.ClassRef TypeOfJPSP = GetClassRef(Nu.ConsoleUI.AppEntry.runTimeReference,
			"Nu.Runtime", "IStaticPart");

		/// <summary>
		/// A reference to the type 'Nu.Runtime.IJoinpoint'.
		/// Created statically to avoid duplicate TypeRef entries in the MD table.
		/// </summary>
		protected static PERWAPI.ClassRef TypeOfJP = GetClassRef(Nu.ConsoleUI.AppEntry.runTimeReference,
			"Nu.Runtime", "IJoinpoint");

		/// <summary>
		/// A reference to the type 'Nu.Runtime.Factory'.
		/// Created statically to avoid duplicate TypeRef entries in the MD table.
		/// </summary>
		protected static PERWAPI.ClassRef Factory = GetClassRef(Nu.ConsoleUI.AppEntry.runTimeReference,
			"Nu.Runtime", "Factory");

		/// <summary>
		/// A reference to the type 'Nu.Runtime.Dispatcher'.
		/// Created statically to avoid duplicate TypeRef entries in the MD table.
		/// </summary>
		protected static PERWAPI.ClassRef Disp = GetClassRef(Nu.ConsoleUI.AppEntry.runTimeReference,
			"Nu.Runtime", "Dispatcher");


		/// <summary>
		/// A reference to the type 'System.Type'.
		/// Created statically to avoid duplicate TypeRef entries in the MD table.
		/// </summary>
		protected static PERWAPI.ClassRef System_Type = GetClassRef(PERWAPI.MSCorLib.mscorlib,
			"System", "Type");

		/// <summary>
		/// A reference to the type 'System.String'.
		/// Created statically to avoid duplicate TypeRef entries in the MD table.
		/// </summary>
		protected static PERWAPI.ClassRef System_String = GetClassRef(PERWAPI.MSCorLib.mscorlib,
			"System", "String");


		/// <summary>
		/// A reference to the method 'System.Type.GetType'.
		/// Created statically to avoid duplicate MethodRef entries in the MD table.
		/// </summary>
		protected static PERWAPI.MethodRef getType = GetMethodRef(System_Type, "GetType", 
			System_Type, new PERWAPI.Type[]{PERWAPI.PrimitiveType.String});

		/// <summary>
		/// A reference to the method 'Nu.Runtime.Factory.MakeSP'.
		/// Created statically to avoid duplicate MethodRef entries in the MD table.
		/// </summary>
		protected static PERWAPI.MethodRef callMakeSP = GetMethodRef(Factory, "MakeSP", 
			TypeOfJPSP, new PERWAPI.Type[]{PERWAPI.PrimitiveType.String, System_Type, TypeOfSig});

		#endregion


		//*****************Methods not used************************/
		// ****************Here to facilitate C&P *****************/
//		protected PERWAPI.FieldDef JPFactory;
//		protected bool IsJPFactoryCreated(ClassDef parent) 
//		{
//			// Find if this class already has a field called JPFactory
//			this.JPFactory = parent.GetField("JPFactory");
//			if(this.JPFactory == null) return false;
//			return true;
//		}
//		/// <summary>
//		/// Add a field of type Nu.Runtime.Factory to the 
//		/// parent class and add initialization instructions 
//		/// to the parents.
//		/// </summary>
//		/// <param name="parent">the parent class</param>
//		/// <returns>reference to the added field</returns>
//		protected FieldDef AddFieldFactory(ClassDef parent) 
//		{
//			if(IsJPFactoryCreated(parent)) return this.JPFactory;
//
//			// Create a field to represent the Join Point Factory
//			this.JPFactory = new FieldDef("JPFactory", Factory, parent);
//						
//			this.JPFactory.AddFieldAttr(FieldAttr.Private);
//			this.JPFactory.AddFieldAttr(FieldAttr.Static);
//			
//			// Add the field to the parent.
//			parent.AddToFieldList(this.JPFactory);
//
//			// Retrieve the type constructor of the parent
//			MethodDef cctor = RetrieveTypeConstructor(parent);
//
//			// Retrieve the body of the type constructor
//			PERWAPI.CILInstructions ctor_body = cctor.GetCodeBuffer();
//			
//			// Reset the set of instructions so that we always insert 
//			// at the beginning of the type constructor
//			if(!ctor_body.InInsertMode())
//				ctor_body.StartInsert();
//			else { ctor_body.EndInsert(); ctor_body.StartInsert();}
//
//			// Insert instructions equivalent to the code below:
//			// static Factory JPFactory = new Factory(File Name, System.Type.GetType(Class Name));
//			
//			ctor_body.ldstr((parent.GetScope()).Name());
//
//			ctor_body.ldstr(parent.NameSpace() + "." + parent.Name());
//
//			PERWAPI.MethodRef getType = new MethodRef(System_Type, "GetType", 
//				System_Type, new PERWAPI.Type[]{PERWAPI.PrimitiveType.String});
//
//			ctor_body.MethInst(PERWAPI.MethodOp.call, getType);
//
//			// The Factory constructor call
//			PERWAPI.MethodRef newFactory = new MethodRef(Factory, ".ctor", 
//				PERWAPI.PrimitiveType.Void, new PERWAPI.Type[]{PERWAPI.PrimitiveType.String, System_Type});
//
//			newFactory.AddCallConv(CallConv.Instance);
//
//			ctor_body.MethInst(PERWAPI.MethodOp.newobj, newFactory);
//
//			// Store the results of the constructor call
//			ctor_body.FieldInst(FieldOp.stsfld, this.JPFactory);
//
//			ctor_body.EndInsert();
//
//			return this.JPFactory;
//		}
	}
}
