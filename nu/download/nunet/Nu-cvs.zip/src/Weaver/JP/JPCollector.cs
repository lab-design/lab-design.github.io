#region "Copyright(C)2005, Hridesh Rajan"
/********************************************************************************
 *                                                                              *
 * This file is part of the Nu compiler source Code.                         *
 *                                                                              *
 * The contents of this file are subject to the Mozilla Public License          *
 * Version 1.1 (the "License"); you may not use this file except in             *
 * compliance with the License. You may obtain a copy of the License at         *
 * either http://www.mozilla.org/MPL/.                                          *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License     *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * Author: Hridesh Rajan                                                        *
 * Copyright (C) 2005 Hridesh Rajan.                                       *
 * All Rights Reserved.                                                         *
 *                                                                              *
 ********************************************************************************/
# endregion

using PERWAPI;
using Nu.Weaver;
namespace Nu.Weaver.JoinPoint {
	public class JPCollector: ILVisitor {

		JPCollection Collection;
		public JPCollector() {
			Collection = new JPCollection();
		}

		#region ILVisitor Members

		public void Accept(PEFile _asm) {
			// TODO:  Add JP.Accept implementation
		}

		public void Accept(ClassDef _class) {
			// TODO:  Add JP.Accept implementation
		}

		void ILVisitor.Accept(MethodDef _method) {
			//Collect Method Execution Join Points

			// Do not collect join points in interfaces
			//if(Parent.IsInterface)return; 
			
   		    PERWAPI.MetaDataElement elem = _method.GetParent();

			PERWAPI.Type parent = (PERWAPI.Type)elem;


			// TODO: Do not collect the invoke, begininvoke, and endinvoke
			// methods in any class that inherits from System.Delegate
			//if(parent.GetType().IsSubclassOf(System.Type.GetType("System.Delegate"))) {
			if(parent.TypeName().EndsWith("SimpleDelegate")){
#if DEBUG
				System.Console.WriteLine("Skipping the auto-generated methods invoke, begininvoke, and endinvoke in " 
					+ parent.TypeName());
#endif
				return;
			}

			//Execution Join Point
			ExecutionJP ejp = new ExecutionJP(_method);
			Collection.Add(ejp);
#if DEBUG
			System.Console.WriteLine("Collected Method Execution Join Point " + ejp.Name);
			System.Console.WriteLine("                In: " + _method.GetParent().NameString());
#endif
			///Remove it later
			ejp.Weave();
		}

		void ILVisitor.Accept(FieldDef _field) {
			// TODO:  Add JP.ILVisitor.Accept implementation
		}

		void ILVisitor.Accept(Property _property) {
			// TODO:  Add JP.ILVisitor.Accept implementation
		}

		#endregion
	}
}