using System.Collections;
namespace Nu.Weaver.JoinPoint
{
	public class JPCollection : System.Collections.Hashtable
	{
		/// <summary>
		/// This method adds a join point to the join point collection. 
		/// It assumes that multiple join points can have the same Name.
		/// This is done to support the overloading, when multiple member methods
		/// fields, constructors have the same name, but only differentiated by 
		/// their return type, or argument.
		/// </summary>
		/// <param name="joinpoint"></param>
		public void Add(IJoinPoint joinpoint)
		{
			if(Contains(joinpoint.Name))
			{
				ArrayList jpList = (ArrayList)this[joinpoint.Name];
				jpList.Add(joinpoint);
			}
			else 
			{
				ArrayList jpList = new ArrayList();
				jpList.Add(joinpoint);
				base.Add(joinpoint.Name,jpList);
			}
		}
		public void AddRange(JPCollection collection)
		{
			foreach(ArrayList jpList in collection.Values)
			{
				foreach(IJoinPoint jp in jpList)
					Add(jp);
			}
		}
		private ArrayList MergedList;
		public new IEnumerator GetEnumerator()
		{
			if(MergedList == null) 
			{
				MergedList = new ArrayList();
				IEnumerator iter = this.Values.GetEnumerator();
				while(iter.MoveNext())
				{
					MergedList.AddRange((ArrayList)iter.Current);
				}
			}
			return MergedList.GetEnumerator();
		}
		public bool Contains(string Name)
		{
			if(Name == null) return false;
			if(base.Contains(Name))return true;
			return false;
		}

		public ArrayList GetJoinpoint(string Name)
		{
			if(base.Contains(Name)) return (ArrayList)this[Name];
			return null;
		}

		/// <summary>
		///			Returns a join point collection of members which are in "this" but not in argument collection. 
		/// </summary>
		/// <param name="jpc"> Collection of Join Points to be excluded from "this".</param>
		/// <returns>(this - jpc) </returns>
		public JPCollection Exclude(JPCollection jpc)
		{
			JPCollection newJPC = new JPCollection();
			System.Collections.IEnumerator e = this.Values.GetEnumerator();
			while ( e.MoveNext() )
			{
				ArrayList jpList1 = (ArrayList)e.Current;
				ArrayList jpList2 = jpc.GetJoinpoint(((IJoinPoint)jpList1[0]).Name);
				// If the join point list is null i.e. there are no common members
				if(jpList2 == null)
				{
					IEnumerator iter = jpList1.GetEnumerator();
					while ( iter.MoveNext())
						newJPC.Add((IJoinPoint)iter.Current);
				}
				else
				{
					IEnumerator iter = jpList1.GetEnumerator();
					IEnumerator iter2 = jpList2.GetEnumerator();
					bool found = false;
					while ( iter.MoveNext())
					{
						iter2.Reset();
						found = false;
						while ( iter2.MoveNext())
						{
							if(iter.Current == iter2.Current) found = true;
						}
						if(!found)newJPC.Add((IJoinPoint)iter.Current);
					}
				}
			}
			return newJPC;
		}
		/// <summary>
		/// 		Returns a join point collection of members which are in both "this" and 
		/// 		the collection supplied as argument.
		/// </summary>
		/// <param name="jpc"></param>
		/// <returns></returns>
		public JPCollection Intersection(JPCollection jpc)
		{
			JPCollection newJPC = new JPCollection();
			if(this.Count == 0 || jpc.Count == 0)
			{
				return newJPC;
			}
			System.Collections.IEnumerator e = this.Values.GetEnumerator();
			while ( e.MoveNext() )
			{
				ArrayList jpList1 = (ArrayList)e.Current; 
				ArrayList jpList2 = jpc.GetJoinpoint(((IJoinPoint) jpList1[0]).Name);
				if(jpList2 == null)continue;

				IEnumerator iter = jpList1.GetEnumerator();
				IEnumerator iter2 = jpList2.GetEnumerator();

				bool found = false;
				while ( iter.MoveNext())
				{
					iter2.Reset();
					found = false;
					while ( iter2.MoveNext())
					{
						if(iter.Current == iter2.Current) found = true;
					}
					if(found)newJPC.Add((IJoinPoint)iter.Current);
				}
			}
			return newJPC;
		}
		/// <summary>
		/// Returns a join point collection union.
		/// </summary>
		/// <param name="jpc"></param>
		/// <returns></returns>
		public JPCollection Union(JPCollection jpc)
		{
			JPCollection newJPC = new JPCollection();
			if(this.Count == 0)
			{
				newJPC.AddRange(jpc);
				return newJPC;
			}
			else if(jpc.Count == 0)
			{
				newJPC.AddRange(this);
				return newJPC;
			}
			newJPC.AddRange(this);

			System.Collections.IEnumerator e = jpc.GetEnumerator();
			while ( e.MoveNext() )
			{
				ArrayList jpList2 = this.GetJoinpoint(((IJoinPoint)e.Current).Name);
				if(jpList2 == null)
				{
					newJPC.Add((IJoinPoint)e.Current);
					continue;
				}

				IEnumerator iter2 = jpList2.GetEnumerator();

				bool found = false;
				while ( iter2.MoveNext())
				{
					if(iter2.Current == e.Current) found = true;
				}
				if(!found)newJPC.Add((IJoinPoint)e.Current);
			}
			return newJPC;
		}
	}
}
