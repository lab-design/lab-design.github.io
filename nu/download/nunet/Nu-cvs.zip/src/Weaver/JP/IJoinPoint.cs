using System;
using PERWAPI;

namespace Nu.Weaver.JoinPoint
{
	/// <summary>
	/// A Join Point's Interface
	/// </summary>
	public interface IJoinPoint
	{
		/// <summary>
		/// The join point's name.
		/// </summary>
		string Name { get; }
		/// <summary>
		/// The location of the join point.
		/// </summary>
		MetaDataElement Location { get; }
		/// <summary>
		/// Weaves at the join point.
		/// </summary>
		void Weave();
	}
}
