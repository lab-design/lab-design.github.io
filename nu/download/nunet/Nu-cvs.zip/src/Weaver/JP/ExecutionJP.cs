using System;
using PERWAPI;

namespace Nu.Weaver.JoinPoint {
	/// <summary>
	/// this represents method execution join point
	/// constructor execution join point and static
	/// initialization join point.
	/// </summary>
	public class ExecutionJP: JoinPoint
	{
		/// <summary>
		/// 
		/// </summary>
		/// <param name="location"></param>
		public ExecutionJP(MethodDef location) : base(location)
		{
			this.method = location;
			parent = (PERWAPI.ClassDef) method.GetParent();
			name = location.Name();
		}


		/// <summary>
		/// 
		/// </summary>
		protected string name;
		/// <summary>
		/// 
		/// </summary>
		public override string Name
		{
			get {
				return name;
			}
		}


		/// <summary>
		/// 
		/// </summary>
		protected MethodDef method;
		/// <summary>
		/// 
		/// </summary>
		protected PERWAPI.ClassDef parent;

		//      TODO:
		//		void Clone()
		//		{
		//			// Store all the instructions in the method body
		//			PERWAPI.CILInstructions[] original_instructions = body.GetInstructions();
		//			// Remove the original instructions 
		//		}


		/// <summary>
		/// 
		/// </summary>
		public override void Weave() {
			
			PERWAPI.CILInstructions body = method.GetCodeBuffer();
			
			// Do not weave into interfaces or abstract methods
			// 
			if (body == null) return;
//			if ((parent.GetAttributes() & TypeAttr.Interface) == TypeAttr.Interface) return;
//			if ((method.GetMethAttributes() & MethAttr.Abstract) == MethAttr.Abstract) return;

			// Create a field to contain the static part of the join point in the parent
			FieldDef staticpart = CreateStaticPart(parent);

            // Insert the call to dispatch execution join point (Point-In-Time Model not Region-In-Time Model)
			InsertExecutionDispatch(body, method, staticpart);

            // Insert the call to dispatch return join point (Point-In-Time Model not Region-In-Time Model)
            InsertReturnDispatch(body, method, staticpart);

			// Initialize the static part in the parent
			InitStaticPart(parent, staticpart);
		}


		/// <summary>
		/// Inserts a call to Nu.Runtime.Dispatcher.DispatchBeforeJP 
		/// at the beginning of a set of instructions.
		/// </summary>
		/// <param name="body">Set of instructions</param>
		/// <param name="method"></param>
		/// <param name="staticpart"></param>
		protected void InsertExecutionDispatch(PERWAPI.CILInstructions body, PERWAPI.MethodDef method, FieldDef staticpart) {
			// Reset the set of instructions so that we always insert 
			// at the beginning of the set.
			if (body.InInsertMode())
				body.EndInsert();
			body.StartInsert();

			// Insert the instructions to construct reflective information
			// at the join point. 
			InsertReflectiveInfo(body, method, staticpart, false);
				
			body.MethInst(PERWAPI.MethodOp.call, callDispExec);

			body.EndInsert();
		}


		/// <summary>
		/// Inserts a call to Nu.Runtime.Dispatcher.DispatchAfterJP 
		/// at the end of a set of instructions.
		/// </summary>
		/// <param name="body">Set of instructions</param>
		/// <param name="method">The container method</param>
		/// <param name="staticpart"></param>
		protected void InsertReturnDispatch(PERWAPI.CILInstructions body, PERWAPI.MethodDef method, FieldDef staticpart) 
		{
			// Reset the set of instructions so that we always insert 
			// at the end of the set.
			if (body.InInsertMode())
				body.EndInsert();

			// remove the ret at the end of the body
			body.RemoveInstruction(body.NumInstructions());
			method.SetMaxStack(method.GetMaxStack() + 1);

			// Insert the instructions to construct reflective information
			// at the join point. 
			InsertReflectiveInfo(body, method, staticpart, true);

			body.MethInst(PERWAPI.MethodOp.call, callDispReturn);

			body.Inst(Op.ret);
		}

		
		/// <summary>
		/// Checks a type to see if it needs boxed.  If it needs boxed, returns the type to
		/// box to.  Otherwise it returns null.
		/// </summary>
		/// <param name="type">The type to check for boxing.</param>
		/// <returns>The type to box to, or null if the type doesnt need boxed.</returns>
		protected PERWAPI.Type GetBoxedType(PERWAPI.Type type)
		{
			/*
			 * TODO:
			 * 
			 * Other types might need boxing: Void, IntPtr, UIntPtr, TypedRef
			 */
			switch (type.TypeName().ToLower())
			{
				case "boolean":
					return PERWAPI.MSCorLib.mscorlib.GetClass("Boolean");

				case "char":
					return PERWAPI.MSCorLib.mscorlib.GetClass("Char");

				case "string":
					return PERWAPI.MSCorLib.mscorlib.GetClass("String");

				case "int8":
					return PERWAPI.MSCorLib.mscorlib.GetClass("Int8");

				case "int16":
					return PERWAPI.MSCorLib.mscorlib.GetClass("Int16");

				case "int32":
					return PERWAPI.MSCorLib.mscorlib.GetClass("Int32");

				case "int64":
					return PERWAPI.MSCorLib.mscorlib.GetClass("Int64");

				case "uint8":
					return PERWAPI.MSCorLib.mscorlib.GetClass("UInt8");

				case "uint16":
					return PERWAPI.MSCorLib.mscorlib.GetClass("UInt16");

				case "uint32":
					return PERWAPI.MSCorLib.mscorlib.GetClass("UInt32");

				case "uint64":
					return PERWAPI.MSCorLib.mscorlib.GetClass("UInt64");

				case "float32":
					return PERWAPI.MSCorLib.mscorlib.GetClass("Float32");

				case "float64":
					return PERWAPI.MSCorLib.mscorlib.GetClass("Float64");

				default:
					return null;
			}
		}


		/// <summary>
		/// Inserts instructions to construct reflective information 
		/// about a join point.
		/// Precondition: the set of instructions should be in insert mode
		/// </summary>
		/// <param name="body"></param>
		/// <param name="method"></param>
		/// <param name="staticpart"></param>
		/// <param name="isReturn"></param>
		protected void InsertReflectiveInfo(PERWAPI.CILInstructions body, PERWAPI.MethodDef method, FieldDef staticpart, bool isReturn) 
		{
			bool methodIsStatic = (method.GetMethAttributes() & PERWAPI.MethAttr.Static) == PERWAPI.MethAttr.Static;
			bool methodHasReturn = isReturn && !method.GetRetType().TypeName().ToLower().Equals("void");

			if (method.GetMaxStack() < 4)
				method.SetMaxStack(4);


			int returnIndex = 0;

			// store the return value
			if (methodHasReturn)
			{
				// make a local variable to store the return value
				PERWAPI.Local retVal = new PERWAPI.Local("retVal", method.GetRetType());
				int retIndex = method.AddLocal(retVal);
				body.StoreLocal(retIndex);
				// have the return value on the stack twice
				body.LoadLocal(retIndex);
				body.LoadLocal(retIndex);

				// make a local variable to store the boxed return value
				PERWAPI.Local returnVal = new PERWAPI.Local("returnVal", PERWAPI.MSCorLib.mscorlib.ObjectClass);
				returnIndex = method.AddLocal(returnVal);
				
				// get the type to box this type to, or null if we dont need to box
				PERWAPI.Type boxedType = GetBoxedType(method.GetRetType());

				// box the value if needed
				if (boxedType != null)
					body.TypeInst(PERWAPI.TypeOp.box, boxedType);

				// store the (boxed) return value
				body.StoreLocal(returnIndex);
			}

			PERWAPI.Param[] Parameters = method.GetParams();

			// Make a local variable to store the args
			PERWAPI.Local ArgsArray = new PERWAPI.Local(
				"argsArray", new PERWAPI.ZeroBasedArray(PERWAPI.MSCorLib.mscorlib.ObjectClass));

			// Add the local to the method
			int ArgsArrayIndex = method.AddLocal(ArgsArray);


			// Load the length of the Parameter array
			body.IntInst(PERWAPI.IntOp.ldc_i4, Parameters.Length);

			// Construct a new array of type System.Type
			body.TypeInst(PERWAPI.TypeOp.newarr, PERWAPI.MSCorLib.mscorlib.ObjectClass);

			// Store the result of the method call in the local variable.
			body.StoreLocal(ArgsArrayIndex);

			// Iterate over all the Parameters to insert it's value in the ArgsArray.
			for (int paramIndex = 0; paramIndex < Parameters.Length; paramIndex++) 
			{
				// Load the reference to the ArgsArray
				body.LoadLocal(ArgsArrayIndex);

				// Load the index to this Param in the array
				body.IntInst(PERWAPI.IntOp.ldc_i4, paramIndex);

				// Load the Parameter's value
				if (methodIsStatic)
					body.LoadArg(paramIndex);
				else
					body.LoadArg(paramIndex + 1);

				// get the type to box this type to, or null if we dont need to box
				PERWAPI.Type boxedType = GetBoxedType(Parameters[paramIndex].GetParType());

				// box the value if needed
				if (boxedType != null)
					body.TypeInst(PERWAPI.TypeOp.box, boxedType);

				// Store the value of the Parameter in the ArgsArray
				body.Inst(PERWAPI.Op.stelem_ref);
			}


			// Load the static part of the join point
			body.FieldInst(FieldOp.ldsfld, staticpart);
			
			// Load the This part of the join point
			// for static methods there is no instance
			if (methodIsStatic || method.Name().Equals(".ctor"))
				body.Inst(Op.ldnull);
			else
				body.LoadArg(0);
			
			// Load the return value of the join point
			if (methodHasReturn)
				body.LoadLocal(returnIndex);
			else
				body.Inst(Op.ldnull);

			// Load the local variable ArgsArray
			body.LoadLocal(ArgsArrayIndex);
		}


		/// <summary>
		/// 
		/// </summary>
		/// <param name="cctor"></param>
		/// <param name="cctor_body"></param>
		/// <returns></returns>
		protected override int AddSignature(MethodDef cctor, CILInstructions cctor_body) 
		{

			/* Equivalent code generated below:
			  * System.Type parentType = System.Type.GetType("parent class name")
			  */
			// First construct a local variable of the type of the parent class
			PERWAPI.Local parentType = new PERWAPI.Local(
				"parentType" + count.ToString(), System_Type);

			// Add the local to the type constructor
			int parentTypeIndex = cctor.AddLocal(parentType);

			// Load the string representation of the method's parent name
			cctor_body.ldstr(parent.NameSpace() + "." + parent.Name());

			// Insert the method call instruction
			cctor_body.MethInst(PERWAPI.MethodOp.call, getType);

			// Store the result of the method call in the local variable.
			cctor_body.StoreLocal(parentTypeIndex);

			/* Equivalent code generated below:
			 * System.Type[] ArgTypeArray = new System.Type[1] {
			 *            System.Type.GetType("System.String")};
			 * System.String[] ArgNameArray = new string[1]{"arg name", ..};
			 */

			// First construct a local variable of type System.Type[]
			// and System.String[]
			PERWAPI.Local ArgTypeArray = new PERWAPI.Local(
				"argTypeArray" + count.ToString(), 
				new PERWAPI.ZeroBasedArray(System_Type));

			PERWAPI.Local ArgNameArray = new PERWAPI.Local(
				"argNameArray" + count.ToString(), 
				new PERWAPI.ZeroBasedArray(PERWAPI.PrimitiveType.String));

			// Add the locals to the type constructor
			int ArgTypeArrayIndex = cctor.AddLocal(ArgTypeArray);
			int ArgNameArrayIndex = cctor.AddLocal(ArgNameArray);

			PERWAPI.Param[] Parameters = method.GetParams();

			// Load the length of the Parameter array
			cctor_body.IntInst(PERWAPI.IntOp.ldc_i4, Parameters.Length);

			// Construct a new array of type System.Type
			cctor_body.TypeInst(PERWAPI.TypeOp.newarr, System_Type);

			// Store the result of the method call in the local variable.
			cctor_body.StoreLocal(ArgTypeArrayIndex);

			// Load the length of the Parameter array
			cctor_body.IntInst(PERWAPI.IntOp.ldc_i4, Parameters.Length);

			// Construct a new array of type System.String
			cctor_body.TypeInst(PERWAPI.TypeOp.newarr, System_String);

			// Store the result of the method call in the local variable.
			cctor_body.StoreLocal(ArgNameArrayIndex);

			// Iterate over all the Parameters to insert it's type in the 
			// ArgTypeArray and it's name in ArgNameArray at the appropriate
			// index.
			for(int paramIndex=0; paramIndex < Parameters.Length; paramIndex++) {

				// Load the reference to the ArgTypeArray
				cctor_body.LoadLocal(ArgTypeArrayIndex);

				// Load the index to this Param in the array
				cctor_body.IntInst(PERWAPI.IntOp.ldc_i4, paramIndex);

				// Load the string representation of the Parameter's type
				cctor_body.ldstr((Parameters[paramIndex].GetParType()).TypeName());

				// Insert the method call System.GetType to find it's type 
				cctor_body.MethInst(PERWAPI.MethodOp.call, getType);

				// Store the type of the Parameter in the ArgTypeArray
				cctor_body.Inst(PERWAPI.Op.stelem_ref);

				// Load the reference to the ArgNameArray
				cctor_body.LoadLocal(ArgNameArrayIndex);

				// Load the index to this Param in the array
				cctor_body.IntInst(PERWAPI.IntOp.ldc_i4, paramIndex);

				// Load the string representation of the Parameter's name
				cctor_body.ldstr(Parameters[paramIndex].GetName()); 

				// Store the name of the Parameter in the ArgNameArray
				cctor_body.Inst(PERWAPI.Op.stelem_ref);
			}


			/* Equivalent code generated below:
			 * System.Type ReturnType = System.Type.GetType("System.String"));
			 */
			PERWAPI.Local ReturnType = new PERWAPI.Local(
				"returnType" + count.ToString(), 
				System_Type);

			// Add the local to the type constructor
			int ReturnTypeIndex = cctor.AddLocal(ReturnType);

			// Load the string representation of the method's return type
			cctor_body.ldstr((method.GetRetType()).TypeName());

			// Insert the method call System.GetType 
			cctor_body.MethInst(PERWAPI.MethodOp.call, getType);

			// Store the result of the method call in the local variable.
			cctor_body.StoreLocal(ReturnTypeIndex);

			/* Equivalent code generated below:
			 * Nu.Runtime.ISignature MSig = JPFactory.MakeMSig(
			 * "modifiers", "method name", parentType, ArgTypeArray, 
			 * ArgNameArray, ReturnType);
			 */

			PERWAPI.Local MSig = new PERWAPI.Local(
				"MSig" + count.ToString(), TypeOfSig);

			// Add the local to the type constructor
			int MSigIndex = cctor.AddLocal(MSig);

			// Load the JPFactory Field
			//cctor_body.FieldInst(FieldOp.ldsfld, this.JPFactory);

			// Load the string representation of the join point visibility
			// public/private/ etc. 
			cctor_body.ldstr((this.method.GetMethAttributes()).ToString());
			
			// Load the string representation of the method name
			cctor_body.ldstr(this.method.Name());

			// Load the local variable parentType
			cctor_body.LoadLocal(parentTypeIndex);

			// Load the local variable ArgTypeArray
			cctor_body.LoadLocal(ArgTypeArrayIndex);

			// Load the local variable ArgNameArray
			cctor_body.LoadLocal(ArgNameArrayIndex);

			// Load the local variable ReturnType
			cctor_body.LoadLocal(ReturnTypeIndex);
			
			// Now since all the arguments are loaded
			// make the method call

			cctor_body.MethInst(PERWAPI.MethodOp.call, MakeMSig);

			// Store the result of the method call in the local variable.
			cctor_body.StoreLocal(MSigIndex);

			// Return the index of the local variable
			return MSigIndex;

		}


		/// <summary>
		/// Make a reference to the dispatch execution to call.
		/// </summary>
//		protected static PERWAPI.MethodRef callDispExec = new MethodRef(Disp, "DispatchExecutionJP",
//			PERWAPI.PrimitiveType.Void, new PERWAPI.Type[]{TypeOfJP});
		protected static PERWAPI.MethodRef callDispExec = new MethodRef(Disp, "DispatchExecutionJP",
			PERWAPI.PrimitiveType.Void, new PERWAPI.Type[]{TypeOfJPSP,
															  PERWAPI.MSCorLib.mscorlib.ObjectClass,
															  PERWAPI.MSCorLib.mscorlib.ObjectClass,
															  new PERWAPI.ZeroBasedArray(PERWAPI.MSCorLib.mscorlib.ObjectClass)});

		/// <summary>
		/// Make a reference to the dispatch return to call.
		/// </summary>
//		protected static PERWAPI.MethodRef callDispReturn = new MethodRef(Disp, "DispatchReturnJP",
//			PERWAPI.PrimitiveType.Void, new PERWAPI.Type[]{TypeOfJP});
		protected static PERWAPI.MethodRef callDispReturn = new MethodRef(Disp, "DispatchReturnJP",
			PERWAPI.PrimitiveType.Void, new PERWAPI.Type[]{TypeOfJPSP,
															  PERWAPI.MSCorLib.mscorlib.ObjectClass,
															  PERWAPI.MSCorLib.mscorlib.ObjectClass,
															  new PERWAPI.ZeroBasedArray(PERWAPI.MSCorLib.mscorlib.ObjectClass)});

		// Make the reference to the method MakeJP to call it.
//		protected static PERWAPI.MethodRef callMakeJP = new MethodRef(Factory, "MakeJP", 
//			TypeOfJP, new PERWAPI.Type[]{TypeOfJPSP});

		/// <summary>
		/// Make the reference to the method MakeJP to call it.
		/// </summary>
//		protected static PERWAPI.MethodRef callMakeJP = new MethodRef(Factory, "MakeJP", 
//			TypeOfJP, new PERWAPI.Type[]{TypeOfJPSP, PERWAPI.MSCorLib.mscorlib.ObjectClass, PERWAPI.MSCorLib.mscorlib.ObjectClass, 
//											PERWAPI.MSCorLib.mscorlib.ObjectClass, new PERWAPI.ZeroBasedArray(PERWAPI.MSCorLib.mscorlib.ObjectClass)});

		/// <summary>
		/// Make a reference to the JPFactory.MakeMSig method to call
		/// </summary>
		protected static PERWAPI.MethodRef MakeMSig = new MethodRef(Factory, 
			"MakeMSig", TypeOfSig, 
			new PERWAPI.Type[]{PERWAPI.PrimitiveType.String,
								  PERWAPI.PrimitiveType.String, System_Type, 
								  new PERWAPI.ZeroBasedArray(System_Type),
								  new PERWAPI.ZeroBasedArray(PERWAPI.PrimitiveType.String),
								  System_Type});
	}
}
