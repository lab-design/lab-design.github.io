#region "Copyright(C)2005, Hridesh Rajan"
/********************************************************************************
 *                                                                              *
 * This file is part of the Nu compiler source Code.                         *
 *                                                                              *
 * The contents of this file are subject to the Mozilla Public License          *
 * Version 1.1 (the "License"); you may not use this file except in             *
 * compliance with the License. You may obtain a copy of the License at         *
 * either http://www.mozilla.org/MPL/.                                          *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License     *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * Author: Hridesh Rajan                                                        *
 * Copyright (C) 2005 Hridesh Rajan.                                       *
 * All Rights Reserved.                                                         *
 *                                                                              *
 ********************************************************************************/
# endregion

using PERWAPI;
namespace Nu.Weaver.Binding {
	public class BindingCollector: Nu.Weaver.ILVisitor{
        BindingCollection Collection = new BindingCollection();

		#region ILVisitor Members

		public void Accept(PEFile _asm) {}

		void Nu.Weaver.ILVisitor.Accept(ClassDef _class) {}

		void Nu.Weaver.ILVisitor.Accept(MethodDef _method) {}

		void Nu.Weaver.ILVisitor.Accept(FieldDef _field) {

			Type _fieldType = _field.GetFieldType();

			if(_fieldType.TypeName().StartsWith("Nu.Runtime.Binding.")) {

				Collection.Add(_field);

#if DEBUG
				System.Console.WriteLine("Collected Binding " + _fieldType.TypeName() + ":" + _field.Name());
				System.Console.WriteLine("                In: " + _field.GetParent().NameString());
#endif

			}
		}

		void Nu.Weaver.ILVisitor.Accept(Property _property){}

		#endregion
	}
}