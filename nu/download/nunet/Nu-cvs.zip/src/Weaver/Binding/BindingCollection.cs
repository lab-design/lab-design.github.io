using System.Collections;
using PERWAPI;
namespace Nu.Weaver.Binding
{
	public class BindingCollection : System.Collections.Hashtable
	{
		/// <summary>
		/// Store a field representing a binding in the collection.
		/// </summary>
		/// <param name="_field">The Binding</param>
		public void Add(PERWAPI.FieldDef _field) {
			this.Add(UniqueName(_field), _field);
		}

		private string UniqueName(PERWAPI.FieldDef _field){
			return _field.GetParent().NameString() + "-" + _field.GetFieldType().TypeName() + "-" + _field.Name();
		}
	}
}
