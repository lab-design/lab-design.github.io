#region "Copyright(C)2005, Hridesh Rajan"
/********************************************************************************
 *                                                                              *
 * This file is part of the Nu compiler source Code.                         *
 *                                                                              *
 * The contents of this file are subject to the Mozilla Public License          *
 * Version 1.1 (the "License"); you may not use this file except in             *
 * compliance with the License. You may obtain a copy of the License at         *
 * either http://www.mozilla.org/MPL/.                                          *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License     *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * Author: Hridesh Rajan                                                        *
 * Copyright (C) 2005 Hridesh Rajan.                                       *
 * All Rights Reserved.                                                         *
 *                                                                              *
 ********************************************************************************/
# endregion


using System;

namespace Nu
{
	/// <summary>
	/// A Global class that accumulates compiler wide information.
	/// 
	/// WARNING: Be careful while putting things here. 
	/// ADVISE: Try to remove things if they are not needed here.
	/// </summary>
	public class Environment
	{
		/// <summary>
		/// The exit point of the compiler. Even Main routine calls this to exit.
		/// </summary>
		/// <param name="code"></param>
		public static void Exit(int code)
		{
			System.Environment.Exit(code);
		}

		/// <summary>
		/// Prints the copyright blurb on the command line
		/// </summary>
		static void printinfo()
		{
			Console.WriteLine("Nu Compiler Version " + Nu.Environment.VersionInfo()+ 
				System.Environment.NewLine + "Copyright (C) 2005-2006 Hridesh Rajan." +
				System.Environment.NewLine + "All rights reserved." + System.Environment.NewLine );
		}
		private static void PrintWarningsErrors()
		{
			Environment.Report.PrintErrors(System.Console.Error);
			Environment.Report.PrintWarnings(System.Console.Error);
		}

		public static Nu.Utils.ErrorReporting.Report Report = new Nu.Utils.ErrorReporting.Report();


		/// <summary>
		/// Version number of the compiler. Used in a crosscutting way :)
		/// </summary>
		/// <returns></returns>
		public static string VersionInfo()
		{
			return "0.3";
		}
	}
}
