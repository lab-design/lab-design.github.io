#region "Copyright(C)2005, Hridesh Rajan"
/********************************************************************************
 *                                                                              *
 * This file is part of the Nu compiler source Code.                         *
 *                                                                              *
 * The contents of this file are subject to the Mozilla Public License          *
 * Version 1.1 (the "License"); you may not use this file except in             *
 * compliance with the License. You may obtain a copy of the License at         *
 * either http://www.mozilla.org/MPL/.                                          *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License     *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * Author: Hridesh Rajan                                                        *
 * Copyright (C) 2005 Hridesh Rajan.                                       *
 * All Rights Reserved.                                                         *
 *                                                                              *
 ********************************************************************************/
# endregion

using System;

namespace Nu.Runtime
{
	/// <summary>
	/// The static part of the reflective information at the join point.
	/// </summary>
	public class StaticPart: IStaticPart
	{		
		/// <summary>
		/// 
		/// </summary>
		/// <param name="_Signature"></param>
		/// <param name="SourceLocation"></param>
		internal StaticPart(Signature.ISignature _Signature, ISourceLocation SourceLocation)
		{
			this._Signature = _Signature;
			this._Location = SourceLocation;
		}
		#region IStaticPart Members

		internal Signature.ISignature _Signature;
		/// <summary>
		/// The signature of the join point.
		/// </summary>
		public Nu.Runtime.Signature.ISignature Signature
		{
			get
			{
				return _Signature;
			}
		}
		internal ISourceLocation _Location;
		/// <summary>
		/// The source location of the join point.
		/// </summary>
		public ISourceLocation Location
		{
			get
			{
				return _Location;
			}
		}
		
		#endregion

		/// <summary>
		/// Creates a string representation of the static part of the reflective information
		/// at the join point.
		/// </summary>
		/// <returns>String representation of the static part.</returns>
		public override string ToString()
		{
//			if(_Signature != null)
				return _Signature.ToString();
		}
	}
}
