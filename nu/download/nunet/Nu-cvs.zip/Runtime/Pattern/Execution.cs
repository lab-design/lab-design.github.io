using System;
using Nu.Runtime.Pattern;

namespace Nu.Runtime.Pattern {
	/// <summary>
	/// 
	/// An execution Pattern selects each method execution 
	/// join point whose signature matches Method.
	/// 
	/// </summary>
	public class Execution:IPattern {
		
		public Execution(Method pattern) {
			if (pattern == null) throw new System.ArgumentNullException("pattern");
			this.pattern = pattern;
		}

		public bool Match(Nu.Runtime.IJoinpoint thisJP){
			if (thisJP._Kind != JPKind.Execution) return false;
			return pattern.Match(thisJP);
		}

		Method pattern;
	}
}
