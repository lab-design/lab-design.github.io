using System;

namespace Nu.Runtime.Pattern
{
	/// <summary>
	/// 
	/// </summary>
	public class Args : IPattern
	{
		public Args(System.Type[] argType)
		{
			this.argType = argType;
		}

		public bool Match(Nu.Runtime.IJoinpoint thisJP)
		{
			if (thisJP.Args.Length != argType.Length)
				return false;
			
			for (int i = 0; i < argType.Length; i++)
				if (!argType[i].IsInstanceOfType(thisJP.Args[i]))
					return false;
			
			return true;
		}

		System.Type[] argType;
	}
}
