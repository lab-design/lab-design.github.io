using System;
using Nu.Runtime.Pattern;

namespace Nu.Runtime.Pattern {
	/// <summary>
	/// 
	/// A return Pattern selects each method return 
	/// join point whose signature matches Method.
	/// 
	/// </summary>
	public class Return:IPattern {
		
		public Return(Method pattern) {
			if (pattern == null) throw new System.ArgumentNullException("pattern");
			this.pattern = pattern;
		}

		public bool Match(Nu.Runtime.IJoinpoint thisJP){
			if (thisJP._Kind != JPKind.Return) return false;
			return pattern.Match(thisJP);
		}

		Method pattern;
	}
}
