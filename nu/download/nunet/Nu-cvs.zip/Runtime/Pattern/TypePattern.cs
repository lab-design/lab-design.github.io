using System;

namespace Nu.Runtime.Pattern
{
	/// <summary>
	/// </summary>
	/// 
	public class TypePattern 
	{
	}
}
