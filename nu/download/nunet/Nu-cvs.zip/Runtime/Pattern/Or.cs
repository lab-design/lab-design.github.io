using System;

namespace Nu.Runtime.Pattern
{
	/// <summary>
	/// An "Or" operator composes two Patterns 
	/// such that a join point is matched if it 
	/// is matched by either Patterns.
	/// </summary>
	public class Or : IPattern {
		public Or(IPattern op1, IPattern op2)
		{
			if (op1 == null) throw new System.ArgumentNullException("op1");
			if (op2 == null) throw new System.ArgumentNullException("op2");
			this.op1 = op1;
			this.op2 = op2;
		}

		public bool Match(Nu.Runtime.IJoinpoint thisJP)
		{
			if (op1.Match(thisJP))
				return true;
			
			return op2.Match(thisJP);
		}
		
		internal IPattern op1, op2;
	}
}

