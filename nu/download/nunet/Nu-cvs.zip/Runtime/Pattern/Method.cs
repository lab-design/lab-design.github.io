using System;

namespace Nu.Runtime.Pattern
{
	/// <summary>
	/// The Method class provides a statically typed approach to
	/// represent patterns to be matched with method signatures. It
	/// provides different constructors to represent different types 
	/// of patterns. 
	/// </summary>
	public class Method
	{
		/// <summary>
		/// The only purpose of this class is to provide a type to represent 
		/// any return type
		/// </summary>
		public class Any 
		{
		}

		/// <summary>
		/// The modifiers to match with the method signatures.
		/// </summary>
		protected Nu.Runtime.Pattern.Modifiers modifiers;
		/// <summary>
		/// The return type to match with the method signatures.
		/// </summary>
		protected System.Type returnType;
		/// <summary>
		/// The compiled regular expression to match with the method signatures.
		/// </summary>
		protected System.Text.RegularExpressions.Regex regex;

		/// <summary>
		/// Default constructor for the Method class.
		/// This constructor should be used when matching is based only on names
		/// For example, to match to a method signature * * Bit.Get(), where you
		/// want to match all modifiers, all return types, and all arguments, you
		/// will construct a method pattern new Method("Bit.Get").
		/// </summary>
		/// <param name="name">The regular expression to match with the method signatures.</param>
		public Method(string name) : this(Modifiers.Any, typeof(Any), name) {
		}

		/// <summary>
		/// This constructor should be used when matching based only on modifiers and
		/// name is to be used. For example, to match to a method signature public *
		/// Bit.Get(), where you want to match only public method called Get of the class
		/// Bit, but do not care about the return type of the method or the argument or the
		/// method, you will construct a method pattern new Method(Modifiers.Public,
		/// "Bit.Get"). The method pattern created using this constructor will 
		/// match all return types, and all arguments.
		/// </summary>
		/// <param name="modifiers">The modifiers to match with the method signatures.</param>
		/// <param name="name">The regular expression to match with the method signatures.</param>
		public Method(Nu.Runtime.Pattern.Modifiers modifiers, string name) : this(modifiers, typeof(Any), name) {
		}

		/// <summary>
		/// This constructor should be used when matching based on modifiers, return type 
		/// and name is to be used. For example, to match to a method signature public void
		/// Bit.Get(), where you want to match only public method called Get of the class
		/// Bit that returns void, but you do not care about the arguments of the method 
		/// you will construct a method pattern new Method(Modifiers.Public,
		/// typeof(void), "Bit.Get"). The method pattern created using this constructor will
		/// match all arguments.
		/// </summary>
		/// <param name="modifiers">The modifiers to match with the method signatures.</param>
		/// <param name="returnType">The return type to match with the method signatures.</param>
		/// <param name="name">The regular expression to match with the method signatures.</param>
		public Method(Nu.Runtime.Pattern.Modifiers modifiers, 
			System.Type returnType, string name) {

			// Use System.Text.RegularExpressions to parse and store a representation
			// of this regular expression "regex" so that for each join point dispatch
			// parsing is fast.

			// TODO: normalize the regular expression? Add anchoring to the end of the
			// string? Auto-escape periods?  "Bit.Set" should really be "Bit\\.Set$"?
			this.regex = new System.Text.RegularExpressions.Regex(name);
			this.modifiers = modifiers;
			this.returnType = returnType;
		}
		
		/// <summary>
		/// Attempts to match the joinpoint's method signature.
		/// </summary>
		/// <param name="thisJP">The joinpoint to match against.</param>
		/// <returns>True if the method signature matches.</returns>
		public bool Match(Nu.Runtime.IJoinpoint thisJP){
			// TODO: Check to see if all this information is exposed
			// at the execution and return join points

			// First check whether the modifier is don't care 
			// if not check if the modifiers match with the signature
			// if not return false
			// TODO: need to convert the comma delimited string into a bit set of Modifiers
//			if (modifiers != Modifiers.Any)
//				if (((new ModifierBitSet(thisJP.Signature.Modifiers)) & modifiers) != modifiers)
//					return false;

			// Second check whether the return type is don't care
			// if not check if the return type matches with the signature
			// if not return false
			if (returnType != typeof(Any))
				if (returnType != ((Nu.Runtime.Signature.IMethodSignature)thisJP.Signature).ReturnType)
					return false;

			// Third check whether the stored regular expression matches
			// the signature of the join point.
			if (!regex.IsMatch(thisJP.Signature.Name))
				return false;

			// Fourth check whether the argument is don't care 
			// if not check if the argument signature matches
			// if not return false
			// TODO: isnt this check already covered with the addition of an Args pattern?
			
			return true;
		}
	}
}

