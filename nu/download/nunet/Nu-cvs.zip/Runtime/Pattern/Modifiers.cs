using System;

namespace Nu.Runtime.Pattern
{
	/// <summary>
	/// Attibutes for a class
	/// </summary>
	[FlagsAttribute]
	public enum Modifiers {Private, Public, NestedPublic, NestedPrivate, 
		NestedFamily, NestedAssembly, NestedFamAndAssem, NestedFamOrAssem, 
		SequentialLayout, ExplicitLayout = 0x10, Interface = 0x20, 
		Abstract = 0x80, PublicAbstract = 0x81, Sealed = 0x100, 
		PublicSealed = 0x101, SpecialName = 0x400, RTSpecialName = 0x800, 
		Import = 0x1000, Serializable = 0x2000, UnicodeClass = 0x10000,
		AutoClass = 0x20000, BeforeFieldInit = 0x100000, Default,  
		FamAndAssem, Assembly, Family, FamOrAssem, Static = 0x0010, 
		PublicStatic = 0x16, Final = 0x0020, PublicStaticFinal = 0x36, 
		Virtual = 0x0040, PrivateVirtual, PublicVirtual = 0x0046, 
		HideBySig = 0x0080, NewSlot = 0x0100, SpecialRTSpecialName = 0x1800,
        RequireSecObject = 0x8000, Any}
}
