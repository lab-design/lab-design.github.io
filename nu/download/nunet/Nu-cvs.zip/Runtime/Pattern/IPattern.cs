using System;

namespace Nu.Runtime.Pattern
{
	/// <summary>
	/// IPattern is an interface for every pattern in the
	/// "Nu" model. The bind and remove primitives expect 
	/// a reference to an object that implements this 
	/// interface.
	/// 
	/// The patterns are of two types: basic and composite.
	/// Basic patterns are fundamental building blocks of
	/// this pattern language. An example of basic patterns is 
	/// <see cref="Nu.Runtime.Pattern.Method">Method</see>.
	/// The composite patterns are formed by qualifying or 
	/// composing basic patterns. For example, a
	/// <see cref="Nu.Runtime.Pattern.Method">Method</see> 
	/// can be qualified with an 
	/// <see cref="Nu.Runtime.Pattern.Execution">Execution</see>
	/// and composed with other patterns using  <see cref="Nu.Runtime.Pattern.And">And</see>, 
	/// <see cref="Nu.Runtime.Pattern.Or">Or</see>, and negated using the 
	/// <see cref="Nu.Runtime.Pattern.Not">Not</see>.
	/// </summary>
	public interface IPattern {
		bool Match(Nu.Runtime.IJoinpoint thisJP);
	}
}
