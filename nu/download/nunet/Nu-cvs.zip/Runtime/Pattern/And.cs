using System;

namespace Nu.Runtime.Pattern
{
	/// <summary>
	/// The operator "And" is used to form composite
	/// patterns. This operator composes two patterns
	/// such that a join point is matched only when
	/// it is matched by both patterns.
	/// </summary>
	public class And :IPattern {
		public And(IPattern op1, IPattern op2)
		{
			if (op1 == null) throw new System.ArgumentNullException("op1");
			if (op2 == null) throw new System.ArgumentNullException("op2");
			this.op1 = op1;
			this.op2 = op2;
		}

		public bool Match(Nu.Runtime.IJoinpoint thisJP)
		{
			if (op1.Match(thisJP))
				return op2.Match(thisJP);
			
			return false;
		}
		
		internal IPattern op1, op2;
	}
}

