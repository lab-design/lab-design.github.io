using System;

namespace Nu.Runtime.Pattern
{
	/// <summary>
	/// A "Not" operator negates a Pattern 
	/// such that a join point is matched only when
	/// it is not matched by the operand Pattern.
	/// </summary>
	public class Not :IPattern {
		public Not(IPattern op)
		{
			if (op == null) throw new System.ArgumentNullException("op");
			this.op = op;
		}

		public bool Match(Nu.Runtime.IJoinpoint thisJP)
		{
			return !op.Match(thisJP);
		}

		internal IPattern op;
	}
}

