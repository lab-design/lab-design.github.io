using System;

namespace Nu.Runtime.Pattern
{
	/// <summary>
	/// A "This" Pattern matches every join point 
	/// when the currently executing object is an 
	/// instance of Type or Id's type. 
	/// </summary>
	public class This :IPattern {
		public This(System.Type type)
		{
			if(type == null) throw new System.ArgumentNullException("type");
			this.type = type;
			this.isType = true;
		}

		public This(object instance)
		{
			if(instance == null) throw new System.ArgumentNullException("instance");
			this.instance = instance;
			this.isType = false;
		}

		public bool Match(Nu.Runtime.IJoinpoint thisJP)
		{
			if(thisJP.This != null)
			{
			 if (this.isType) 
				 return thisJP.This.GetType().Equals(this.type);
			 else return thisJP.This.GetType().Equals(this.instance);
			}
			return false;
		}

		System.Type type;
		object instance;
		bool isType;
	}
}

