using System;
using Nu.Runtime.Pattern;

namespace Nu.Runtime.Pattern {
	/// <summary>
	/// 
	/// A NewExecutionPattern selects each constructor execution 
	/// join point whose signature matches Method.
	/// 
	/// </summary>
	public class StaticInitialization:IPattern {
		
		public StaticInitialization(Method pattern) {
			if (pattern == null) throw new System.ArgumentNullException("pattern");
			this.pattern = pattern;
		}

		public bool Match(Nu.Runtime.IJoinpoint thisJP){
			if (thisJP._Kind != JPKind.Unknown) return false;
			return pattern.Match(thisJP);
		}

		Method pattern;
	}
}
