#region "Copyright(C)2005, Hridesh Rajan"
/********************************************************************************
 *                                                                              *
 * This file is part of the Nu compiler source Code.                         *
 *                                                                              *
 * The contents of this file are subject to the Mozilla Public License          *
 * Version 1.1 (the "License"); you may not use this file except in             *
 * compliance with the License. You may obtain a copy of the License at         *
 * either http://www.mozilla.org/MPL/.                                          *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License     *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * Author: Hridesh Rajan                                                        *
 * Copyright (C) 2005 Hridesh Rajan.                                       *
 * All Rights Reserved.                                                         *
 *                                                                              *
 ********************************************************************************/
# endregion

namespace Nu.Runtime
{
	/// <summary>
	/// 
	/// </summary>
    public class Dispatcher
    {
		/// <summary>
		/// 
		/// </summary>
		/// <param name="pattern"></param>
		/// <param name="del"></param>
		public static void Bind(Nu.Runtime.Pattern.IPattern pattern, Nu.Runtime.Delegate.SimpleDelegate del)
		{
			Bind(pattern, (System.Delegate)del);
		}


		/// <summary>
		/// 
		/// </summary>
		/// <param name="pattern"></param>
		/// <param name="del"></param>
		public static void Bind(Nu.Runtime.Pattern.IPattern pattern, Nu.Runtime.Delegate.JPDelegate del)
		{
			Bind(pattern, (System.Delegate)del);
		}


		private static void Bind(Nu.Runtime.Pattern.IPattern pattern, System.Delegate del)
		{
#if DEBUG
            System.Console.WriteLine("Dispatch: Bind poincut");
#endif

			// if the pattern contains an execution join point, add it to the execution collection
			if (PatternContainsJP(typeof(Nu.Runtime.Pattern.Execution), pattern))
				ExecutionPatternDelegatePairs.Add(new PatternDelegatePair(pattern, del));

			// if the pattern contains a return join point, add it to the return collection
			if (PatternContainsJP(typeof(Nu.Runtime.Pattern.Return), pattern))
				ReturnPatternDelegatePairs.Add(new PatternDelegatePair(pattern, del));
		}


		/// <summary>
		/// 
		/// </summary>
		/// <param name="pattern"></param>
		/// <param name="del"></param>
		public static void Remove(Nu.Runtime.Pattern.IPattern pattern, Nu.Runtime.Delegate.SimpleDelegate del)
		{
			Remove(pattern, (System.Delegate)del);
		}


		/// <summary>
		/// 
		/// </summary>
		/// <param name="pattern"></param>
		/// <param name="del"></param>
		public static void Remove(Nu.Runtime.Pattern.IPattern pattern, Nu.Runtime.Delegate.JPDelegate del)
		{
			Remove(pattern, (System.Delegate)del);
		}


		private static void Remove(Nu.Runtime.Pattern.IPattern pattern, System.Delegate del)
        {
#if DEBUG
            System.Console.WriteLine("Dispatch: Remove poincut");
#endif

			// if the pattern contains an execution join point, remove it from the execution collection
			if (PatternContainsJP(typeof(Nu.Runtime.Pattern.Execution), pattern))
				ExecutionPatternDelegatePairs.Remove(new PatternDelegatePair(pattern, del));

			// if the pattern contains a return join point, remove it from the return collection
			if (PatternContainsJP(typeof(Nu.Runtime.Pattern.Return), pattern))
				ReturnPatternDelegatePairs.Remove(new PatternDelegatePair(pattern, del));
		}


        private static System.Collections.ArrayList ExecutionPatternDelegatePairs = new System.Collections.ArrayList();
        private static System.Collections.ArrayList ReturnPatternDelegatePairs = new System.Collections.ArrayList();


		private static bool PatternContainsJP(System.Type jpType, Nu.Runtime.Pattern.IPattern pattern)
		{
			if (pattern.GetType().Equals(jpType))
				return true;
			else if (pattern is Nu.Runtime.Pattern.And)
				return PatternContainsJP(jpType, ((Nu.Runtime.Pattern.And)pattern).op1) || PatternContainsJP(jpType, ((Nu.Runtime.Pattern.And)pattern).op2);
			else if (pattern is Nu.Runtime.Pattern.Or)
				return PatternContainsJP(jpType, ((Nu.Runtime.Pattern.Or)pattern).op1) || PatternContainsJP(jpType, ((Nu.Runtime.Pattern.Or)pattern).op2);
			else if (pattern is Nu.Runtime.Pattern.Not)
				return !PatternContainsJP(jpType, ((Nu.Runtime.Pattern.Not)pattern).op);
			else
				return false;
		}


        internal class PatternDelegatePair
        {
            internal PatternDelegatePair(Nu.Runtime.Pattern.IPattern pattern, System.Delegate del)
            {
                this.pattern = pattern;
                this.del = del;
            }

            internal Nu.Runtime.Pattern.IPattern pattern;
            internal System.Delegate del;
        }


		/// <summary>
		/// 
		/// </summary>
		/// <param name="staticPart"></param>
		/// <param name="_this"></param>
		/// <param name="returnVal"></param>
		/// <param name="args"></param>
        public static void DispatchExecutionJP(Nu.Runtime.IStaticPart staticPart, object _this, object returnVal, object[] args)
        {
			IJoinpoint thisJP = Factory.MakeJP(staticPart, _this, JPKind.Execution, returnVal, args);

#if DEBUG
            System.Console.WriteLine("Dispatch: execution JP -- " + thisJP.ToString());
#endif

			foreach (PatternDelegatePair P in ExecutionPatternDelegatePairs)
            {
				((Joinpoint)thisJP).SetTarget(P.del.Target);

				if (P.pattern.Match(thisJP))
				{
					if (P.del.GetType().Name.Equals("JPDelegate"))
						P.del.DynamicInvoke(new object[] { thisJP });
					else
						P.del.DynamicInvoke(new object[] { });
				}
			}
		}


		/// <summary>
		/// 
		/// </summary>
		/// <param name="staticPart"></param>
		/// <param name="_this"></param>
		/// <param name="returnVal"></param>
		/// <param name="args"></param>
        public static void DispatchReturnJP(Nu.Runtime.IStaticPart staticPart, object _this, object returnVal, object[] args)
		{
			IJoinpoint thisJP = Factory.MakeJP(staticPart, _this, JPKind.Return, returnVal, args);

#if DEBUG
			System.Console.WriteLine("Dispatch: return JP -- " + thisJP.ToString());
#endif

			foreach (PatternDelegatePair P in ReturnPatternDelegatePairs)
            {
				((Joinpoint)thisJP).SetTarget(P.del.Target);

				if (P.pattern.Match(thisJP))
				{
					if (P.del.GetType().Name.Equals("JPDelegate"))
						P.del.DynamicInvoke(new object[] { thisJP });
					else
						P.del.DynamicInvoke(new object[] { });
				}
			}
		}
    }
}