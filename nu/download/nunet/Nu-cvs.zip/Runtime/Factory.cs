#region "Copyright(C)2005, Hridesh Rajan"
/********************************************************************************
 *                                                                              *
 * This file is part of the Nu compiler source Code.                         *
 *                                                                              *
 * The contents of this file are subject to the Mozilla Public License          *
 * Version 1.1 (the "License"); you may not use this file except in             *
 * compliance with the License. You may obtain a copy of the License at         *
 * either http://www.mozilla.org/MPL/.                                          *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License     *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * Author: Hridesh Rajan                                                        *
 * Copyright (C) 2005 Hridesh Rajan.                                       *
 * All Rights Reserved.                                                         *
 *                                                                              *
 ********************************************************************************/
# endregion

using System;

namespace Nu.Runtime {
	/// <summary>
	/// Run time factory for creating reflective information at a join point. As a developer using Nu
	/// you don't need to understand how this class works.
	/// </summary>
	public sealed class Factory
	{
		/// <summary>
		/// 
		/// </summary>
		/// <param name="FileName"></param>
		/// <param name="type"></param>
		/// <param name="sig"></param>
		/// <returns></returns>
		public static IStaticPart MakeSP(System.String FileName, System.Type type, Signature.ISignature sig) 
		{
			ISourceLocation Location = new SourceLocation(type, FileName, -1);
			return new StaticPart(sig, Location);
		}
		 

		private static object[] NO_ARGS = new object[0];

//#if DEBUG
		/// <summary>
		/// 
		/// </summary>
		/// <param name="staticPart"></param>
		/// <returns></returns>
		public static Nu.Runtime.IJoinpoint MakeJP(IStaticPart staticPart, JPKind kind){
			return new Nu.Runtime.Joinpoint((StaticPart)staticPart, kind);
		}
//#endif

		/// <summary>
		/// 
		/// </summary>
		/// <param name="staticPart"></param>
		/// <param name="_this"></param>
		/// <param name="target"></param>
		/// <param name="returnValue"></param>
		/// <returns></returns>
		public static Nu.Runtime.IJoinpoint MakeJP(IStaticPart staticPart, object _this, JPKind kind, object returnValue) 
		{
			return new Nu.Runtime.Joinpoint((StaticPart)staticPart, _this, kind, returnValue, NO_ARGS);
		}
    
		/// <summary>
		/// 
		/// </summary>
		/// <param name="staticPart"></param>
		/// <param name="_this"></param>
		/// <param name="target"></param>
		/// <param name="returnValue"></param>
		/// <param name="first_arg"></param>
		/// <returns></returns>
		public static IJoinpoint MakeJP(IStaticPart staticPart, object _this, JPKind kind, object returnValue, object first_arg) 
		{
			return new Nu.Runtime.Joinpoint((StaticPart)staticPart, _this, kind, returnValue, new object[] {first_arg} );
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="staticPart"></param>
		/// <param name="_this"></param>
		/// <param name="target"></param>
		/// <param name="returnValue"></param>
		/// <param name="first_arg"></param>
		/// <param name="second_arg"></param>
		/// <returns></returns>
		public static IJoinpoint MakeJP(IStaticPart staticPart, object _this, JPKind kind, object returnValue, object first_arg, object second_arg) 
		{
			return new Nu.Runtime.Joinpoint((StaticPart)staticPart, _this, kind, returnValue, new object[] {first_arg, second_arg} );
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="staticPart"></param>
		/// <param name="_this"></param>
		/// <param name="target"></param>
		/// <param name="returnValue"></param>
		/// <param name="args"></param>
		/// <returns></returns>
		public static IJoinpoint MakeJP(IStaticPart staticPart, object _this, JPKind kind, object returnValue, object [] args) {
			return new Nu.Runtime.Joinpoint((StaticPart)staticPart, _this, kind, returnValue, args );
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public Signature.ISignature MakeNULLSig() {
			return new Signature.NULL();
		}
		//		public Signature.IMethodSignature MakeMethodSignature(string StringRepresentation) 
		//		{
		//			return new Signature.MethodSignature(StringRepresentation);
		//		}
    
#if DEBUG
		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public static Signature.IMethodSignature MakeMSig(){
			return null;
		}
#endif

		/// <summary>
		/// 
		/// </summary>
		/// <param name="modifiers"></param>
		/// <param name="name"></param>
		/// <param name="declaringType"></param>
		/// <param name="ParameterTypes"></param>
		/// <param name="ParameterNames"></param>
		/// <param name="ReturnType"></param>
		/// <returns></returns>
		public static Signature.ISignature MakeMSig(System.String modifiers, System.String name, System.Type declaringType, 
			System.Type[] ParameterTypes, System.String[] ParameterNames, System.Type ReturnType) {
			return new Signature.MethodSignature(modifiers, name, declaringType, ParameterTypes, ParameterNames, ReturnType);
		}

		//		public Signature.IFieldSignature MakeFieldSignature(string StringRepresentation) 
		//		{
		//			return new Signature.FieldSignature(StringRepresentation);
		//		}
    
		/// <summary>
		/// 
		/// </summary>
		/// <param name="modifiers"></param>
		/// <param name="name"></param>
		/// <param name="declaringType"></param>
		/// <param name="FieldType"></param>
		/// <returns></returns>
		public Signature.IFieldSignature MakeFSig(string modifiers, string name, System.Type declaringType, Type FieldType) {
			return new Signature.FieldSignature(modifiers, name, declaringType, FieldType);
		}

		//		public Signature.IConstructorSignature MakeConstructorSignature(string StringRepresentation) 
		//		{
		//			return new Signature.ConstructorSignature(StringRepresentation);
		//		}
    
		/// <summary>
		/// 
		/// </summary>
		/// <param name="modifiers"></param>
		/// <param name="name"></param>
		/// <param name="declaringType"></param>
		/// <param name="ParameterTypes"></param>
		/// <param name="ParameterNames"></param>
		/// <returns></returns>
		public Signature.IConstructorSignature MakeCSig(string modifiers, string name, System.Type declaringType, 
			Type[] ParameterTypes, string[] ParameterNames) {
			return new Signature.ConstructorSignature(modifiers, name, declaringType, ParameterTypes, ParameterNames);
		}

		//		public Signature.ICatchClauseSignature MakeCatchClauseSignature(string StringRepresentation) 
		//		{
		//			return new Signature.CatchClauseSignature(StringRepresentation);
		//		}
    
		/// <summary>
		/// Make CatchClauseSignature
		/// </summary>
		/// <param name="declaringType"></param>
		/// <param name="ParameterType"></param>
		/// <param name="ParameterName"></param>
		/// <returns></returns>
		public Signature.ICatchClauseSignature MakeCCSig(System.Type declaringType, Type ParameterType, string ParameterName) {
			return new Signature.CatchClauseSignature(declaringType,ParameterType,ParameterName);
		}


		//		public static JoinPoint.StaticPart makeEncSJP(Member member) 
		//		{
		//			Signature sig = null;
		//			String kind = null;
		//			if (member instanceof Method) 
		//										{
		//											Method method = (Method) member;
		//											sig = new MethodSignatureImpl(method.getModifiers(),method.getName(),
		//												method.getDeclaringClass(),method.getParameterTypes(),
		//												new String[method.getParameterTypes().length],
		//												method.getExceptionTypes(),method.getReturnType());
		//											kind = JoinPoint.METHOD_EXECUTION;
		//										} 
		//			else if (member instanceof Constructor) 
		//												  {
		//													  Constructor cons = (Constructor) member;
		//													  sig = new ConstructorSignatureImpl(cons.getModifiers(),cons.getDeclaringClass(),
		//														  cons.getParameterTypes(),
		//														  new String[cons.getParameterTypes().length],
		//														  cons.getExceptionTypes());
		//													  kind = JoinPoint.CONSTRUCTOR_EXECUTION;
		//												  } 
		//			else 
		//			{
		//				throw new IllegalArgumentException("member must be either a method or constructor");
		//			}
		//			return new JoinPointImpl.StaticPartImpl(kind,sig,null);
		//		}
    
		//		public AdviceSignature makeAdviceSig(String stringRep) 
		//		{
		//			AdviceSignatureImpl ret = new AdviceSignatureImpl(stringRep);
		//			ret.setLookupClassLoader(lookupClassLoader);
		//			return ret;
		//		}
		//
		//		public AdviceSignature makeAdviceSig(int modifiers, String name, Class declaringType, 
		//			Class[] parameterTypes, String[] parameterNames, Class[] exceptionTypes,
		//			Class returnType) 
		//		{
		//			AdviceSignatureImpl ret = new AdviceSignatureImpl(modifiers,name,declaringType,parameterTypes,parameterNames,exceptionTypes,returnType);
		//			ret.setLookupClassLoader(lookupClassLoader);
		//			return ret;
		//		}
		//
		//		public InitializerSignature makeInitializerSig(String stringRep) 
		//		{
		//			InitializerSignatureImpl ret = new InitializerSignatureImpl(stringRep);
		//			ret.setLookupClassLoader(lookupClassLoader);
		//			return ret;
		//		}
		//
		//		public InitializerSignature makeInitializerSig(int modifiers, Class declaringType) 
		//		{
		//			InitializerSignatureImpl ret = new InitializerSignatureImpl(modifiers,declaringType);
		//			ret.setLookupClassLoader(lookupClassLoader);
		//			return ret;
		//		}    

	}
}
