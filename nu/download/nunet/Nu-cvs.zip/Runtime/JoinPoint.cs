#region "Copyright(C)2005, Hridesh Rajan"
/********************************************************************************
 *                                                                              *
 * This file is part of the Nu compiler source Code.                         *
 *                                                                              *
 * The contents of this file are subject to the Mozilla Public License          *
 * Version 1.1 (the "License"); you may not use this file except in             *
 * compliance with the License. You may obtain a copy of the License at         *
 * either http://www.mozilla.org/MPL/.                                          *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License     *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * Author: Hridesh Rajan                                                        *
 * Copyright (C) 2005 Hridesh Rajan.                                       *
 * All Rights Reserved.                                                         *
 *                                                                              *
 ********************************************************************************/
# endregion

using System;

namespace Nu.Runtime
{
	/// <summary>
	/// Represents the runtime reflective object Joinpoint.
	/// </summary>
	internal class Joinpoint: IJoinpoint
	{

		// String representations of join point kinds
		static string[] KindArray = new string[]{"execution", "return", "unknown"};


		/// <summary>
		/// 
		/// </summary>
		/// <param name="staticPart"></param>
		/// <param name="_this"></param>
		/// <param name="_kind"></param>
		/// <param name="returnValue"></param>
		/// <param name="args"></param>
		public Joinpoint(Nu.Runtime.StaticPart staticPart, object _this, JPKind _kind, object returnValue, System.Object[] args) 
		{
			this.staticPart = staticPart;
			this._this = _this;
			this._kind = _kind;
			this.returnValue = returnValue;
			this.args = args;
			this.args_length = args.Length;
		}

		internal void SetTarget(object target)
		{
			this.target = target;
		}

		public Joinpoint(Nu.Runtime.StaticPart staticPart, JPKind _kind) 
		{
			this.staticPart = staticPart;
			this._kind = _kind;
		}

		#region IJoinpoint Members

		internal int args_length; // Optimization to eliminate calls to this.args.Length across the package

		internal object _this;
		/// <summary>
		/// 
		/// </summary>
		public object This
		{
			get
			{
				return _this;
			}
		}

		internal object target;
		/// <summary>
		/// 
		/// </summary>
		public object Target
		{
			get
			{
				return target;
			}
		}

		internal object returnValue;
		/// <summary>
		/// 
		/// </summary>
		public object ReturnValue
		{
			get
			{
				return returnValue;
			}
		}

		internal System.Object[] args;
		/// <summary>
		/// 
		/// </summary>
		public Object[] Args
		{
			get
			{
				if(args.Length == 0)return args;
				/// To implement the semantics that arguments are always passed by value
				/// we will pass a copy of the argument instead of passing the actual 
				/// arguments
				System.Object[] copy = new System.Object[args.Length];
				System.Array.Copy(args, 0, copy, 0, args.Length);
				return copy;
			}
		}

		internal Nu.Runtime.StaticPart staticPart;
		/// <summary>
		/// 
		/// </summary>
		public Nu.Runtime.IStaticPart StaticPart
		{ 
			get
			{
				return staticPart;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public Nu.Runtime.Signature.ISignature Signature
		{
			get
			{
				return staticPart._Signature;
			}
		}

		internal JPKind _kind;
		/// <summary>
		/// The string representation of the kind of the join point.
		/// </summary>
		public string Kind
		{
			get
			{
				return KindArray[(int)_kind];
			}
		}

		public JPKind _Kind {
			get {
				return _kind;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public ISourceLocation Location
		{
			get
			{
				return staticPart._Location;
			}
		}
		#endregion

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public override string ToString()
		{
			if (staticPart != null)
				return Kind + "(" + staticPart.ToString() + ")";
			return base.ToString();
		}
	}
}
