#region "Copyright(C)2005, Hridesh Rajan"
/********************************************************************************
 *                                                                              *
 * This file is part of the Nu compiler source Code.                         *
 *                                                                              *
 * The contents of this file are subject to the Mozilla Public License          *
 * Version 1.1 (the "License"); you may not use this file except in             *
 * compliance with the License. You may obtain a copy of the License at         *
 * either http://www.mozilla.org/MPL/.                                          *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License     *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * Author: Hridesh Rajan                                                        *
 * Copyright (C) 2005 Hridesh Rajan.                                       *
 * All Rights Reserved.                                                         *
 *                                                                              *
 ********************************************************************************/
# endregion

using System;

namespace Nu.Runtime
{
	/// <summary>
	/// The kinds of joinpoints.
	/// </summary>
	public enum JPKind {
		/// <summary>
		/// An execution joinpoint.  Matches at the execution of a method.
		/// </summary>
		Execution,
		/// <summary>
		/// A return joinpoint.  Matches at the return of a method.
		/// </summary>
		Return,
		/// <summary>
		/// An unknown joinpoint.  Used as a placeholder for not yet implemented joinpoints.
		/// </summary>
		Unknown };

	/// <summary>
	/// Represents the runtime reflective object Joinpoint.
	/// </summary>
	public interface IJoinpoint
	{   
		/// <summary>
		/// Returns the value of "this" at the join point. Returns
		/// null in the case of static join points
		/// </summary>
		object This { get; }        
		
		/// <summary>
		/// Returns the target of the join point. Returns null
		/// in cases where there is no target.
		/// </summary>
		object Target { get; }

		/// <summary>
		/// Returns the return value at the join point if it 
		/// is a valid return value otherwise null.
		/// </summary>
		object ReturnValue { get; }
        
		/// <summary>
		/// Returns the list of arguments of the join points. Returns
		/// an array of length zero if there are no arguments.
		/// </summary>
		System.Object[] Args { get; } 

		/// <summary>
		/// Returns the string representation of the join point kind.
		/// </summary>
		string Kind { get; }
        
		/// <summary>
		/// Returns the kind of the joinpoint.
		/// </summary>
		JPKind _Kind { get; }

		/// <summary>
		/// Returns the signature of the join point. Please see the interface
		/// Nu.Runtime.Signature.ISignature for more details.
		/// </summary>
		Nu.Runtime.Signature.ISignature Signature{ get; }

		/// <summary>
		/// Returns the static representation at the join point. Please see 
		/// Nu.Runtime.IStaticPart for more details.
		/// </summary>
		Nu.Runtime.IStaticPart StaticPart{ get; }

		/// <summary>
		/// Returns the Location of the join point. Please see 
		/// Nu.Runtime.ISourceLocation for more details.
		/// </summary>
		ISourceLocation Location { get; }

	}
}
