using System;

namespace Nu.Runtime.Signature
{
	/// <summary>
	/// Signature of a field. A field get, set and property get, set
	/// join points return this signature.
	/// </summary>
	public interface IFieldSignature:IMemberSignature 
	{
		/// <summary>
		/// The System.Type representation of the type of the field.
		/// </summary>
		System.Type FieldType{ get; }
	}
}
