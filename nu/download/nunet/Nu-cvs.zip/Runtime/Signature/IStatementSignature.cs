using System;

namespace Nu.Runtime.Signature
{
	/// <summary>
	/// The signature of an statement. The iteration and 
	/// the conditional join points return this signature.
	/// Currently not implemented.
	/// </summary>
	public interface IStatementSignature: ISignature
	{
	}
}
