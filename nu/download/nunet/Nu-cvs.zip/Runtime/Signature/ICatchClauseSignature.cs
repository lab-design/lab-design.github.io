using System;

namespace Nu.Runtime.Signature
{
	/// <summary>
	/// The signature for the handler join points.
	/// </summary>
	public interface ICatchClauseSignature: ISignature 
	{
		/// <summary>
		/// Returns the type of the exception caught
		/// </summary>
		System.Type ParameterType{ get; }     

		/// <summary>
		/// Returns the name of the exception caught.
		/// </summary>
		string ParameterName{ get; }
	}
}
