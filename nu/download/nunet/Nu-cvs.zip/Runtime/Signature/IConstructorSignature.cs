using System;

namespace Nu.Runtime.Signature
{
	/// <summary>
	/// The signature of a constructor. An object initialization join point
	/// returns this signature.
	/// </summary>
	public interface IConstructorSignature: ICodeSignature 
	{
	}
}
