using System;

namespace Nu.Runtime.Signature
{
	/// <summary>
	/// Summary description for CodeSignature.
	/// </summary>
	internal abstract class CodeSignature : MemberSignature, ICodeSignature
	{
		internal CodeSignature( string modifiers, string name, System.Type declaringType, 
			Type[] ParameterTypes, string[] ParameterNames): base(modifiers, name, declaringType)
		{
			_ParameterTypes = ParameterTypes;
			_ParameterNames = ParameterNames;
		}
		#region ICodeSignature Members
		
		public override string ToString()
		{

			System.Text.StringBuilder sb = new System.Text.StringBuilder();
			if(this.Modifiers != null) sb.Append(this.Modifiers + " ");
			if(this.DeclaringType != null) sb.Append(this.DeclaringTypeName + ".");
			if(this.Name != null) sb.Append(this.Name);

			return  sb.ToString(); 
		}

		Type[] _ParameterTypes;
		public Type[] ParameterTypes
		{
			get
			{
				return _ParameterTypes;
			}
		}

		string[] _ParameterNames;
		public string[] ParameterNames
		{
			get
			{
				return _ParameterNames;
			}
		}

		#endregion

	}
}
