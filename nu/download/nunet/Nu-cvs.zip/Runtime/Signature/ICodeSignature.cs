using System;

namespace Nu.Runtime.Signature
{
	/// <summary>
	/// ICodeSignature
	/// </summary>
	public interface ICodeSignature : IMemberSignature 
	{
		/// <summary>
		/// The list of the types of the parameters at the join point.
		/// </summary>
		System.Type[] ParameterTypes { get; }

		/// <summary>
		/// The list of the names of the parameters at the join point. 
		/// </summary>
		string[] ParameterNames { get; }
	}
}
