using System;

namespace Nu.Runtime.Signature
{
	/// <summary>
	/// 
	/// </summary>
	public interface IMemberSignature : ISignature 
	{
	}
}
