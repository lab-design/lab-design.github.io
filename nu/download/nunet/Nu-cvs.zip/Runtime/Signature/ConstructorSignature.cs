using System;

namespace Nu.Runtime.Signature
{
	internal class ConstructorSignature: CodeSignature, IConstructorSignature
	{
		public ConstructorSignature(string modifiers, string name, System.Type declaringType, 
			Type[] ParameterTypes, string[] ParameterNames)
			:base(modifiers, name, declaringType, ParameterTypes, ParameterNames)
		{
		}
	}
}
