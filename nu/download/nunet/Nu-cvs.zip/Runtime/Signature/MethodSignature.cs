using System;

namespace Nu.Runtime.Signature
{
	/// <summary>
	/// Summary description for MethodSignature.
	/// </summary>
	internal class MethodSignature: CodeSignature, IMethodSignature
	{
		internal MethodSignature( string modifiers, string name, System.Type declaringType, 
			Type[] ParameterTypes, string[] ParameterNames, Type ReturnType)
			: base(modifiers, name, declaringType, ParameterTypes, ParameterNames)
		{
			this._ReturnType = ReturnType;
		}
		public override string ToString()
		{
			System.Text.StringBuilder sb = new System.Text.StringBuilder();
			if(this.Modifiers != null) sb.Append(this.Modifiers + " ");
			if(this._ReturnType != null) sb.Append(this._ReturnType.ToString() + " ");
			if(this.DeclaringType != null) sb.Append(this.DeclaringTypeName + ".");
			if(this.Name != null) sb.Append(this.Name);
			sb.Append("(");
			for(int i = 0; i < this.ParameterTypes.GetLength(0); i++)
			{
				if (i > 0)
					sb.Append(",");
				sb.Append(" ");
				if(this.ParameterTypes[i]!= null)sb.Append(this.ParameterTypes[i].ToString());
				if(this.ParameterNames[i]!= null)sb.Append(" " + this.ParameterNames[i]);
			}
			sb.Append(" )");

			return  sb.ToString(); 
		}

		#region IMethodSignature Members

		Type _ReturnType;
		public Type ReturnType
		{
			get
			{
				return _ReturnType;
			}
		}

		#endregion
	}
}
