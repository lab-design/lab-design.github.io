using System;

namespace Nu.Runtime.Signature
{
	internal abstract class MemberSignature: Signature, IMemberSignature
	{
		internal MemberSignature(string modifiers, string name, System.Type declaringType)
			:base(modifiers, name, declaringType) 
		{
		}
	}
}
