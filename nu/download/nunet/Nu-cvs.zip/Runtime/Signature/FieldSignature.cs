using System;

namespace Nu.Runtime.Signature
{
	internal class FieldSignature: MemberSignature, IFieldSignature
	{
		public FieldSignature(string modifiers, string name, System.Type declaringType, Type FieldType)
			:base(modifiers, name, declaringType)
		{
			this._FieldType = FieldType;
		}
		#region IFieldSignature Members

		public override string ToString()
		{
			return "field-signature"; 
		}

		Type _FieldType;
		public Type FieldType
		{
			get
			{
				return _FieldType;
			}
		}

		#endregion
	}
}
