using System;

namespace Nu.Runtime.Signature
{
	internal class CatchClauseSignature: Signature, ICatchClauseSignature
	{
		public CatchClauseSignature(System.Type declaringType, Type ParameterType, string ParameterName)
			:base("No_Modifiers", "catch", declaringType) 
		{
			this._ParameterType = ParameterType;
			this._ParameterName = ParameterName;
		}

		#region ICatchClauseSignature Members
		public override string ToString()
		{
			return "catch-clause"; 
		}

		Type _ParameterType;
		public Type ParameterType
		{
			get
			{
				return _ParameterType;
			}
		}
		string _ParameterName;
		public string ParameterName
		{
			get
			{
				return _ParameterName;
			}
		}

		#endregion
	}
}
