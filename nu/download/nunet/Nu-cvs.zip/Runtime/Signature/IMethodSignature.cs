using System;

namespace Nu.Runtime.Signature
{
	/// <summary>
	/// Signature of the method. A call and an execution join 
	/// point return this signature.
	/// </summary>
	public interface IMethodSignature: ICodeSignature 
	{
		/// <summary>
		/// The return type of the method.
		/// </summary>
		System.Type ReturnType{ get; }
	}
}
