using System;

namespace Nu.Runtime.Signature
{
	internal abstract class Signature: ISignature
	{
		internal Signature(string modifiers, string name, System.Type declaringType) 
		{
			this.modifiers = modifiers;
			this.name = name;
			this.declaringType = declaringType;
		}

		#region ISignature Members

		/// <summary>
		/// Returns a string representation of this signature. 
		/// </summary>
		/// <returns> String representation of the signature. </returns>
		public abstract override string ToString();

		string name;
		public string Name
		{
			get
			{
				return name;
			}
		}

		string modifiers;
		public string Modifiers
		{
			get
			{
				return modifiers;
			}
		}

		System.Type declaringType;
		public Type DeclaringType
		{
			get
			{
				return declaringType;
			}
		}

		string declaringTypeName = null;
		public string DeclaringTypeName
		{
			get
			{
				if(declaringTypeName == null)
					declaringTypeName = declaringType.FullName;
				return declaringTypeName;
			}
		}

		#endregion
	}
}
