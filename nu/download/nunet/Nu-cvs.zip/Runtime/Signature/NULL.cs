using System;

namespace Nu.Runtime.Signature
{
	/// <summary>
	/// A null signature, returned in cases where the join point
	/// signature is not implemented.
	/// </summary>
	public class NULL: ISignature
	{
		public NULL(){}
		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public override string ToString()
		{
			return "JOIN-POINT-SIGNATURE-NOT-IMPLEMENTED";
		}
		#region ISignature Members

		/// <summary>
		/// 
		/// </summary>
		public string Name
		{
			get
			{
				// TODO:  Add NULL.Name getter implementation
				return null;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public string Modifiers
		{
			get
			{
				// TODO:  Add NULL.Modifiers getter implementation
				return "No_Modifiers";
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public Type DeclaringType
		{
			get
			{
				// TODO:  Add NULL.DeclaringType getter implementation
				return null;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public string DeclaringTypeName
		{
			get
			{
				// TODO:  Add NULL.DeclaringTypeName getter implementation
				return null;
			}
		}

		#endregion
	}
}
