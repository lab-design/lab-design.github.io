using System;

namespace Nu.Runtime.Signature
{
	/// <summary>
	/// Summary description for ISignature.
	/// </summary>
	public interface ISignature
	{

		/// <summary>
		/// Returns a string representation of this signature. 
		/// </summary>
		/// <returns> String representation of the signature. </returns>
		string ToString();

		/// <summary>
		/// Name of the signature.
		/// </summary>
		string Name { get; }

		/// <summary>
		/// Modifiers of this signature 
		/// </summary>
		string Modifiers { get; }


		/// <summary>
		/// Type of the enclosing class 
		/// </summary>
		System.Type DeclaringType{ get; }
    
		/// <summary>
		/// Name of the enclosing class 
		/// </summary>
		string DeclaringTypeName{ get; }	
	}
}
