#region "Copyright(C)2006, Iowa State University"
/********************************************************************************
 *                                                                              *
 * This file is part of the Nu compiler source Code.                            *
 *                                                                              *
 * The contents of this file are subject to the Mozilla Public License          *
 * Version 1.1 (the "License"); you may not use this file except in             *
 * compliance with the License. You may obtain a copy of the License at         *
 * either http://www.mozilla.org/MPL/.                                          *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License     *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * Author: Robert Dyer                                                          *
 * Copyright (C) 2006 Iowa State University.                                    *
 * All Rights Reserved.                                                         *
 *                                                                              *
 ********************************************************************************/
# endregion

using System;

using Nu.Runtime;
using Nu.Runtime.Pattern;
using Nu.Runtime.Delegate;

namespace HJHelloWorld
{
	class HelloWorld
	{
		static HelloWorld()
		{
			new HelloWorldHM();
		}

		static void Main(string[] args)
		{
		}
	}

	class HelloWorldHM
	{
		static HelloWorldHM()
		{
			Nu.Runtime.Dispatcher.Bind(
				new Return(new Method(Modifiers.Static, "Main")),
				new SimpleDelegate(HelloWorldHM.HelloHS));

			Nu.Runtime.Dispatcher.Bind(
				new Return(new Method(Modifiers.Static, "Main")),
				new SimpleDelegate(HelloWorldHM.WorldHS));
		}
		
		public static void HelloHS()
		{
			new Hello();
		}
		
		public static void WorldHS()
		{
			new World();
		}
	}

	class Hello
	{
		public Hello()
		{
			System.Console.WriteLine("Hello");
		}
	}

	class World
	{
		public World()
		{
			System.Console.WriteLine("World");
		}
	}
}
