#region "Copyright(C)2006, Iowa State University"
/********************************************************************************
 *                                                                              *
 * This file is part of the Nu compiler source Code.                            *
 *                                                                              *
 * The contents of this file are subject to the Mozilla Public License          *
 * Version 1.1 (the "License"); you may not use this file except in             *
 * compliance with the License. You may obtain a copy of the License at         *
 * either http://www.mozilla.org/MPL/.                                          *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License     *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * Author: Robert Dyer                                                          *
 * Copyright (C) 2006 Iowa State University.                                    *
 * All Rights Reserved.                                                         *
 *                                                                              *
 ********************************************************************************/
# endregion

using System;

namespace CFHelloWorld.Filters
{
	using System.Collections;

	/*
	 * The following filter description was taken from:
	 * 
	 * @incollection { bergmans:aosdbook05,
	 *		title = {Principles and Design Rationale of Composition Filters},
	 *		pages = {63-95},
	 *		author = {Lodewijk Bergmans and Mehmet {Ak{\c s}it}},
	 *		crossref = {:aosdbook05},
	 * }
	 */

	/// <summary>
	/// Wait. If the message is accepted, it continues to the next filter in
	/// the set. The message is queued as long as the evaluation of the
	/// filter expression results in a rejection.
	/// </summary>
	public class WaitFilter : Filter
	{
		private System.Threading.Thread worker;
		private Queue messages = new Queue();

		public WaitFilter()
		{
		}

		public WaitFilter(IFilter nextFilter)
		{
			this.nextFilter = nextFilter;
		}

		public override void Accept(Message m, FilterElement element)
		{
			messages.Dequeue();

			if (messages.Count == 0 && worker != null && worker.IsAlive)
			{
				worker.Abort();
				worker = null;
			}

			// otherwise send the message on to the next filter
			if (nextFilter != null)
				nextFilter.Test(m);
		}

		public override void Reject(Message m)
		{
			messages.Enqueue(m);

			// queue the message to try again later
			if (worker == null)
			{
				worker = new System.Threading.Thread(new System.Threading.ThreadStart(Work));

				worker.Priority = System.Threading.ThreadPriority.BelowNormal;
				worker.Start();
			}
		}

		private void Work()
		{
			while (messages.Count > 0)
			{
				// TODO: fix the threaded queue for wait filters
				System.Threading.Thread.Sleep(1);
				Test((Message)messages.Peek());
			}
		}
	}
}
