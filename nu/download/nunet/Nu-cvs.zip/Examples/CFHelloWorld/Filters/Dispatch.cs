#region "Copyright(C)2006, Iowa State University"
/********************************************************************************
 *                                                                              *
 * This file is part of the Nu compiler source Code.                            *
 *                                                                              *
 * The contents of this file are subject to the Mozilla Public License          *
 * Version 1.1 (the "License"); you may not use this file except in             *
 * compliance with the License. You may obtain a copy of the License at         *
 * either http://www.mozilla.org/MPL/.                                          *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License     *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * Author: Robert Dyer                                                          *
 * Copyright (C) 2006 Iowa State University.                                    *
 * All Rights Reserved.                                                         *
 *                                                                              *
 ********************************************************************************/
# endregion

using System;

namespace CFHelloWorld.Filters
{
	using CFHelloWorld;

	/*
	 * The following filter description was taken from:
	 * 
	 * @incollection { bergmans:aosdbook05,
	 *		title = {Principles and Design Rationale of Composition Filters},
	 *		pages = {63-95},
	 *		author = {Lodewijk Bergmans and Mehmet {Ak{\c s}it}},
	 *		crossref = {:aosdbook05},
	 * }
	 */

	/// <summary>
	/// Dispatch. If the message is accepted, it is dispatched to the current 
	/// target of the message, otherwise the message continues to the
	/// subsequent filter (if there is none, an exception is raised).
	/// </summary>
	public class DispatchFilter : Filter
	{
		public DispatchFilter()
		{
		}

		public DispatchFilter(IFilter nextFilter)
		{
			this.nextFilter = nextFilter;
		}

		public override void Accept(Message m, FilterElement element)
		{
			// on accepting a message, just dispatch it
			m.Dispatch();
		}
		
		public override void Reject(Message m)
		{
			// if there is no filter after this then throw an exception
			if (nextFilter == null)
				throw new FilterException("Message from " + m.Selector.ToString()
					+ " was rejected by this dispatch filter and no more filters exist.");

			// otherwise send the message on to the next filter
			nextFilter.Test(m);
		}
	}
}
