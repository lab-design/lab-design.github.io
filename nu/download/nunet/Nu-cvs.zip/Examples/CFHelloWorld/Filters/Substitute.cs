#region "Copyright(C)2006, Iowa State University"
/********************************************************************************
 *                                                                              *
 * This file is part of the Nu compiler source Code.                            *
 *                                                                              *
 * The contents of this file are subject to the Mozilla Public License          *
 * Version 1.1 (the "License"); you may not use this file except in             *
 * compliance with the License. You may obtain a copy of the License at         *
 * either http://www.mozilla.org/MPL/.                                          *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License     *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * Author: Robert Dyer                                                          *
 * Copyright (C) 2006 Iowa State University.                                    *
 * All Rights Reserved.                                                         *
 *                                                                              *
 ********************************************************************************/
# endregion

using System;

namespace CFHelloWorld.Filters
{
	/*
	 * The following filter description was taken from:
	 * 
	 * @incollection { bergmans:aosdbook05,
	 *		title = {Principles and Design Rationale of Composition Filters},
	 *		pages = {63-95},
	 *		author = {Lodewijk Bergmans and Mehmet {Ak{\c s}it}},
	 *		crossref = {:aosdbook05},
	 * }
	 */

	/// <summary>
	/// Substitute. Is used to modify (substitute) certain properties
	/// of messages explicitly.
	/// </summary>
	public class SubstituteFilter : Filter
	{
		public SubstituteFilter()
		{
		}

		public SubstituteFilter(IFilter nextFilter)
		{
			this.nextFilter = nextFilter;
		}
		
		public override void Accept(Message m, FilterElement element)
		{
		}

		public override void Reject(Message m)
		{
			// otherwise send the message on to the next filter
			if (nextFilter != null)
				nextFilter.Test(m);
		}
	}
}
