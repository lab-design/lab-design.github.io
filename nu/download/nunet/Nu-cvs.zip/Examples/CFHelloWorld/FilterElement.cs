#region "Copyright(C)2006, Iowa State University"
/********************************************************************************
 *                                                                              *
 * This file is part of the Nu compiler source Code.                            *
 *                                                                              *
 * The contents of this file are subject to the Mozilla Public License          *
 * Version 1.1 (the "License"); you may not use this file except in             *
 * compliance with the License. You may obtain a copy of the License at         *
 * either http://www.mozilla.org/MPL/.                                          *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License     *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * Author: Robert Dyer                                                          *
 * Copyright (C) 2006 Iowa State University.                                    *
 * All Rights Reserved.                                                         *
 *                                                                              *
 ********************************************************************************/
# endregion

using System;

namespace CFHelloWorld
{
	/// <summary>
	/// A delegate used for checking conditions in filter elements.
	/// </summary>
	public delegate bool CheckCondition();
	
	/// <summary>
	/// A delegate used for forwarding a message on to a specified object.
	/// </summary>
	public delegate bool Forwarder(Message m);


	/// <summary>
	/// Provides a single filter element.  Filter elements have
	/// a check condition (a default condition of true is provided
	/// for filter elements with a 'dont care' condition), matching,
	/// and optionally an object to forward the message to.
	/// </summary>
	public class FilterElement
	{
		/// <summary>
		/// The filter element's condition.
		/// </summary>
		private CheckCondition condition;
		/// <summary>
		/// The identifier's the filter element matches.
		/// </summary>
		private Identifier[] matches;

		public Forwarder forward;
		

		/// <summary>
		/// Provides a default condition for filter elements (always true).
		/// </summary>
		/// <returns>Always returns true.</returns>
		public static bool DefaultCheck()
		{
			return true;
		}


		public FilterElement(CheckCondition condition, string matchTarget, string[] matchSel)
		{
			this.condition = condition;
			matches = new Identifier[matchSel.Length];
			for (int i = 0; i < matchSel.Length; i++)
				matches[i] = new Identifier(matchTarget, matchSel[i]);
		}


		public FilterElement(string matchTarget, string[] matchSel) : this(new CheckCondition(FilterElement.DefaultCheck), matchTarget, matchSel)
		{
		}


		public FilterElement(CheckCondition condition, string matchTarget, string[] matchSel, Forwarder forward) : this(condition, matchTarget, matchSel)
		{
			this.forward = forward;
		}


		public FilterElement(string matchTarget, string[] matchSel, Forwarder forward) : this(new CheckCondition(FilterElement.DefaultCheck), matchTarget, matchSel, forward)
		{
		}
		

		/// <summary>
		/// Tests if this filter element will accept a specific message.
		/// </summary>
		/// <param name="m">The message to test.</param>
		/// <returns>Boolean indicating acceptance of the message.</returns>
		public bool Accept(Message m)
		{
			// check the condition
			if (condition())
				// if the condition is true, see if the message matches
				foreach (Identifier id in matches)
					// if the message matches then accept it
					if (id.Equals(m.Selector))
						return true;
			
			return false;
		}
	}
}
