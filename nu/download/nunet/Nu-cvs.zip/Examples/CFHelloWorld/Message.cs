#region "Copyright(C)2006, Iowa State University"
/********************************************************************************
 *                                                                              *
 * This file is part of the Nu compiler source Code.                            *
 *                                                                              *
 * The contents of this file are subject to the Mozilla Public License          *
 * Version 1.1 (the "License"); you may not use this file except in             *
 * compliance with the License. You may obtain a copy of the License at         *
 * either http://www.mozilla.org/MPL/.                                          *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License     *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * Author: Robert Dyer                                                          *
 * Copyright (C) 2006 Iowa State University.                                    *
 * All Rights Reserved.                                                         *
 *                                                                              *
 ********************************************************************************/
# endregion

using System;

namespace CFHelloWorld
{
	/// <summary>
	/// Provides message functionality.
	/// </summary>
	public class Message
	{
		/// <summary>
		/// The message's selector.
		/// </summary>
		private Identifier selector;
		/// <summary>
		/// The arguments of the message.
		/// </summary>
		private object[] args = new object[0];
		/// <summary>
		/// The message's target.
		/// </summary>
		private System.Delegate target;
		/// <summary>
		/// The message's sender.
		/// </summary>
		private object sender;
		/// <summary>
		/// The message's server.
		/// </summary>
		private object server;

		/// <summary>
		/// The return value of the message.
		/// </summary>
		private object returnValue;


		/*
		 * The following text taken from:
		 * 
		   @inproceedings{ aksit94,
		    key    = "aksit94",
			author = "Mehmet Aksit and Ken Wakita and Jan Bosch and Lodewijk Bergmans and Akinori Yonezawa",
			title = "{Abstracting Object Interactions Using Composition Filters}",
			booktitle = "Proceedings of the {ECOOP}'93 Workshop on Object-Based Distributed Programming",
			volume = "791",
			publisher = "Springer-Verlag",
			editor = "Rachid Guerraoui and Oscar Nierstrasz and Michel Riveill",
			pages = "152--184",
			year = "1994",
			url = "citeseer.ist.psu.edu/aksit94abstracting.html",
		   }
		 *
		 * The variable inner allows direct internal access on the objects' own methods.
		 * self refers to the instance of the class which defines the method.
		 * If, for example, myPoint refers to self, it will refer to myPoint but not aReferencePoint.
		 * In order to refer to the object that originally received the message, server is used as a target.
		 * Note that server is dynamically bound and is equivalent to Smalltalk self.
		 */

		// TODO: add sender, receiver, server(?)
		public Message(Identifier selector, System.Delegate target, object[] args)
		{
			this.selector = selector;
			this.target = target;
			this.args = args;
		}

		// TODO:
		//  fire()
		//  reply()
		//  copy()
		//  get/set server
		//  get/set sender
		//  get/set receiver

		/// <summary>
		/// Gets/sets the message selector.
		/// </summary>
		public Identifier Selector
		{
			get
			{
				return selector;
			}
			
			set
			{
				selector = value;
			}
		}

		/// <summary>
		/// Gets/sets the arguments of the message.
		/// </summary>
		public object this [int i]
		{
			get 
			{
				if (i > args.Length)
					throw new FilterException("Invalid argument index requested from message.");

				return args[i];
			}

			set
			{
				if (i > args.Length)
					throw new FilterException("Attempt to set value on invalid argument index in message.");

				args[i] = value;
			}
		}

		/// <summary>
		/// Sends the message to the system for filtering.
		/// </summary>
		public void Send()
		{
		}

		/// <summary>
		/// Dispatches a message, which invokes the message body.
		/// </summary>
		public void Dispatch()
		{
			returnValue = target.DynamicInvoke(args);
		}
	}
}
