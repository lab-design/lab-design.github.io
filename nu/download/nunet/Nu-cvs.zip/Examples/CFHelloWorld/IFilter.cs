#region "Copyright(C)2006, Iowa State University"
/********************************************************************************
 *                                                                              *
 * This file is part of the Nu compiler source Code.                            *
 *                                                                              *
 * The contents of this file are subject to the Mozilla Public License          *
 * Version 1.1 (the "License"); you may not use this file except in             *
 * compliance with the License. You may obtain a copy of the License at         *
 * either http://www.mozilla.org/MPL/.                                          *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License     *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * Author: Robert Dyer                                                          *
 * Copyright (C) 2006 Iowa State University.                                    *
 * All Rights Reserved.                                                         *
 *                                                                              *
 ********************************************************************************/
# endregion

using System;

namespace CFHelloWorld
{
	/// <summary>
	/// Public interface to the filters.
	/// </summary>
	public interface IFilter
	{
		/// <summary>
		/// Enables this filter sequence.
		/// Binds to Message.Send()
		/// </summary>
		void Enable();

		/// <summary>
		/// Adds a filter element to this filter.
		/// </summary>
		/// <param name="element">The filter element to add.</param>
		void AddFilterElement(FilterElement element);
		
		/// <summary>
		/// Tests a message to see if it is accepted by any of
		/// the contained filter elements and if not, rejects it.
		/// </summary>
		/// <param name="m">The message to test.</param>
		void Test(Message m);

		/// <summary>
		/// Accepts a message.  The actual semantics is determined
		/// by the concrete implementation.
		/// </summary>
		/// <param name="m">The message that was accepted.</param>
		/// <param name="element">The filter element that accepted the message.</param>
		void Accept(Message m, FilterElement element);
		
		/// <summary>
		/// Rejects a message.  The actual semantics is determined
		/// by the concrete implementation.
		/// </summary>
		/// <param name="m">The message being rejected.</param>
		void Reject(Message m);
	}
}
