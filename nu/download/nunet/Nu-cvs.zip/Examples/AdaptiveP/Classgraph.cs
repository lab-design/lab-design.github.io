#region "Copyright(C)2006, Iowa State University"
/********************************************************************************
 *                                                                              *
 * This file is part of the Nu compiler source Code.                            *
 *                                                                              *
 * The contents of this file are subject to the Mozilla Public License          *
 * Version 1.1 (the "License"); you may not use this file except in             *
 * compliance with the License. You may obtain a copy of the License at         *
 * either http://www.mozilla.org/MPL/.                                          *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License     *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * Author: Youssef Hanna                                                        *
 * Copyright (C) 2006 Iowa State University.                                    *
 * All Rights Reserved.                                                         *
 *                                                                              *
 ********************************************************************************/
# endregion

using System;
using System.Text;
using System.Reflection;

namespace AdaptiveP
{
    /// <summary>
    /// This is a simple classgraph that is implemented just for this example
    /// This classgraph traverses from Company to Employee
    /// </summary>
    class Classgraph
    {
        Node Start;

        public Classgraph()
        {
            //TODO: construct a classgraph using reflection
            Start = new Node();
            Start.className = "Company";
            Node employee = new Node();
            employee.className = "employee";
            Start.outgoing.outNode = employee;
            Node salary = new Node();
            salary.className = "Salary";
            employee.outgoing.outNode = salary;
        }

        public void Traverse(object o, string from, string to)
        {
            Traverse(o, Start, from, to);
        }

        public void Traverse(object o, Node current, string from, string to)
        {
            //TODO: make it general
            if (o is Payroll.Company)
            {
                Payroll.Company c = (Payroll.Company)o;
                // We are exploring all the has-a relationships here
                foreach (Payroll.Employee e in c.employees)
                {
                    Node Next = current.outgoing.outNode;
                    Next.Object = e;
                    Traverse(e, Next, from, to);
                }
            }
            else if (o is Payroll.Employee)
            {
                Payroll.Employee e  = (Payroll.Employee)o;
                
                // if Traverse starts initially from Employee, 
                // we need to start from Employee instead of Company
                if (current.className.Equals("Company"))
                    current = current.outgoing.outNode;

                // We are exploring all the has-a relationships here
                Node Next = current.outgoing.outNode;

                Next.Object = e.s ;
                Traverse(e.s, Next, from, to);
            }
        }
    }

    class Node
    {
        public string className;
        public object Object;
        public Link incoming; 
        public Link outgoing;
        public Node()
        {
            Object = new object();
            outgoing = new Link();
            incoming = new Link();
        }
    }

    class Link
    {
        public Node inNode;
        public Node outNode; 
    }
}
