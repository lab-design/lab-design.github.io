Nu 0.1 - Instructions for Compiling the Examples

There are five examples.  They may be found at:

  Examples\AdaptiveP
  Examples\AspectJ
  Examples\CFHelloWorld
  Examples\HelloWorld
  Examples\HJHelloWorld

Inside each directory you will find a Visual Studio solution file (.sln).
Open the solution and then build the solution (Build -> Build Solution).

Once the solution is built, two executables will be created.
The executables reside in the bin\ directory inside the example's directory.

The executable with the same name as the example is the normal, un-instrumented
executable.  The executable with "_Nu_Instrumented" in its name is the
instrumented executable created by running "Nu.exe Example.exe".
