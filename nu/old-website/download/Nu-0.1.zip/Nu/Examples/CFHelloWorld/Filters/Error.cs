#region "Copyright(C)2006, Iowa State University"
/********************************************************************************
 *                                                                              *
 * This file is part of the Nu compiler source Code.                            *
 *                                                                              *
 * The contents of this file are subject to the Mozilla Public License          *
 * Version 1.1 (the "License"); you may not use this file except in             *
 * compliance with the License. You may obtain a copy of the License at         *
 * either http://www.mozilla.org/MPL/.                                          *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License     *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * Author: Robert Dyer                                                          *
 * Copyright (C) 2006 Iowa State University.                                    *
 * All Rights Reserved.                                                         *
 *                                                                              *
 ********************************************************************************/
# endregion

using System;

namespace CFHelloWorld.Filters
{
	/*
	 * The following filter description was taken from:
	 * 
	 * @incollection { bergmans:aosdbook05,
	 *		title = {Principles and Design Rationale of Composition Filters},
	 *		pages = {63-95},
	 *		author = {Lodewijk Bergmans and Mehmet {Ak{\c s}it}},
	 *		crossref = {:aosdbook05},
	 * }
	 */

	/// <summary>
	/// Error. If the filter rejects the message, it raises an exception,
	/// otherwise the message continues to the next filter in the set.
	/// </summary>
	public class ErrorFilter : Filter
	{
		public ErrorFilter()
		{
		}

		public ErrorFilter(IFilter nextFilter)
		{
			this.nextFilter = nextFilter;
		}
		
		public override void Accept(Message m, FilterElement element)
		{
			// otherwise send the message on to the next filter
			if (nextFilter != null)
				nextFilter.Test(m);
		}

		public override void Reject(Message m)
		{
			// rejected messages throw exceptions
			throw new FilterException("Message from " + m.Selector.ToString()
				+ " was rejected by this error filter.");
		}
	}
}
