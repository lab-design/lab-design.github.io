#region "Copyright(C)2006, Iowa State University"
/********************************************************************************
 *                                                                              *
 * This file is part of the Nu compiler source Code.                            *
 *                                                                              *
 * The contents of this file are subject to the Mozilla Public License          *
 * Version 1.1 (the "License"); you may not use this file except in             *
 * compliance with the License. You may obtain a copy of the License at         *
 * either http://www.mozilla.org/MPL/.                                          *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License     *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * Author: Robert Dyer                                                          *
 * Copyright (C) 2006 Iowa State University.                                    *
 * All Rights Reserved.                                                         *
 *                                                                              *
 ********************************************************************************/
# endregion

using System;
using CFHelloWorld.Filters;

namespace CFHelloWorld
{
	class HelloWorld
	{
		[STAThread]
		static void Main(string[] args)
		{
			Log logger = new Log("console");
			
			if (args.Length > 0 && args[0].ToLower().Equals("/debug"))
				logger.DebugOn();
			
			logger.Warning("Warning 1");
			logger.Exception("Exception 1");
			logger.Warning("Warning 2");
			logger.Exception("Exception 2");
			logger.Warning("Warning 3");
			logger.Warning("Warning 4");
			logger.Exception("Exception 3");

			logger.DebugOn();
		}
	}

	class Log
	{
		private bool isDebug;
		private IFilter disp;
		private IFilter queue;
		private IFilter cleanup;
		
		public Log(string path)
		{
			isDebug = false;

			// create the filters in reverse order
			cleanup = new DispatchFilter();
			cleanup.AddFilterElement(new FilterElement("Log", new string[] {"Exception", "Warning"}));

			queue = new WaitFilter(cleanup);
			queue.AddFilterElement(new FilterElement(new CheckCondition(queue_Check_1), "Log", new string[] {"Warning"}));

			disp = new DispatchFilter(queue);
			disp.AddFilterElement(new FilterElement(new CheckCondition(disp_Check_1), "Log", new string[] {"Warning"}));
			disp.AddFilterElement(new FilterElement("Log", new string[] {"Exception", "DebugOn", "DebugOff"}));

			// only the first filter gets a call to enable, the rest are already chained
			disp.Enable();
		}

		// condition checks
		private bool queue_Check_1()
		{
			return Debug;
		}

		private bool disp_Check_1()
		{
			return Debug;
		}

		// conditions
		public bool Debug
		{
			get
			{
				return isDebug;
			}
		}
		
		// delegate declarations
		private delegate void log_Del_1(string s);
		private delegate void log_Del_2(string s);
		private delegate void log_Del_3();
		private delegate void log_Del_4();

		// body definitions
		private void ExceptionBody(string s)
		{
			System.Console.WriteLine("**EXCEPTION: " + s);
		}
		
		private void WarningBody(string s)
		{
			System.Console.WriteLine("Warning: " + s);
		}

		private void DebugOnBody()
		{
			isDebug = true;
		}

		private void DebugOffBody()
		{
			isDebug = false;
		}

		// message invocations
		public void Exception(string s) 
		{
			Message m = new Message(new Identifier("Log", "Exception"), new log_Del_1(ExceptionBody), new object[] {s});
			m.Send();
		}
		
		public void Warning(string s) 
		{
			Message m = new Message(new Identifier("Log", "Warning"), new log_Del_2(WarningBody), new object[] {s});
			m.Send();
		}

		public void DebugOn() 
		{
			Message m = new Message(new Identifier("Log", "DebugOn"), new log_Del_3(DebugOnBody), new object[] {});
			m.Send();
		}

		public void DebugOff() 
		{
			Message m = new Message(new Identifier("Log", "DebugOff"), new log_Del_4(DebugOffBody), new object[] {});
			m.Send();
		}
	}
}
