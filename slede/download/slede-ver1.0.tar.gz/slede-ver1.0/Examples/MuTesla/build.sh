echo "Creating the promela model"

make pc 1> right.tc 2> wrong.tc 
x=$(awk '/error/{print $7}' right.tc) 
if [ $x -gt 0 ]
then
   cat wrong.tc
   rm right.tc wrong.tc
   exit 1
else 
   echo ""
   echo "Model generated. Verifying the model"
   spin -a promela.pm 
   gcc -o pan pan.c -DVECTORSZ=10000 2>right.tc 
   ./pan -a > right.tc 
   x=$(awk '/errors/{print $8}' right.tc) 
   echo ""
   if [ $x -gt 0 ]
   then
     echo "Property violated! Generating the counterexample."
     spin -t promela.pm >counterexample.txt
     echo ""
     echo "Counterexample generated in counterexample.txt"
     rm promela.pm.trail
   else
     echo "Propoerty not violated. Protocol is secure!"
   fi
fi
rm right.tc wrong.tc pan.m pan.h pan.t pan.b pan pan.c
