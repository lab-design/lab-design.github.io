c_decl {
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
};
c_decl {
__extension__ 
__extension__ 
__extension__ 










__extension__ 
__extension__ 
__extension__ 
__extension__ 

__extension__ 
__extension__ 
__extension__ 




__extension__ 








__extension__ 




__extension__ 
__extension__ 







__extension__ 
__extension__ 
__extension__ 







__extension__ 
__extension__ 
__extension__ 
__extension__ 
__extension__ 
__extension__ 
__extension__ 
__extension__ 
__extension__ 
__extension__ 
__extension__ 
__extension__ 
__extension__ 
__extension__ 
__extension__ 
__extension__ 
__extension__ 
__extension__ 
__extension__ 
__extension__ 

__extension__ 
__extension__ 
__extension__ 


__extension__ 


__extension__ 


__extension__ 




__extension__ 
__extension__ 


__extension__ 
__extension__ 


__extension__ 
__extension__ 

__extension__ 








__extension__ 


__extension__ 
__extension__ 


__extension__ 


__extension__ 





__extension__ 





__extension__ 





__extension__ 
typedef unsigned char bool;
enum __nesc_unnamed4242 {
  FALSE = 0, 
  TRUE = 1
};

uint16_t node = 1;

enum __nesc_unnamed4243 {
  FAIL = 0, 
  SUCCESS = 1
};
static inline 

uint8_t rcombine(uint8_t r1, uint8_t r2);
typedef uint8_t  result_t;
static inline 






result_t rcombine(result_t r1, result_t r2);
static inline 






result_t rcombine3(result_t r1, result_t r2, result_t r3);
static inline 



result_t rcombine4(result_t r1, result_t r2, result_t r3, 
result_t r4);





enum __nesc_unnamed4244 {
  dummy_by_slede = 0
};
typedef struct __nesc_unnamed4245 {
  int size;
  void *data;
  int private_size;
} heap_t;
static inline 
void init_heap(heap_t *heap);
static inline 
int heap_is_empty(heap_t *heap);
static inline 
long long heap_get_min_key(heap_t *heap);
static 
void *heap_pop_min_data(heap_t *heap, long long *key);
static inline void heap_insert(heap_t *heap, void *data, long long key);
enum __nesc_unnamed4246 {
  TOS_BCAST_ADDR = 0xffff, 
  TOS_UART_ADDR = 0x007e
};





enum __nesc_unnamed4247 {
  TOS_DEFAULT_AM_GROUP = 0x7d
};

uint8_t TOS_AM_GROUP = TOS_DEFAULT_AM_GROUP;
typedef struct TOS_Msg {


  uint16_t addr;
  uint8_t type;
  uint8_t group;
  uint8_t length;
  int8_t data[29];
  uint16_t crc;







  uint16_t strength;
  uint8_t ack;
  uint16_t time;
  uint8_t sendSecurityMode;
  uint8_t receiveSecurityMode;
} TOS_Msg;

typedef struct TOS_Msg_TinySecCompat {


  uint16_t addr;
  uint8_t type;

  uint8_t length;
  uint8_t group;
  int8_t data[29];
  uint16_t crc;







  uint16_t strength;
  uint8_t ack;
  uint16_t time;
  uint8_t sendSecurityMode;
  uint8_t receiveSecurityMode;
} TOS_Msg_TinySecCompat;

typedef struct TinySec_Msg {

  uint16_t addr;
  uint8_t type;
  uint8_t length;

  uint8_t iv[4];

  uint8_t enc[29];

  uint8_t mac[4];


  uint8_t calc_mac[4];
  uint8_t ack_byte;
  int cryptoDone;
  int receiveDone;

  int validMAC;
} __attribute((packed))  TinySec_Msg;



enum __nesc_unnamed4248 {
  MSG_DATA_SIZE = (size_t )& ((struct TOS_Msg *)0)->crc + sizeof(uint16_t ), 
  TINYSEC_MSG_DATA_SIZE = (size_t )& ((struct TinySec_Msg *)0)->mac + 4, 
  DATA_LENGTH = 29, 
  LENGTH_BYTE_NUMBER = (size_t )& ((struct TOS_Msg *)0)->length + 1, 
  TINYSEC_NODE_ID_SIZE = sizeof(uint16_t )
};

enum __nesc_unnamed4249 {
  TINYSEC_AUTH_ONLY = 1, 
  TINYSEC_ENCRYPT_AND_AUTH = 2, 
  TINYSEC_DISABLED = 3, 
  TINYSEC_ENABLED_BIT = 128, 
  TINYSEC_ENCRYPT_ENABLED_BIT = 64
} __attribute((packed)) ;


typedef TOS_Msg *TOS_MsgPtr;
static 
void *nmemcpy(void *to, const void *from, size_t n);
static inline 








void *nmemset(void *to, int val, size_t n);
typedef struct Mac {
  int cipher;

  int key;
} 
Mac;

typedef struct IntMsg {
  int info;

  int type;

  int src;

  int dest;

  int key;

  Mac MAC;
} 
IntMsg;
};
c_state "int SensorM___Leds___greenOn___" "Global" "0"
c_decl {
static inline   result_t RandomLFSR___Random___init(void);
}
c_decl {
static   uint16_t RandomLFSR___Random___rand(void);
}
c_state "uint16_t SensorM___pairwiseKeyWithPrevious[2]" "Global"
c_state "uint16_t SensorM___pairwiseKeyWithNext[2]" "Global"
c_state "uint16_t SensorM___currentKeyReceived[2]" "Global"
c_state "struct TOS_Msg SensorM___data[2]" "Global"
c_state "IntMsg SensorM___savedMessage[2]" "Global"
c_state "uint16_t SensorM___dataRcvd[2]" "Global"
c_state "uint16_t SensorM___currentKeyInChain[2]" "Global"
c_state "uint8_t SensorM___toggle[2]" "Global"
c_decl {  void ;}
c_decl {  void ;}
c_state "TOS_MsgPtr SensorM___Send___sendDone___msg" "Local prtcl"
c_state "result_t SensorM___Send___sendDone___success" "Local prtcl"
c_state "TOS_MsgPtr SensorM___ReceiveMsg___receive___msg" "Local events"






















 c_state "result_t  returnOf___SensorM___Send___sendDone" "Local prtcl" 
 inline SensorM___Send___sendDone()
{
atomic{
 if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
 :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
 fi;
c_code { Pprtcl-> returnOf___SensorM___Send___sendDone = SUCCESS;
;};
}
}


c_state "TOS_MsgPtr Environment" "Global" "NULL"
c_state "uint8_t Receiver" "Global"
c_state "int Sender" "Global"
c_state "int MessageInEnvironment" "Global" "0" /* Field = 0 => No message; Field = -1 => Intruder */
c_state "int legitimate" "Local events" "0"

 c_state "TOS_MsgPtr  returnOf___SensorM___ReceiveMsg___receive" "Local events" 
 inline SensorM___ReceiveMsg___receive()
{
atomic{
 if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
 :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
 fi;
c_code { 
  Pevents->SensorM___ReceiveMsg___receive___message_received = (IntMsg *)Pevents->SensorM___ReceiveMsg___receive___msg->data;
  Pevents->SensorM___ReceiveMsg___receive___k = *Pevents->SensorM___ReceiveMsg___receive___message_received;
  ;
  ;

  ;
  ;};
  }
  if
  :: c_expr {Pevents->SensorM___ReceiveMsg___receive___k.type == 1} -> 
    {
    atomic{
     if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
     :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
     fi;
    c_code { ;};
      }
      if
      :: c_expr {now.SensorM___currentKeyReceived[Pevents->node] == 0} -> 
        {
        atomic{
         if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
         :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
         fi;
        c_code { ;
          now.SensorM___currentKeyReceived[Pevents->node] = Pevents->SensorM___ReceiveMsg___receive___k.info;
        ;};
        }
        }
      :: else -> atomic{
       if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
       :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
       fi;
      c_code { 
        ;};
        }
        if
        :: c_expr {(now.SensorM___currentKeyReceived[Pevents->node] + 2) * 9 == Pevents->SensorM___ReceiveMsg___receive___k.info} -> 
          {
          atomic{
           if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
           :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
           fi;
          c_code { ;
            now.SensorM___currentKeyReceived[Pevents->node] = Pevents->SensorM___ReceiveMsg___receive___k.info;
            ;};
            }
            if
            :: c_expr {now.SensorM___savedMessage[Pevents->node].info != 0} -> 
              {
              atomic{
               if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
               :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
               fi;
              c_code { Pevents->SensorM___ReceiveMsg___receive___MACRcvd.cipher = now.SensorM___savedMessage[Pevents->node].info;
                Pevents->SensorM___ReceiveMsg___receive___mac = now.SensorM___savedMessage[Pevents->node].MAC;
                ;
                ;};
                }
                if
                :: c_expr {Pevents->SensorM___ReceiveMsg___receive___mac.cipher == Pevents->SensorM___ReceiveMsg___receive___MACRcvd.cipher && now.SensorM___currentKeyReceived[Pevents->node] == Pevents->SensorM___ReceiveMsg___receive___mac.key} -> 
                  {
                  atomic{
                   if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
                   :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
                   fi;
                  c_code { now.SensorM___dataRcvd[Pevents->node] = now.SensorM___savedMessage[Pevents->node].info;
                    ;};
                    }
                    assert(c_expr{Pevents->legitimate==1});
                    atomic{
                     if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
                     :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
                     fi;
                    c_code { ;
                    ;
                  ;};
                  }
                  }
                :: else -> skip;
                fi;
                atomic{
                 if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
                 :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
                 fi;
                c_code { ;};
              }
              }
            :: else -> skip;
            fi;
            atomic{
             if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
             :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
             fi;
            c_code { ;};
          }
          }
        :: else -> skip;
        fi;
        atomic{
         if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
         :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
         fi;
        c_code { ;};
      }
      fi;
      atomic{
       if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
       :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
       fi;
      c_code { ;};
    }
    }
  :: else -> atomic{
   if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
   :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
   fi;
  c_code { 
    ;};
    }
    if
    :: c_expr {Pevents->SensorM___ReceiveMsg___receive___k.type == 2} -> 
      {
      atomic{
       if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
       :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
       fi;
      c_code { ;
        now.SensorM___savedMessage[Pevents->node].info = Pevents->SensorM___ReceiveMsg___receive___k.info;
        now.SensorM___savedMessage[Pevents->node].src = Pevents->SensorM___ReceiveMsg___receive___k.src;
        now.SensorM___savedMessage[Pevents->node].dest = Pevents->SensorM___ReceiveMsg___receive___k.dest;
        now.SensorM___savedMessage[Pevents->node].MAC = Pevents->SensorM___ReceiveMsg___receive___k.MAC;
      ;};
      }
      }
    :: else -> skip;
    fi;
    atomic{
     if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
     :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
     fi;
    c_code { ;};
  }
  fi;
  atomic{
   if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
   :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
   fi;
  c_code { Pevents-> returnOf___SensorM___ReceiveMsg___receive = Pevents->SensorM___ReceiveMsg___receive___msg;
;};
}
}








 c_state "result_t  returnOf___SensorM___Sensor___start" "Local prtcl" 
 inline SensorM___Sensor___start()
{
atomic{
 if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
 :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
 fi;
c_code { ;};
  }
  c_code { now.start_timer[Pprtcl->node] = 1;};
  atomic{
   if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
   :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
   fi;
  c_code { ;
  Pprtcl-> returnOf___SensorM___Sensor___start = SUCCESS;
;};
}
}


 c_state "result_t  returnOf___OneWayKeyM___StdControl___start" "Local prtcl" 
 inline OneWayKeyM___StdControl___start()
{
atomic{
 if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
 :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
 fi;
c_code { ;};
  }
  SensorM___Sensor___start();
  atomic{
   if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
   :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
   fi;
  c_code { ;
  Pprtcl-> returnOf___OneWayKeyM___StdControl___start = SUCCESS;
;};
}
}







 c_state "result_t  returnOf___SensorM___Sensor___init" "Local prtcl" 
 inline SensorM___Sensor___init()
{
atomic{
 if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
 :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
 fi;
c_code { now.SensorM___currentKeyInChain[Pprtcl->node] = Pprtcl->node + 2;
  now.SensorM___pairwiseKeyWithPrevious[Pprtcl->node] = Pprtcl->node + 5;
  now.SensorM___pairwiseKeyWithNext[Pprtcl->node] = Pprtcl->node + 6;
  now.SensorM___toggle[Pprtcl->node] = 0;
  now.SensorM___currentKeyReceived[Pprtcl->node] = 0;
  Pprtcl-> returnOf___SensorM___Sensor___init = SUCCESS;
;};
}
}


 c_state "result_t  returnOf___OneWayKeyM___StdControl___init" "Local prtcl" 
 inline OneWayKeyM___StdControl___init()
{
atomic{
 if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
 :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
 fi;
c_code { ;};
  }
  SensorM___Sensor___init();
  atomic{
   if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
   :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
   fi;
  c_code { ;
  Pprtcl-> returnOf___OneWayKeyM___StdControl___init = SUCCESS;
;};
}
}





  inline SensorM___sendMsg()
{
atomic{
 if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
 :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
 fi;
c_code { 
  Pprtcl->SensorM___sendMsg___message = (IntMsg *)now.SensorM___data[Pprtcl->node].data;
  ;

  Pprtcl->SensorM___sendMsg___message->info = 4;
  Pprtcl->SensorM___sendMsg___mac.cipher = 4;
  Pprtcl->SensorM___sendMsg___mac.key = now.SensorM___currentKeyInChain[Pprtcl->node];
  Pprtcl->SensorM___sendMsg___message->MAC = Pprtcl->SensorM___sendMsg___mac;
  Pprtcl->SensorM___sendMsg___message->type = 2;
  Pprtcl->SensorM___sendMsg___message->src = Pprtcl->node;
  Pprtcl->SensorM___sendMsg___message->dest = Pprtcl->node + 1;
  ;
  now.Sender = Pprtcl->node;
  now.sent_from_intruder = 0;
  now.MessageCounter = -1;
  now.Receiver = Pprtcl->SensorM___sendMsg___message->dest;
  now.Environment = &now.SensorM___data[Pprtcl->node];
  now.MessageInEnvironment = ((IntMsg*)(now.Environment->data))->type;
  ;
;};
}
}

  inline SensorM___sendMsg___event()
{
atomic{
 if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
 :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
 fi;
c_code { 
  Pevents->SensorM___sendMsg___event___message = (IntMsg *)now.SensorM___data[Pevents->node].data;
  ;

  Pevents->SensorM___sendMsg___event___message->info = 4;
  Pevents->SensorM___sendMsg___event___mac.cipher = 4;
  Pevents->SensorM___sendMsg___event___mac.key = now.SensorM___currentKeyInChain[Pevents->node];
  Pevents->SensorM___sendMsg___event___message->MAC = Pevents->SensorM___sendMsg___event___mac;
  Pevents->SensorM___sendMsg___event___message->type = 2;
  Pevents->SensorM___sendMsg___event___message->src = Pevents->node;
  Pevents->SensorM___sendMsg___event___message->dest = Pevents->node + 1;
  ;
  now.Sender = Pevents->node;
  now.sent_from_intruder = 0;
  now.MessageCounter = -1;
  now.Receiver = Pevents->SensorM___sendMsg___event___message->dest;
  now.Environment = &now.SensorM___data[Pevents->node];
  now.MessageInEnvironment = ((IntMsg*)(now.Environment->data))->type;
  ;
;};
}
}

  inline SensorM___sendkey()
{
atomic{
 if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
 :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
 fi;
c_code { 
  Pprtcl->SensorM___sendkey___message = (IntMsg *)now.SensorM___data[Pprtcl->node].data;

  Pprtcl->SensorM___sendkey___message->info = now.SensorM___currentKeyInChain[Pprtcl->node];
  Pprtcl->SensorM___sendkey___message->src = Pprtcl->node;
  Pprtcl->SensorM___sendkey___message->dest = Pprtcl->node + 1;
  Pprtcl->SensorM___sendkey___message->type = 1;
  now.SensorM___currentKeyInChain[Pprtcl->node] = (now.SensorM___currentKeyInChain[Pprtcl->node] + 2) * 9;
  ;
  now.Sender = Pprtcl->node;
  now.sent_from_intruder = 0;
  now.MessageCounter = -1;
  now.Receiver = Pprtcl->SensorM___sendkey___message->dest;
  now.Environment = &now.SensorM___data[Pprtcl->node];
  now.MessageInEnvironment = ((IntMsg*)(now.Environment->data))->type;
  ;
;};
}
}

  inline SensorM___sendkey___event()
{
atomic{
 if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
 :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
 fi;
c_code { 
  Pevents->SensorM___sendkey___event___message = (IntMsg *)now.SensorM___data[Pevents->node].data;

  Pevents->SensorM___sendkey___event___message->info = now.SensorM___currentKeyInChain[Pevents->node];
  Pevents->SensorM___sendkey___event___message->src = Pevents->node;
  Pevents->SensorM___sendkey___event___message->dest = Pevents->node + 1;
  Pevents->SensorM___sendkey___event___message->type = 1;
  now.SensorM___currentKeyInChain[Pevents->node] = (now.SensorM___currentKeyInChain[Pevents->node] + 2) * 9;
  ;
  now.Sender = Pevents->node;
  now.sent_from_intruder = 0;
  now.MessageCounter = -1;
  now.Receiver = Pevents->SensorM___sendkey___event___message->dest;
  now.Environment = &now.SensorM___data[Pevents->node];
  now.MessageInEnvironment = ((IntMsg*)(now.Environment->data))->type;
  ;
;};
}
}

 c_state "result_t  returnOf___SensorM___Timer___fired" "Local events" 
 inline SensorM___Timer___fired()
{
atomic{
 if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
 :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
 fi;
c_code { ;
  ;};
  }
  if
  :: c_expr {now.SensorM___toggle[Pevents->node] % 2 == 0} -> 
    atomic{
     if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
     :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
     fi;
    c_code { Pevents->tasks_queue[Pevents->tasks_index] = 3;
    Pevents->tasks_index ++;;};
    }
    ;
  :: else -> atomic{
   if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
   :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
   fi;
  c_code { 
    Pevents->tasks_queue[Pevents->tasks_index] = 1;
    Pevents->tasks_index ++;;
  ;};
  }
  fi;
  atomic{
   if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
   :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
   fi;
  c_code { now.SensorM___toggle[Pevents->node]++;
  Pevents-> returnOf___SensorM___Timer___fired = SUCCESS;
;};
}
atomic {
do
:: c_expr{Pevents->index < Pevents->tasks_index} -> 
if
  :: c_expr{Pevents->tasks_queue[Pevents->index] == 0} ->SensorM___sendMsg();
  :: c_expr{Pevents->tasks_queue[Pevents->index] == 1} ->SensorM___sendMsg___event();
  :: c_expr{Pevents->tasks_queue[Pevents->index] == 2} ->SensorM___sendkey();
  :: c_expr{Pevents->tasks_queue[Pevents->index] == 3} ->SensorM___sendkey___event();
fi;
c_code { Pevents->index++;};
:: else->break;
od;
c_code { Pevents->index = 0;};
c_code { Pevents->tasks_index = 0;};
}
}













 c_state "result_t  returnOf___SensorM___Sensor___stop" "Local prtcl" 
 inline SensorM___Sensor___stop()
{
atomic{
 if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
 :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
 fi;
c_code { ;
  Pprtcl-> returnOf___SensorM___Sensor___stop = SUCCESS;
;};
}
}


 c_state "result_t  returnOf___OneWayKeyM___StdControl___stop" "Local prtcl" 
 inline OneWayKeyM___StdControl___stop()
{
atomic{
 if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
 :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
 fi;
c_code { ;};
  }
  SensorM___Sensor___stop();
  atomic{
   if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
   :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
   fi;
  c_code { ;
  Pprtcl-> returnOf___OneWayKeyM___StdControl___stop = SUCCESS;
;};
}
}



c_state "IntMsg *SensorM___ReceiveMsg___receive___message_received" "Local events"
c_state "IntMsg SensorM___ReceiveMsg___receive___k" "Local events"
c_state "Mac SensorM___ReceiveMsg___receive___MACRcvd" "Local events"
c_state "Mac SensorM___ReceiveMsg___receive___mac" "Local events"






c_state "IntMsg *SensorM___sendMsg___message" "Local prtcl"
c_state "Mac SensorM___sendMsg___mac" "Local prtcl"


c_state "IntMsg *SensorM___sendMsg___event___message" "Local events"
c_state "Mac SensorM___sendMsg___event___mac" "Local events"


c_state "IntMsg *SensorM___sendkey___message" "Local prtcl"


c_state "IntMsg *SensorM___sendkey___event___message" "Local events"





c_state "struct IntMsg* msgRcvd" "Local Intruder"
c_state "struct IntMsg* msg_to_send" "Local Intruder"
c_state "int msg_is_modified" "Local Intruder" "0" 
c_state "struct TOS_Msg msgModified" "Local Intruder"
c_state "struct TOS_Msg message_received" "Local events"
c_state "int sent_from_intruder" "Global" "0"
c_state "int MessageCounter" "Global" "0"
c_state "TOS_Msg msg2" "Local Intruder"
c_state "int saved_message2" "Local Intruder"
c_state "int can_send2" "Global" "0"
c_state "struct Mac  data2___2" "Local Intruder"
c_state "int  data___2" "Local Intruder"
c_state "TOS_Msg msg1" "Local Intruder"
c_state "int saved_message1" "Local Intruder"
c_state "int can_send1" "Global" "0"
c_state "int  data___1" "Local Intruder"
proctype Intruder() {
  do
  :: atomic { c_expr{now.MessageInEnvironment!=0 && now.MessageInEnvironment != -1 && now.sent_from_intruder == 0} -> 
  atomic { c_code {PIntruder->msgRcvd = (IntMsg*)now.Environment->data;
  switch (PIntruder->msgRcvd->type) {
    case 2: {
      PIntruder->msg2 = (*now.Environment);
      PIntruder->saved_message2 = 1;
      PIntruder->data2___2 = PIntruder->msgRcvd->MAC;
      PIntruder->data___2 = PIntruder->msgRcvd->info;
      break; }
    case 1: {
      PIntruder->msg1 = (*now.Environment);
      PIntruder->saved_message1 = 1;
      PIntruder->data___1 = PIntruder->msgRcvd->info;
      break; }
  }
  ;};
   if ::c_expr{PIntruder->msgRcvd->type == 2} -> printf("Intruder received a message of type DataMsg\n");
  ::c_expr{PIntruder->msgRcvd->type == 1} -> printf("Intruder received a message of type KeyMsg\n");
  fi;
  } /* closing the atomic */
  } /* closing 2nd atomic */
  :: atomic { c_expr{now.MessageInEnvironment!=0 && now.MessageInEnvironment != -1 && now.sent_from_intruder == 0} -> 
  atomic { c_code {PIntruder->msgRcvd = (IntMsg*)now.Environment->data;
  PIntruder->msg_to_send = (IntMsg*) PIntruder->msgModified.data;};
  if
    :: c_expr { PIntruder->msgRcvd->type == 2 } -> 
      skip;
    :: c_expr { PIntruder->msgRcvd->type == 1 } -> 
      if
         :: c_expr {PIntruder->msgRcvd->info == PIntruder->data2___2.cipher || PIntruder->msgRcvd->info == PIntruder->data2___2.key} -> 
        {
          if
            :: c_expr{PIntruder->msgRcvd->info == PIntruder->data2___2.cipher} -> /* This means that cipher is key */
            c_code {PIntruder->msg_to_send->MAC.key = PIntruder->data2___2.key - 2; PIntruder->msg_to_send->MAC.cipher = PIntruder->data2___2.cipher; }; 
            :: c_expr{PIntruder->msgRcvd->info == PIntruder->data2___2.key} -> 
            c_code {PIntruder->msg_to_send->MAC.cipher = PIntruder->data2___2.cipher - 2; PIntruder->msg_to_send->MAC.key = PIntruder->data2___2.key; }; 
            :: else->skip;
          fi;
          if
            :: c_code {PIntruder->msg_to_send->info = PIntruder->data___2 + -2;}; /* Modify content */
            :: c_code {PIntruder->msg_to_send->info = PIntruder->data___2 + -1;}; /* Modify content */
          fi;
          c_code {PIntruder->msg_to_send->dest = PIntruder->msgRcvd->dest;};
          c_code {PIntruder->msg_to_send->src = PIntruder->msgRcvd->src;};
          c_code { PIntruder->msg_is_modified = 1;
          PIntruder->msg_to_send->type = 2;
          now.Environment = &PIntruder->msgModified;
          now.MessageInEnvironment = -1;
          now.Sender = PIntruder->msgRcvd->src;
          now.Receiver = PIntruder->msgRcvd->dest;
          now.sent_from_intruder = 1;
          now.MessageCounter = -1;
          };
        }
        ::if
          :: c_code {PIntruder->msg_to_send->info = PIntruder->msgRcvd->info - 2;};
          :: c_code {PIntruder->msg_to_send->info = PIntruder->msgRcvd->info - 1;};
        fi;
        c_code {
        PIntruder->msg_to_send->src = PIntruder->msgRcvd->src;
        PIntruder->msg_to_send->type = 1;
        PIntruder->msg_to_send->dest = PIntruder->msgRcvd->dest;
        now.Environment = &PIntruder->msgModified;
        now.MessageInEnvironment = -1;
        now.Sender = PIntruder->msgRcvd->src;
        now.Receiver = PIntruder->msgRcvd->dest;
        now.sent_from_intruder = 1;
        now.MessageCounter = -1;
        };
        fi;
    fi;
  if :: c_expr{PIntruder->msg_is_modified == 1} -> printf(" and modified it\n"); c_code {PIntruder->msg_is_modified = 0;};
  :: else -> printf(" and saved it\n");
  fi;
  } /* closing atomic */ 
  } /* closing atomic */ 
  :: atomic {c_expr{PIntruder->saved_message2 == 1 && now.can_send2 == 1 && (now.sent_from_intruder != 1 || now.MessageInEnvironment != -1 || ((IntMsg*)now.Environment->data)->type != 2)}-> 
  atomic {
    c_code{PIntruder->msg_to_send = (IntMsg*) PIntruder->msgModified.data;
     PIntruder->msg_to_send->MAC = ((IntMsg*)PIntruder->msg2.data)->MAC;
     PIntruder->msg_to_send->info = ((IntMsg*)PIntruder->msg2.data)->info;
     PIntruder->msg_to_send->dest = ((IntMsg*)PIntruder->msg2.data)->dest;
     PIntruder->msg_to_send->src = ((IntMsg*)PIntruder->msg2.data)->src;
     PIntruder->msg_to_send->type = 2;
    now.Environment = &PIntruder->msgModified;
    now.MessageInEnvironment = ((IntMsg *) now.Environment->data)->type;
    now.Sender = PIntruder->msg_to_send->src;
    now.Receiver = PIntruder->msg_to_send->dest;
    now.sent_from_intruder = 1;
    now.MessageCounter = -1;
    now.can_send2 = 0;
    };
  } /* atomic */
  } /* closing 2nd atomic */
  :: atomic {c_expr{PIntruder->saved_message1 == 1 && now.can_send1 == 1 && (now.sent_from_intruder != 1 || now.MessageInEnvironment != -1 || ((IntMsg*)now.Environment->data)->type != 1)}-> 
  atomic {
    c_code{PIntruder->msg_to_send = (IntMsg*) PIntruder->msgModified.data;
    }; if
    ::c_code {PIntruder->msg_to_send->info = ((IntMsg*)PIntruder->msg1.data)->info - 2;};
    ::c_code {PIntruder->msg_to_send->info = ((IntMsg*)PIntruder->msg1.data)->info;};
    fi; c_code{;
     PIntruder->msg_to_send->type = 1;
    now.Environment = &PIntruder->msgModified;
    now.MessageInEnvironment = ((IntMsg *) now.Environment->data)->type;
    now.Sender = PIntruder->msg_to_send->src;
    now.Receiver = PIntruder->msg_to_send->dest;
    now.sent_from_intruder = 1;
    now.MessageCounter = -1;
    now.can_send1 = 0;
    };
  } /* atomic */
  } /* closing 2nd atomic */
  od;
}
c_state "int start_timer[2]" "Global" 
c_state "int timer_counter" "Local events" 
c_state "int tasks_queue[4]" "Local events" 
c_state "int tasks_index" "Local events" 
c_state "int index" "Local events" 
c_state "int tasks_queue[4]" "Local prtcl" 
c_state "int tasks_index" "Local prtcl" 
c_state "int index" "Local prtcl" 
proctype prtcl(int node){ 
   OneWayKeyM___StdControl___init();
   OneWayKeyM___StdControl___start();
}
proctype events(int node) {
do
::atomic { c_expr{now.MessageCounter != Pevents->node && now.MessageInEnvironment != 0 && now.Sender!= Pevents->node && now.Receiver < 2 &&( (now.Sender == 1 && Pevents->node == 0) || (now.Sender == 0 && Pevents->node == 1) ) } ->
atomic{
 if :: (_pid%2 == 0) -> printf("Node %d\n ", _pid/2 - 1); 
 :: else -> printf(" Node %d\n ", (_pid + 1)/2 - 1); 
 fi;
c_code { now.MessageCounter = Pevents->node;
Pevents->message_received = *now.Environment;
Pevents->SensorM___ReceiveMsg___receive___msg = &Pevents->message_received;
  if (now.MessageInEnvironment!=-1 && ((IntMsg*)(now.Environment->data))->type == 2)
  Pevents->legitimate = 1;
  if (now.MessageInEnvironment==2)
  now.can_send2 = 0;
  else if (now.MessageInEnvironment==1)
  now.can_send1 = 0;
  else {
  now.can_send2 = 1;
  now.can_send1 = 1;
  }
;};
}
}
SensorM___ReceiveMsg___receive();
:: c_expr{now.start_timer[Pevents->node] == 1 && Pevents->timer_counter < 3} -> SensorM___Timer___fired(); c_code{Pevents->timer_counter++;};
od;
}
init {
   run prtcl(0);
   run events(0);
   run prtcl(1);
   run events(1);
   run Intruder();
}
#define q c_expr{now.SensorM___Leds___greenOn___0 && now.MessageInEnvironment == 2}
#define p 1==1
/* p always true */
never {    /* !([] (p)) */
T0_init:
	if
	:: (! ((p))) -> goto accept_all
	:: (1) -> goto T0_init
	fi;
accept_all:
	skip
}
